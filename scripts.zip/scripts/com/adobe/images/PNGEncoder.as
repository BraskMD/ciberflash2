package com.adobe.images
{
   import flash.display.BitmapData;
   import flash.geom.*;
   import flash.utils.*;
   
   public class PNGEncoder
   {
      private static var crcTable:Array;
      
      private static var crcTableComputed:Boolean = false;
      
      public function PNGEncoder()
      {
         super();
      }
      
      private static function writeChunk(png:ByteArray, _arg_2:uint, data:ByteArray) : void
      {
         var c:uint = 0;
         var n:uint = 0;
         var k:uint = 0;
         var len:uint = 0;
         var i:int = 0;
         if(!crcTableComputed)
         {
            crcTableComputed = true;
            crcTable = [];
            n = 0;
            while(n < 256)
            {
               c = n;
               k = 0;
               while(k < 8)
               {
                  if(c & 1)
                  {
                     c = uint(uint(3988292384) ^ uint(c >>> 1));
                  }
                  else
                  {
                     c = uint(c >>> 1);
                  }
                  k++;
               }
               crcTable[n] = c;
               n++;
            }
         }
         if(data != null)
         {
            len = data.length;
         }
         png.writeUnsignedInt(len);
         var p:uint = png.position;
         png.writeUnsignedInt(_arg_2);
         if(data != null)
         {
            png.writeBytes(data);
         }
         var e:uint = png.position;
         png.position = p;
         c = 4294967295;
         while(i < e - p)
         {
            c = uint(crcTable[(c ^ png.readUnsignedByte()) & uint(255)] ^ uint(c >>> 8));
            i++;
         }
         c = uint(c ^ uint(4294967295));
         png.position = e;
         png.writeUnsignedInt(c);
      }
      
      public static function encode(img:BitmapData) : ByteArray
      {
         var p:uint = 0;
         var j:int = 0;
         var i:int = 0;
         var png:ByteArray = new ByteArray();
         png.writeUnsignedInt(2303741511);
         png.writeUnsignedInt(218765834);
         var IHDR:ByteArray = new ByteArray();
         IHDR.writeInt(img.width);
         IHDR.writeInt(img.height);
         IHDR.writeUnsignedInt(134610944);
         IHDR.writeByte(0);
         writeChunk(png,1229472850,IHDR);
         var IDAT:ByteArray = new ByteArray();
         while(i < img.height)
         {
            IDAT.writeByte(0);
            if(!img.transparent)
            {
               j = 0;
               while(j < img.width)
               {
                  p = img.getPixel(j,i);
                  IDAT.writeUnsignedInt(uint((p & 0xFFFFFF) << 8 | 0xFF));
                  j++;
               }
            }
            else
            {
               j = 0;
               while(j < img.width)
               {
                  p = img.getPixel32(j,i);
                  IDAT.writeUnsignedInt(uint((p & 0xFFFFFF) << 8 | p >>> 24));
                  j++;
               }
            }
            i++;
         }
         IDAT.compress();
         writeChunk(png,1229209940,IDAT);
         writeChunk(png,1229278788,null);
         return png;
      }
   }
}

