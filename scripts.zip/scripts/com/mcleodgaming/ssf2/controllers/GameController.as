package com.mcleodgaming.ssf2.controllers
{
   import com.mcleodgaming.ssf2.*;
   import com.mcleodgaming.ssf2.audio.*;
   import com.mcleodgaming.ssf2.engine.*;
   import com.mcleodgaming.ssf2.enums.*;
   import com.mcleodgaming.ssf2.items.*;
   import com.mcleodgaming.ssf2.menus.*;
   import com.mcleodgaming.ssf2.net.*;
   import com.mcleodgaming.ssf2.util.*;
   import flash.display.*;
   import flash.events.*;
   import flash.system.*;
   
   public class GameController
   {
      public static var stageData:StageData;
      
      public static var tmpStageData:StageData;
      
      public static var currentGame:Game;
      
      public static var onlineModeMatchSettings:Object;
      
      public static var tmpGame:Game;
      
      public static var weather:MovieClip;
      
      public static var cutscene:MovieClip;
      
      public static var tags:MovieClip;
      
      public static var hud:HudMenu;
      
      public static var constantDebugger:ConstantDebuggerMenu;
      
      public static var stage:MovieClip;
      
      public static var background:MovieClip;
      
      public static var stageMusic:String;
      
      public static var loopLoc:Number;
      
      public static var cameraParameters:VcamSettings;
      
      public static var isStarted:Boolean;
      
      private static var matchStarted:Boolean;
      
      private static var m_prepped:Boolean = false;
      
      init();
      
      public function GameController()
      {
         super();
      }
      
      public static function init() : void
      {
         weather = null;
         cutscene = null;
         tags = null;
         hud = null;
         constantDebugger = null;
         stage = null;
         background = null;
         stageMusic = null;
         loopLoc = 0;
         cameraParameters = null;
         matchStarted = false;
      }
      
      private static function getStatsNameForPlayer(id:int, playerSettings:Vector.<PlayerSetting>) : String
      {
         var i:int = 0;
         var statsName:String = playerSettings[id].character;
         if(!statsName)
         {
            i = id - 1;
            while(i >= 0)
            {
               if(playerSettings[i].character)
               {
                  statsName = playerSettings[i].character === "random" ? Main.RandCharList[i].StatsName : playerSettings[i].character;
               }
               i--;
            }
         }
         else if(statsName === "random")
         {
            statsName = Main.RandCharList[id].StatsName;
         }
         return statsName;
      }
      
      private static function setupRandomCostumes() : void
      {
         var costumeNum:int = 0;
         var randCostumeArr:Array = null;
         var found:Boolean = false;
         var i:int = 0;
         var j:int = 0;
         var statsName:String = null;
         var altStatsName:String = null;
         var k:int = 0;
         while(k < currentGame.PlayerSettings.length)
         {
            if(!currentGame.SuddenDeath && !currentGame.LevelData.teams && (currentGame.PlayerSettings[k].character == "random" || currentGame.PlayerSettings[k].isRandom) || currentGame.GameMode == Mode.TRAINING && !currentGame.PlayerSettings[k].character)
            {
               costumeNum = 0;
               randCostumeArr = new Array();
               found = false;
               i = 0;
               j = 0;
               statsName = GameController.getStatsNameForPlayer(k,currentGame.PlayerSettings);
               i = 0;
               while(i < currentGame.PlayerSettings.length)
               {
                  if(currentGame.PlayerSettings[i].exist && currentGame.PlayerSettings[i].character && currentGame.PlayerSettings[i].costume == -1 && i != k)
                  {
                     found = true;
                  }
                  i++;
               }
               if(!found)
               {
                  randCostumeArr.push(-1);
               }
               while(ResourceManager.getCostume(statsName,null,costumeNum) != null)
               {
                  found = false;
                  i = 0;
                  while(i < currentGame.PlayerSettings.length)
                  {
                     altStatsName = GameController.getStatsNameForPlayer(i,currentGame.PlayerSettings);
                     if(currentGame.PlayerSettings[i].exist && altStatsName && currentGame.PlayerSettings[i].costume == costumeNum && i != k)
                     {
                        found = true;
                     }
                     i++;
                  }
                  if(!found)
                  {
                     randCostumeArr.push(costumeNum);
                  }
                  costumeNum++;
               }
               currentGame.PlayerSettings[k].costume = randCostumeArr[Utils.randomInteger(0,randCostumeArr.length - 1)];
            }
            else
            {
               Utils.random();
            }
            k++;
         }
      }
      
      public static function startMatch(game:Game = null) : void
      {
         var currStage:Resource = null;
         var hasMusic:Boolean = false;
         var musicID:String = null;
         var musicResource:Resource = null;
         var id3:* = undefined;
         var stg:MovieClip = null;
         var randomIndex:int = 0;
         var str:String = null;
         var cameraObj:Object = null;
         var count:int = 0;
         MultiplayerManager.vsFinish(null);
         if(game)
         {
            GameController.currentGame = game;
         }
         if(!matchStarted)
         {
            if(Boolean(ModeFeatures.hasFeature(ModeFeatures.MULTIPLAYER_MANAGER,GameController.currentGame.GameMode)) && !GameController.currentGame.SuddenDeath)
            {
               if(MultiplayerManager.RoomData.matchSettings.gameMode === Mode.ONLINE_ARENA)
               {
                  GameController.currentGame.CustomModeObj.PreviousMenu = MultiplayerManager.IsHost ? MenuController.arenaCharacterSelectMenu : MenuController.onlineCharacterMenu;
               }
            }
            Main.Root.visible = false;
            matchStarted = true;
            weather = new MovieClip();
            cutscene = new MovieClip();
            tags = new MovieClip();
            background = new MovieClip();
            hud = new HudMenu();
            constantDebugger = new ConstantDebuggerMenu();
            if(Main.DEBUG)
            {
               hud.Container.addChild(constantDebugger.Container);
            }
            stage = ResourceManager.getLibraryMC(GameController.currentGame.LevelData.stage == "xpstage" ? "xpstage" : "stage_" + GameController.currentGame.LevelData.stage);
            stage.name = "stageMC";
            Main.Root.addChild(background);
            Main.Root.addChild(stage);
            Main.Root.addChild(tags);
            Main.Root.addChild(weather);
            Main.Root.addChild(cutscene);
            Main.Root.addChild(hud.Container);
            currStage = ResourceManager.getResourceByID(GameController.currentGame.LevelData.stage);
            hasMusic = !!GameController.currentGame.LevelData.musicOverride ? true : currStage.getProp("music") && Boolean(currStage.getProp("music").length);
            musicID = hasMusic ? GameController.currentGame.LevelData.musicOverride || currStage.getProp("music")[Main.RandMusicIndex].id : null;
            musicResource = !!musicID ? ResourceManager.getResourceByID(musicID) : null;
            if(hasMusic && musicResource && musicResource.getProp("id3"))
            {
               id3 = musicResource.getProp("id3");
               if(id3.songName)
               {
                  hud.displayMusicInfo(id3.songName);
               }
            }
            stageMusic = null;
            loopLoc = 0;
            if(musicResource)
            {
               stageMusic = musicResource.getProp("music") || null;
               loopLoc = musicResource.getProp("musicLoop") || 0;
            }
            cameraParameters = new VcamSettings(currStage.getProp("camera"));
            if(stageMusic == null || loopLoc == 0)
            {
               stg = currStage.MC;
               if(stg.stageMusicArray)
               {
                  randomIndex = int(Utils.safeRandomInteger(0,stg.stageMusicArray.length - 1));
                  stageMusic = stg.stageMusicArray[randomIndex];
                  loopLoc = !!stg.loopLocArray ? Number(stg.loopLocArray[randomIndex]) : Number(stg.loopLoc) || 0;
                  if(stg.stageMusicNameArray)
                  {
                     hud.displayMusicInfo(stg.stageMusicNameArray[randomIndex]);
                  }
                  else
                  {
                     hud.displayMusicInfo(stg.stageMusicName || stageMusic);
                  }
               }
               else if(stg.stageMusic)
               {
                  stageMusic = stg.stageMusic;
                  loopLoc = Number(stg.loopLoc) || 0;
                  hud.displayMusicInfo(stg.stageMusicName || (stg.stageMusic || ""));
               }
               if(stg.cameraParameters)
               {
                  cameraObj = new Object();
                  for(str in stg.cameraParameters)
                  {
                     cameraObj[str] = stg.cameraParameters[str];
                  }
                  str = "bg";
                  if(stg.cameraParameters[str])
                  {
                     count = 1;
                     cameraObj.backgrounds = new Array();
                     while(stg.cameraParameters[str] != null)
                     {
                        cameraObj.backgrounds.push({
                           "linkage_id":stg.cameraParameters[str],
                           "mode":stg.cameraParameters["mode_" + str],
                           "autoPanMultiplier":stg.cameraParameters["autoPanMultiplier_" + str],
                           "width_override":stg.cameraParameters["width_override_" + str],
                           "height_override":stg.cameraParameters["height_override_" + str],
                           "horizontalPanLock":stg.cameraParameters["horizontalPanLock_" + str],
                           "verticalPanLock":stg.cameraParameters["verticalPanLock_" + str],
                           "horizontalScroll":stg.cameraParameters["horizontalScroll_" + str],
                           "verticalScroll":stg.cameraParameters["verticalScroll_" + str],
                           "x_start":stg.cameraParameters["x_start_" + str],
                           "y_start":stg.cameraParameters["y_start_" + str],
                           "xPanMultiplier":stg.cameraParameters["xPanMultiplier_" + str],
                           "yPanMultiplier":stg.cameraParameters["yPanMultiplier_" + str],
                           "foreground":stg.cameraParameters["foreground_" + str]
                        });
                        count++;
                        str = "bg" + count;
                     }
                  }
                  cameraParameters = new VcamSettings(cameraObj);
               }
            }
            prepOtherHitBoxStuff();
            Main.Root.stage.addEventListener(Event.ENTER_FRAME,actuallyStartMatch);
         }
      }
      
      public static function prepOtherHitBoxStuff() : void
      {
         var i:int = 0;
         var j:int = 0;
         var tmpMC:MovieClip = null;
         if(m_prepped)
         {
            return;
         }
         m_prepped = true;
         var m_managerList:Vector.<String> = new Vector.<String>();
         i = 0;
         while(i < ItemsListData.DATA.length)
         {
            m_managerList.push(ItemsListData.DATA[i].linkage_id);
            i++;
         }
         j = 0;
         while(j < m_managerList.length)
         {
            if(!HitBoxManager.HitBoxManageList[m_managerList[j]])
            {
               tmpMC = ResourceManager.getLibraryMC(m_managerList[j]);
               if(tmpMC)
               {
                  i = 0;
                  while(i < tmpMC.totalFrames)
                  {
                     tmpMC.gotoAndStop(i + 1);
                     if(tmpMC.stance)
                     {
                        Utils.removeActionScript(tmpMC.stance);
                        HitBoxAnimation.createHitBoxAnimation(m_managerList[j] + "_" + tmpMC.currentLabel,tmpMC.stance,tmpMC);
                     }
                     i++;
                  }
                  tmpMC = null;
               }
            }
            j++;
         }
      }
      
      private static function actuallyStartMatch(e:Event) : void
      {
         var stageAPI:Class = null;
         var i:int = 0;
         Main.Root.stage.removeEventListener(Event.ENTER_FRAME,actuallyStartMatch);
         SaveData.Unlocks.ghostNessSDs = 0;
         var currStage:Resource = ResourceManager.getResourceByID(GameController.currentGame.LevelData.stage);
         if(currStage)
         {
            trace("Checking :: ",currStage.getProp("stage"),"::",currStage.MetaData.BASE_CLASSES.SSF2Stage);
            stageAPI = currStage.getProp("stage") || currStage.MetaData.BASE_CLASSES.SSF2Stage || null;
         }
         Utils.setRandSeed(currentGame.LevelData.randSeed);
         Utils.shuffleRandom();
         Main.prepRandomCharacters(currentGame.PlayerSettings.length);
         if(GameController.currentGame.GameMode === Mode.ONLINE_WAITING_ROOM && GameController.currentGame.PlayerSettings[0].character == "random")
         {
            Main.RandCharList[0] = Main.RandCharList[MultiplayerManager.PlayerID - 1];
         }
         GameController.setupRandomCostumes();
         if(ModeFeatures.hasFeature(ModeFeatures.MULTIPLAYER_MANAGER,GameController.currentGame.GameMode))
         {
            GameController.currentGame.fixDuplicateCostumes();
         }
         var controllers:Vector.<Controller> = ModeFeatures.hasFeature(ModeFeatures.MULTIPLAYER_MANAGER,GameController.currentGame.GameMode) ? MultiplayerManager.Controllers : SaveData.Controllers;
         GameController.stageData = new StageData(controllers,Main.Root,stageAPI,stage,hud,cameraParameters,GameController.currentGame,SoundQueue.instance,stageMusic,loopLoc);
         constantDebugger.makeEvents();
         GameController.stageData.startGame();
      }
      
      public static function endMatch() : void
      {
         if(matchStarted)
         {
            GameController.stageData.CamRef.die();
            weather.parent.removeChild(weather);
            cutscene.parent.removeChild(cutscene);
            tags.parent.removeChild(tags);
            stage.parent.removeChild(stage);
            background.parent.removeChild(background);
            hud.removeSelf();
            constantDebugger.killEvents();
            init();
            trace("Game graphics and stage data disposed");
         }
      }
      
      public static function destroyStageData() : void
      {
         if(GameController.stageData)
         {
            GameController.stageData.dispose();
         }
         GameController.stage = null;
         GameController.stageData = null;
         GameController.tmpStageData = null;
         GameController.tmpGame = null;
         Main.clearRandomCharacterPrep();
         SoundQueue.instance.setLoopFunction(SoundQueue.instance.loopMusic);
         System.gc();
      }
   }
}

