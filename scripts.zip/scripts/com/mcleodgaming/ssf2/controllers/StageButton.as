package com.mcleodgaming.ssf2.controllers
{
   import com.mcleodgaming.ssf2.*;
   import com.mcleodgaming.ssf2.audio.*;
   import com.mcleodgaming.ssf2.engine.*;
   import com.mcleodgaming.ssf2.enums.*;
   import com.mcleodgaming.ssf2.fmc.*;
   import com.mcleodgaming.ssf2.net.*;
   import com.mcleodgaming.ssf2.util.*;
   import flash.display.*;
   import flash.events.*;
   
   public class StageButton extends HandButton
   {
      protected var m_currentGame:Game;
      
      protected var m_stageID:String;
      
      protected var m_hiddenStagesList:Vector.<String>;
      
      protected var m_loadingMask:MovieClip;
      
      protected var m_currentAltIndex:int;
      
      public function StageButton(game:Game, button:MovieClip, stageID:String)
      {
         var i:int = 0;
         super(button);
         this.m_currentGame = game;
         this.m_stageID = stageID;
         this.m_hiddenStagesList = new Vector.<String>();
         this.m_hiddenStagesList.push("xpstage");
         this.m_hiddenStagesList.push("mushroomkingdom3");
         this.m_hiddenStagesList.push("skyworld");
         this.m_hiddenStagesList.push("castlesiege");
         while(i < this.m_hiddenStagesList.length)
         {
            if(!Main.DEBUG && stageID == this.m_hiddenStagesList[i])
            {
               m_button.visible = false;
               break;
            }
            i++;
         }
         this.m_loadingMask = ResourceManager.getLibraryMC("loadingMask");
         this.m_loadingMask.x = Main.Width / 2;
         this.m_loadingMask.y = Main.Height / 2;
         this.m_currentAltIndex = -1;
      }
      
      override public function makeEvents() : void
      {
         super.makeEvents();
         this.m_button.addEventListener(MouseEvent.RIGHT_CLICK,this.tryToAlternateStage);
      }
      
      override public function killEvents() : void
      {
         super.killEvents();
         this.m_button.removeEventListener(MouseEvent.RIGHT_CLICK,this.tryToAlternateStage);
      }
      
      public function get StageID() : String
      {
         return this.m_stageID;
      }
      
      public function setCurrentGame(game:Game) : void
      {
         this.m_currentGame = game;
      }
      
      override protected function button_ROLLOVER(e:MouseEvent) : void
      {
         var displayName:String = null;
         var stageInfo:Object = null;
         var tmpBmp:Bitmap = null;
         var tmpString:String = null;
         var stageAltID:String = null;
         SoundQueue.instance.playSoundEffect("menu_hover");
         if(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("mc") != null)
         {
            MenuController.stageSelectMenu.SubMenu.alternateBtn.visible = this.m_stageID === "random" ? false : ResourceManager.getResourceByID("mappings").getProp("metadata").stage[this.m_stageID].alternate_id != null;
            if(this.m_currentAltIndex == -1)
            {
               if(FMCManager.getStage(this.m_stageID) != null)
               {
                  Utils.tryToGotoAndStop(MovieClip(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("mc")),"external");
                  tmpBmp = FMCManager.getStageBitmapHD(this.m_stageID);
                  if(tmpBmp)
                  {
                     tmpBmp.x -= tmpBmp.width / 2;
                     tmpBmp.y -= tmpBmp.height / 2;
                     tmpBmp.name = "bitmapHolder";
                     MovieClip(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("mc")).mc.addChild(tmpBmp);
                  }
               }
               else
               {
                  Utils.tryToGotoAndStop(MovieClip(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("mc")),this.m_stageID == "random" ? "random" : this.m_stageID);
               }
               displayName = "Untitled";
               if(this.m_stageID === "random")
               {
                  displayName = "Random";
               }
               else if(this.m_stageID === "xpstage")
               {
                  displayName = "Expansion Stage";
               }
               else if(ResourceManager.getResourceByID("mappings").getProp("metadata").stage[this.m_stageID])
               {
                  displayName = ResourceManager.getResourceByID("mappings").getProp("metadata").stage[this.m_stageID].name;
               }
               else
               {
                  displayName = "Untitled";
               }
               MenuController.stageSelectMenu.SubMenu.stage_sample.stage_txt.text = displayName;
               MenuController.stageSelectMenu.SubMenu.stage_sample.creatorLabel.visible = this.m_stageID !== "random";
               MenuController.stageSelectMenu.SubMenu.stage_sample.noteLabel.visible = this.m_stageID !== "random";
               MenuController.stageSelectMenu.SubMenu.stage_sample.creator_txt.text = this.m_stageID === "random" ? "" : ResourceManager.getResourceByID("mappings").getProp("metadata").stage[this.m_stageID].creator || "McleodGaming";
               MenuController.stageSelectMenu.SubMenu.stage_sample.note_txt.text = this.m_stageID === "random" ? "" : ResourceManager.getResourceByID("mappings").getProp("metadata").stage[this.m_stageID].note || "None";
            }
            else
            {
               stageInfo = ResourceManager.getResourceByID("mappings").getProp("metadata").stage;
               if(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("mc"))
               {
                  if(MovieClip(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("mc")).mc)
                  {
                     MovieClip(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("mc")).mc.removeChild(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("mc").mc.getChildByName("bitmapHolder"));
                  }
               }
               stageAltID = stageInfo[this.m_stageID].alternate_id[this.m_currentAltIndex];
               SoundQueue.instance.playSoundEffect("menu_hover");
               if(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("mc") != null)
               {
                  if(!FMCManager.getStage(stageAltID))
                  {
                     Utils.tryToGotoAndStop(MovieClip(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("mc")),stageAltID == "random" ? "random" : stageAltID);
                  }
                  else
                  {
                     Utils.tryToGotoAndStop(MovieClip(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("mc")),"external");
                     tmpBmp = FMCManager.getStageBitmapHD(stageAltID);
                     if(tmpBmp)
                     {
                        tmpBmp.x -= tmpBmp.width / 2;
                        tmpBmp.y -= tmpBmp.height / 2;
                        tmpBmp.name = "bitmapHolder";
                        MovieClip(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer).mc.addChild(tmpBmp);
                     }
                  }
                  displayName = "Untitled";
                  if(stageAltID === "random")
                  {
                     displayName = "Random";
                  }
                  else if(stageAltID === "xpstage")
                  {
                     displayName = "Expansion Stage";
                  }
                  else if(stageInfo[stageAltID].name)
                  {
                     displayName = stageInfo[stageAltID].name;
                  }
                  else
                  {
                     displayName = "Untitled";
                  }
                  MenuController.stageSelectMenu.SubMenu.stage_sample.stage_txt.text = displayName;
                  MenuController.stageSelectMenu.SubMenu.stage_sample.creatorLabel.visible = stageAltID !== "random";
                  MenuController.stageSelectMenu.SubMenu.stage_sample.noteLabel.visible = stageAltID !== "random";
                  MenuController.stageSelectMenu.SubMenu.stage_sample.creator_txt.text = stageAltID === "random" ? "" : stageInfo[stageAltID].creator || "McleodGaming";
                  MenuController.stageSelectMenu.SubMenu.stage_sample.note_txt.text = stageAltID === "random" ? "" : stageInfo[stageAltID].note || "None";
               }
            }
         }
      }
      
      override protected function button_CLICK(e:MouseEvent) : void
      {
         var i:int = 0;
         if(!GameController.isStarted)
         {
            if(this.m_stageID !== "random" && !ResourceManager.getResourceByID(this.m_stageID).FileName)
            {
               SoundQueue.instance.playSoundEffect("menu_error");
               return;
            }
            SoundQueue.instance.playSoundEffect("menu_crowd");
            SoundQueue.instance.playSoundEffect("menu_selectstage");
            GameController.isStarted = true;
            this.m_currentGame.LevelData.stage = this.m_stageID === "random" ? StageSetting.getRandomStage() : this.m_stageID;
            if(this.m_currentAltIndex != -1)
            {
               this.m_currentGame.LevelData.stage = ResourceManager.getResourceByID("mappings").getProp("metadata").stage[this.m_stageID].alternate_id[this.m_currentAltIndex];
            }
            m_button.removeEventListener(MouseEvent.ROLL_OVER,this.button_ROLLOVER);
            m_button.removeEventListener(MouseEvent.CLICK,this.button_CLICK);
            m_button.removeEventListener(MouseEvent.ROLL_OUT,this.button_ROLLOUT);
            if(this.m_currentGame.GameMode === Mode.ONLINE)
            {
               MultiplayerManager.toWaitingRoom(this.m_currentGame,this.startGame);
            }
            else
            {
               this.m_currentGame.LevelData.randSeed = Utils.randomInteger(1,1000);
               Utils.setRandSeed(this.m_currentGame.LevelData.randSeed);
               Utils.shuffleRandom();
               Main.prepRandomCharacters(this.m_currentGame.PlayerSettings.length);
               ResourceManager.queueResources([this.m_currentGame.LevelData.stage]);
               i = 1;
               while(i <= this.m_currentGame.PlayerSettings.length)
               {
                  if(this.m_currentGame.PlayerSettings[i - 1] && this.m_currentGame.PlayerSettings[i - 1].exist && this.m_currentGame.PlayerSettings[i - 1].character != null && this.m_currentGame.PlayerSettings[i - 1].character != "xp")
                  {
                     ResourceManager.queueResources([this.m_currentGame.PlayerSettings[i - 1].character == "random" ? Main.RandCharList[i - 1].StatsName : this.m_currentGame.PlayerSettings[i - 1].character]);
                  }
                  i++;
               }
               if(!MultiplayerManager.vsShow(this.m_currentGame.PlayerSettings,false))
               {
                  Main.Root.addChild(this.m_loadingMask);
               }
               ResourceManager.load({"oncomplete":this.startGame});
            }
         }
      }
      
      override protected function button_ROLLOUT(e:MouseEvent) : void
      {
         var previewer:MovieClip = MenuController.stageSelectMenu.SubMenu.stage_sample.previewer;
         if(!GameController.isStarted)
         {
            if(previewer.getChildByName("mc").mc)
            {
               if(previewer.getChildByName("mc").mc.getChildByName("mc"))
               {
                  previewer.getChildByName("mc").mc.removeChild(previewer.getChildByName("mc").mc.getChildByName("bitmapHolder"));
               }
            }
            Utils.tryToGotoAndStop(MovieClip(previewer.getChildByName("mc")),"paused");
            MenuController.stageSelectMenu.SubMenu.stage_sample.stage_txt.text = "";
            MenuController.stageSelectMenu.SubMenu.stage_sample.creator_txt.text = "";
            MenuController.stageSelectMenu.SubMenu.stage_sample.note_txt.text = "";
            MenuController.stageSelectMenu.SubMenu.stage_sample.creatorLabel.visible = false;
            MenuController.stageSelectMenu.SubMenu.stage_sample.noteLabel.visible = false;
            MenuController.stageSelectMenu.SubMenu.alternateBtn.visible = false;
         }
      }
      
      public function startGame(e:* = null) : void
      {
         MultiplayerManager.vsFinish(this.startGameNow);
      }
      
      public function startGameNow() : void
      {
         if(this.m_loadingMask.parent != null)
         {
            Main.Root.removeChild(this.m_loadingMask);
         }
         MenuController.disposeAllMenus();
         GameController.startMatch(this.m_currentGame);
      }
      
      public function tryToAlternateStage(e:* = null) : void
      {
         var displayName:String = null;
         var tmpBmp:Bitmap = null;
         var tmpString:String = null;
         var stageInfo:Object = ResourceManager.getResourceByID("mappings").getProp("metadata").stage;
         var stageAltID:String = null;
         if(!stageInfo[this.m_stageID].alternate_id)
         {
            SoundQueue.instance.playSoundEffect("menu_error");
            return;
         }
         MenuController.stageSelectMenu.SubMenu.alternateBtn.visible = stageInfo[this.m_stageID].alternate_id != null;
         if(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("bitmapHolder"))
         {
            MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.removeChild(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("bitmapHolder"));
         }
         ++this.m_currentAltIndex;
         stageAltID = stageInfo[this.m_stageID].alternate_id[this.m_currentAltIndex];
         if(this.m_currentAltIndex >= stageInfo[this.m_stageID].alternate_id.length)
         {
            this.m_currentAltIndex = -1;
         }
         stageAltID = this.m_currentAltIndex == -1 ? this.m_stageID : stageInfo[this.m_stageID].alternate_id[this.m_currentAltIndex];
         SoundQueue.instance.playSoundEffect("menu_hover");
         if(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("mc") != null)
         {
            if(FMCManager.getStage(stageAltID) == null)
            {
               Utils.tryToGotoAndStop(MovieClip(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer.getChildByName("mc")),stageAltID == "random" ? "random" : stageAltID);
            }
            else
            {
               tmpBmp = FMCManager.getStageBitmapHD(stageAltID);
               if(tmpBmp)
               {
                  tmpBmp.x -= tmpBmp.width / 2;
                  tmpBmp.y -= tmpBmp.height / 2;
                  tmpBmp.name = "bitmapHolder";
                  MovieClip(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer).addChild(tmpBmp);
               }
            }
            displayName = "Untitled";
            if(stageAltID === "random")
            {
               displayName = "Random";
            }
            else if(stageAltID === "xpstage")
            {
               displayName = "Expansion Stage";
            }
            else if(stageInfo[stageAltID].name)
            {
               displayName = stageInfo[stageAltID].name;
            }
            else
            {
               displayName = "Untitled";
            }
            MenuController.stageSelectMenu.SubMenu.stage_sample.stage_txt.text = displayName;
            MenuController.stageSelectMenu.SubMenu.stage_sample.creatorLabel.visible = stageAltID !== "random";
            MenuController.stageSelectMenu.SubMenu.stage_sample.noteLabel.visible = stageAltID !== "random";
            MenuController.stageSelectMenu.SubMenu.stage_sample.creator_txt.text = stageAltID === "random" ? "" : stageInfo[stageAltID].creator || "McleodGaming";
            MenuController.stageSelectMenu.SubMenu.stage_sample.note_txt.text = stageAltID === "random" ? "" : stageInfo[stageAltID].note || "None";
         }
         if(e is MouseEvent)
         {
            this.m_button.dispatchEvent(new MouseEvent(MouseEvent.MOUSE_OVER));
         }
      }
   }
}

