package com.mcleodgaming.ssf2.fmc.loader
{
   import com.mcleodgaming.ssf2.fmc.*;
   import flash.display.*;
   import flash.events.*;
   import flash.net.*;
   
   public class BitmapAssetLoader
   {
      private static var _queueLength:int;
      
      private static var _urls:Array;
      
      private static var _successBack:Function;
      
      private static var _processBack:Function;
      
      private static var loader:Loader;
      
      private static var successBitmap:Function;
      
      private static var failBitmap:Function;
      
      private static var processBitmap:Function;
      
      public function BitmapAssetLoader()
      {
         super();
      }
      
      public static function loadQueue(array:Array, successFunc:Function, processFunc:Function = null) : void
      {
         _successBack = successFunc;
         _processBack = processFunc;
         _urls = array.concat();
         _queueLength = array.length;
         BitmapAssetLoader.loadNext();
      }
      
      private static function load(_arg_1:String, _arg_2:Function = null, _arg_3:Function = null) : void
      {
         var url:String = null;
         var back:Function = null;
         url = _arg_1;
         back = _arg_2;
         var process:Function = _arg_3;
         var loadCom:* = function(_arg_1:DisplayObject):void
         {
            trace("BitmapAssetLoader.load success ::",url);
            FMCManager.cacheBitmap(url,_arg_1);
            if(back != null)
            {
               back();
            }
         };
         var loadFail:* = function():void
         {
            trace("BitmapAssetLoader.loadFail ::",url);
            if(back != null)
            {
               back();
            }
         };
         BitmapAssetLoader.loadBitmap(url,loadCom,loadFail,process);
      }
      
      private static function loadNext() : void
      {
         var loadProcess:* = function(_arg_1:Number):void
         {
            var _local_3:Number = NaN;
            var _local_2:Number = NaN;
            if(_processBack != null)
            {
               _local_3 = _queueLength - _urls.length - 1 + _arg_1;
               _local_2 = _local_3 / _queueLength;
               _processBack(_local_2);
            }
         };
         if(_urls.length < 1)
         {
            if(_successBack != null)
            {
               _successBack();
            }
            return;
         }
         BitmapAssetLoader.load(_urls.shift(),loadNext,loadProcess);
      }
      
      private static function loadBitmap(url:String, successFunc:Function, failFunc:Function = null, processFunc:Function = null) : void
      {
         successBitmap = successFunc;
         failBitmap = failFunc;
         processBitmap = processFunc;
         if(loader != null)
         {
            loader = null;
         }
         loader = new Loader();
         loader.contentLoaderInfo.addEventListener(Event.COMPLETE,loadBitmapComplete);
         loader.contentLoaderInfo.addEventListener("ioError",loadBitmapError);
         loader.contentLoaderInfo.addEventListener("progress",loadBitmapProgress);
         loader.load(new URLRequest(url));
      }
      
      private static function loadBitmapComplete(e:Event) : void
      {
         loader.contentLoaderInfo.removeEventListener(Event.COMPLETE,loadBitmapComplete);
         loader.contentLoaderInfo.removeEventListener("ioError",loadBitmapError);
         loader.contentLoaderInfo.removeEventListener("progress",loadBitmapProgress);
         if(successBitmap != null)
         {
            successBitmap(loader.content);
         }
         loader.unload();
      }
      
      private static function loadBitmapError(e:Event) : void
      {
         loader.contentLoaderInfo.removeEventListener(Event.COMPLETE,loadBitmapComplete);
         loader.contentLoaderInfo.removeEventListener("ioError",loadBitmapError);
         loader.contentLoaderInfo.removeEventListener("progress",loadBitmapProgress);
         if(failBitmap != null)
         {
            failBitmap();
         }
         loader.close();
      }
      
      private static function loadBitmapProgress(e:ProgressEvent) : void
      {
         if(processBitmap != null)
         {
            processBitmap(e.bytesLoaded / e.bytesTotal);
         }
      }
   }
}

