package com.mcleodgaming.ssf2.fmc.loader
{
   import com.mcleodgaming.ssf2.net.*;
   import flash.events.*;
   import flash.filesystem.*;
   import flash.net.*;
   
   public class TextAssetLoader
   {
      private static var urlLoader:URLLoader;
      
      private static var successFunc:Function;
      
      private static var failFunc:Function;
      
      public function TextAssetLoader()
      {
         super();
      }
      
      private static function loadComplete(e:Event) : void
      {
         urlLoader.removeEventListener(Event.COMPLETE,loadComplete);
         urlLoader.removeEventListener(IOErrorEvent.IO_ERROR,loadErrorIO);
         urlLoader.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,loadErrorSecurity);
         if(successFunc != null)
         {
            successFunc(urlLoader.data);
         }
      }
      
      private static function loadErrorIO(e:Event) : void
      {
         urlLoader.removeEventListener(Event.COMPLETE,loadComplete);
         urlLoader.removeEventListener(IOErrorEvent.IO_ERROR,loadErrorIO);
         urlLoader.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,loadErrorSecurity);
         if(failFunc != null)
         {
            failFunc();
         }
         trace(e.toString());
         urlLoader.close();
      }
      
      private static function loadErrorSecurity(e:Event) : void
      {
         urlLoader.removeEventListener(Event.COMPLETE,loadComplete);
         urlLoader.removeEventListener(IOErrorEvent.IO_ERROR,loadErrorIO);
         urlLoader.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,loadErrorSecurity);
         if(failFunc != null)
         {
            failFunc();
         }
         trace(e.toString());
         urlLoader.close();
      }
      
      public static function load(url:String, back:Function, failBack:Function = null) : void
      {
         successFunc = back;
         failFunc = failBack;
         if(urlLoader != null)
         {
            urlLoader = null;
         }
         urlLoader = new URLLoader();
         urlLoader.addEventListener(Event.COMPLETE,loadComplete);
         urlLoader.addEventListener(IOErrorEvent.IO_ERROR,loadErrorIO);
         urlLoader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,loadErrorSecurity);
         urlLoader.load(new URLRequest(url));
      }
      
      public static function loadSimple(path:String) : String
      {
         var content:String = null;
         if(!File.applicationDirectory.resolvePath(path).exists)
         {
            MultiplayerManager.notify("[TextAssetLoader] File [" + path + "] does not exist");
            return null;
         }
         var stream:FileStream = new FileStream();
         stream.open(File.applicationDirectory.resolvePath(path),FileMode.READ);
         content = stream.readUTFBytes(stream.bytesAvailable);
         stream.close();
         return content;
      }
   }
}

