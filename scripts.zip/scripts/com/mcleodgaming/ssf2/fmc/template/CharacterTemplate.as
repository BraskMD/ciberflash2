package com.mcleodgaming.ssf2.fmc.template
{
   public class CharacterTemplate
   {
      private var charID:String;
      
      private var altCharID:String;
      
      private var charName:String;
      
      private var cssName:String;
      
      private var charInfo:String;
      
      private var txtSize:Number;
      
      private var portraitURL:String;
      
      private var cssURL:String;
      
      private var fsCutinURL:String;
      
      private var costumeURL:String;
      
      private var _cloneKey:Array = ["charID","altCharID","charName","cssName","charInfo","txtSize","portraitURL","cssURL","fsCutinURL","costumeURL"];
      
      public function CharacterTemplate()
      {
         super();
      }
      
      public function initByXML(_arg_1:XML) : void
      {
         this.charID = _arg_1.@id;
         this.altCharID = _arg_1.@alternateID;
         this.charName = _arg_1.@charName;
         this.cssName = _arg_1.@cssName;
         this.charInfo = _arg_1.@info;
         this.txtSize = Number(_arg_1.@txtNumber);
         this.portraitURL = _arg_1.resource.@portrait;
         this.cssURL = _arg_1.resource.@icon;
         this.fsCutinURL = _arg_1.resource.@fs_cutin;
         this.costumeURL = _arg_1.resource.@costume_data;
         this.cssName = this.cssName.replace(/\\n/g,"\n");
         this.charInfo = this.charInfo.replace(/\\n/g,"\n");
      }
      
      public function clone() : CharacterTemplate
      {
         var _local_2:String = null;
         var _local_1:CharacterTemplate = new CharacterTemplate();
         for each(_local_2 in this._cloneKey)
         {
            _local_1[_local_2] = this[_local_2];
         }
         return _local_1;
      }
      
      public function get ID() : String
      {
         return this.charID;
      }
      
      public function get CharName() : String
      {
         return this.charName;
      }
      
      public function get CssName() : String
      {
         return this.cssName;
      }
      
      public function get TextSize() : Number
      {
         return this.txtSize;
      }
      
      public function get PortraitURL() : String
      {
         return this.portraitURL;
      }
      
      public function get CssURL() : String
      {
         return this.cssURL;
      }
      
      public function get FSCutinURL() : String
      {
         return this.fsCutinURL;
      }
      
      public function get CostumeURL() : String
      {
         return this.costumeURL;
      }
      
      public function get CharInfo() : String
      {
         return this.charInfo;
      }
      
      public function get AlternateID() : String
      {
         return this.altCharID;
      }
   }
}

