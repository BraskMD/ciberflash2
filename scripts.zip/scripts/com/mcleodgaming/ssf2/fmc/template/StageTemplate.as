package com.mcleodgaming.ssf2.fmc.template
{
   public class StageTemplate
   {
      private var id:String;
      
      private var previewURL:String;
      
      private var _cloneKey:Array = ["id","previewURL"];
      
      public function StageTemplate()
      {
         super();
      }
      
      public function initByXML(_arg_1:XML) : void
      {
         this.id = _arg_1.@id;
         this.previewURL = _arg_1.@previewURL;
      }
      
      public function get ID() : String
      {
         return this.id;
      }
      
      public function get PreviewURL() : String
      {
         return this.previewURL;
      }
      
      public function clone() : StageTemplate
      {
         var _local_2:String = null;
         var _local_1:StageTemplate = new StageTemplate();
         for each(_local_2 in this._cloneKey)
         {
            _local_1[_local_2] = this[_local_2];
         }
         return _local_1;
      }
   }
}

