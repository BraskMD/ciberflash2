package com.mcleodgaming.ssf2.fmc
{
   import com.mcleodgaming.ssf2.fmc.loader.*;
   import com.mcleodgaming.ssf2.net.*;
   import flash.display.*;
   import flash.events.*;
   import flash.net.*;
   
   public class FMCLoader
   {
      private static var initLoadSuccessFunc:Function;
      
      private static var initLoadProcessFunc:Function;
      
      private static var initLoadStep:int;
      
      private static var initLoadStepName:String;
      
      public function FMCLoader()
      {
         super();
      }
      
      public static function initLoad(successFunc:Function, processFunc:Function) : void
      {
         initLoadSuccessFunc = successFunc;
         initLoadProcessFunc = processFunc;
         initLoadStep = -1;
         initLoadStepName = null;
         FMCLoader.initLoadNext();
      }
      
      private static function initLoadProcess(percent:Number) : void
      {
         if(initLoadProcessFunc != null)
         {
            initLoadProcessFunc(percent,initLoadStepName);
         }
      }
      
      private static function initLoadNext() : void
      {
         ++initLoadStep;
         switch(initLoadStep)
         {
            case 0:
               initLoadStepName = "Loading Mapping JSON";
               TextAssetLoader.load("assets/config/mappings.json",initMappingsJSON,initLoadNext);
               break;
            case 1:
               initLoadStepName = "Loading Character XML";
               TextAssetLoader.load("assets/config/fighter.xml",initCharacterXML,initLoadNext);
               break;
            case 2:
               initLoadStepName = "Loading Stage XML";
               TextAssetLoader.load("assets/config/stage.xml",initStageXML,initLoadNext);
               break;
            case 3:
               initLoadStepName = "Loading Character Bitmap";
               BitmapAssetLoader.loadQueue(FMCManager.getAllCharacterBitmapFileURL(),initLoadNext,initLoadProcess);
               break;
            case 4:
               initLoadStepName = "Loading Stage Bitmap";
               BitmapAssetLoader.loadQueue(FMCManager.getAllStageBitmapFileURL(),initLoadNext,initLoadProcess);
               break;
            case 5:
               initLoadStepName = "Here we go!";
               if(initLoadSuccessFunc != null)
               {
                  initLoadSuccessFunc();
                  initLoadSuccessFunc = null;
               }
         }
      }
      
      private static function initCharacterXML(data:*) : void
      {
         try
         {
            FMCManager.importCharacter(new XML(data));
            FMCLoader.initLoadNext();
         }
         catch(e:Error)
         {
            MultiplayerManager.notify("[FMCLoader]" + e.toString() + " in assets/config/fighter.xml");
         }
      }
      
      private static function initStageXML(data:*) : void
      {
         try
         {
            FMCManager.importStage(new XML(data));
            FMCLoader.initLoadNext();
         }
         catch(e:Error)
         {
            MultiplayerManager.notify("[FMCLoader]" + e.toString() + " in assets/config/stage.xml");
         }
      }
      
      private static function initMappingsJSON(data:*) : void
      {
         try
         {
            FMCManager.importMappings(JSON.parse(data));
            FMCLoader.initLoadNext();
         }
         catch(e:Error)
         {
            MultiplayerManager.notify("[FMCLoader]" + e.toString() + " in assets/config/mappings.json");
         }
      }
   }
}

