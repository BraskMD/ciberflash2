package com.mcleodgaming.ssf2.fmc
{
   import com.mcleodgaming.ssf2.fmc.template.*;
   import com.mcleodgaming.ssf2.util.*;
   import flash.display.*;
   import flash.geom.Matrix;
   import flash.system.*;
   
   public class FMCData
   {
      public static const CHARACTER_CSS:int = 0;
      
      public static const CHARACTER_PORTRAIT:int = 1;
      
      public static const CHARACTER_FS_CUTIN:int = 2;
      
      public static const STAGE_PREVIEW_WIDTH:int = 256;
      
      private var mappingsObject:Object;
      
      private var characterObject:Object;
      
      private var stageObject:Object;
      
      private var bitmapObject:Object;
      
      private var costumeObject:Array;
      
      private var metalCostumeObject:Object;
      
      private var infoObject:Object;
      
      public function FMCData()
      {
         super();
         this.mappingsObject = ResourceManager.getResourceByID("mappings").getProp("metadata");
         this.characterObject = new Object();
         this.stageObject = new Object();
         this.bitmapObject = new Object();
         this.costumeObject = ResourceManager.getResourceByID("misc").getProp("metadata").costume_data;
         this.metalCostumeObject = ResourceManager.getResourceByID("misc").getProp("metadata").metal_costume_data;
         this.infoObject = ResourceManager.getResourceByID("misc_fmc_character").getProp("metadata").info;
      }
      
      private static function noDuplicateArray(arr:Array) : Array
      {
         var result:Array = new Array();
         var i:int = 0;
         while(i < arr.length)
         {
            if(result.indexOf(arr[i]) < 0)
            {
               result.push(arr[i]);
            }
            i++;
         }
         return result;
      }
      
      public function importCharacter(characterXML:XML) : void
      {
         var template:CharacterTemplate = null;
         var i:int = 0;
         if(characterXML != null)
         {
            while(characterXML.fighter[i] != null)
            {
               template = new CharacterTemplate();
               template.initByXML(characterXML.fighter[i]);
               this.characterObject[template.ID] = template;
               i++;
            }
         }
         System.disposeXML(characterXML);
         characterXML = null;
      }
      
      public function importStage(stageXML:XML) : void
      {
         var template:StageTemplate = null;
         var i:int = 0;
         if(stageXML != null)
         {
            while(stageXML.stage[i] != null)
            {
               template = new StageTemplate();
               template.initByXML(stageXML.stage[i]);
               this.stageObject[template.ID] = template;
               i++;
            }
         }
         System.disposeXML(stageXML);
         stageXML = null;
      }
      
      public function importMappings(data:Object) : void
      {
         if(data)
         {
            this.mappingsObject = data;
         }
         data = null;
      }
      
      public function getCharacter(id:String) : CharacterTemplate
      {
         return this.characterObject[id] as CharacterTemplate;
      }
      
      public function getAllCharacterBitmapFileURL() : Array
      {
         var id:String = null;
         var result:Array = new Array();
         var tmpChar:CharacterTemplate = null;
         for(id in this.characterObject)
         {
            tmpChar = this.characterObject[id];
            if(tmpChar)
            {
               if(tmpChar.CssURL != "")
               {
                  result.push(tmpChar.CssURL);
               }
               if(tmpChar.PortraitURL != "")
               {
                  result.push(tmpChar.PortraitURL);
               }
               if(tmpChar.FSCutinURL != "")
               {
                  result.push(tmpChar.FSCutinURL);
               }
            }
         }
         return noDuplicateArray(result);
      }
      
      public function getCharacterBitmap(id:String, bitmapType:int) : Bitmap
      {
         var result:Bitmap = null;
         var tmpChar:CharacterTemplate = this.getCharacter(id);
         if(tmpChar)
         {
            switch(bitmapType)
            {
               case CHARACTER_CSS:
                  result = this.getBitmap(tmpChar.CssURL);
                  break;
               case CHARACTER_PORTRAIT:
                  result = this.getBitmap(tmpChar.PortraitURL);
                  break;
               case CHARACTER_FS_CUTIN:
                  result = this.getBitmap(tmpChar.FSCutinURL);
            }
         }
         return result;
      }
      
      public function getStage(id:String) : StageTemplate
      {
         return this.stageObject[id] as StageTemplate;
      }
      
      public function getAllStageBitmapFileURL() : Array
      {
         var id:String = null;
         var result:Array = new Array();
         var tmpStage:StageTemplate = null;
         for(id in this.stageObject)
         {
            tmpStage = this.stageObject[id];
            if(tmpStage)
            {
               if(tmpStage.PreviewURL != "")
               {
                  result.push(tmpStage.PreviewURL);
               }
            }
         }
         return noDuplicateArray(result);
      }
      
      public function getStageBitmap(id:String) : Bitmap
      {
         var tmpStage:StageTemplate = this.getStage(id);
         var bmp:Bitmap = null;
         var small:BitmapData = null;
         var srcWidth:int = 0;
         var srcHeight:int = 0;
         if(tmpStage)
         {
            bmp = this.getBitmap(tmpStage.PreviewURL);
            if(bmp != null && bmp.bitmapData.width > STAGE_PREVIEW_WIDTH)
            {
               srcWidth = bmp.bitmapData.width;
               srcHeight = bmp.bitmapData.height;
               small = new BitmapData(STAGE_PREVIEW_WIDTH,int(Math.round(srcHeight * STAGE_PREVIEW_WIDTH / srcWidth)),true,0);
               small.draw(bmp.bitmapData,new Matrix(small.width / srcWidth,0,0,small.height / srcHeight),null,null,null,true);
               bmp.bitmapData.dispose();
               bmp = new Bitmap(small,"auto",true);
            }
            return bmp;
         }
         return null;
      }
      
      public function getStageBitmapHD(id:String) : Bitmap
      {
         var tmpStage:StageTemplate = this.getStage(id);
         var bmp:Bitmap = null;
         var s:Number = NaN;
         if(tmpStage)
         {
            bmp = this.getBitmap(tmpStage.PreviewURL);
            if(bmp != null)
            {
               bmp.smoothing = true;
               if(bmp.bitmapData.width > STAGE_PREVIEW_WIDTH)
               {
                  s = STAGE_PREVIEW_WIDTH / bmp.bitmapData.width;
                  bmp.scaleX = s;
                  bmp.scaleY = s;
               }
            }
            return bmp;
         }
         return null;
      }
      
      public function getMappings() : Object
      {
         return this.mappingsObject;
      }
      
      private function getBitmap(url:*) : Bitmap
      {
         var bitmapData:BitmapData = this.bitmapObject[url];
         if(bitmapData == null)
         {
            return null;
         }
         return new Bitmap(bitmapData.clone());
      }
      
      public function cacheBitmap(url:String, bitmap:DisplayObject) : void
      {
         var tmpBmp:Bitmap = bitmap as Bitmap;
         var tmpBmpData:* = null;
         if(!tmpBmp)
         {
            trace("BitmapAssetLoader.cacheBitmap Error");
            return;
         }
         if(tmpBmp)
         {
            try
            {
               tmpBmpData = tmpBmp.bitmapData;
            }
            catch(e:Error)
            {
               trace("BitmapAssetLoader.cacheBitmap Error::",e);
            }
         }
         if(tmpBmpData)
         {
            this.bitmapObject[url] = tmpBmpData;
         }
      }
      
      public function getCostumeObject() : Array
      {
         return this.costumeObject;
      }
      
      public function getMetalCostumeObject() : Object
      {
         return this.metalCostumeObject;
      }
      
      public function getInfoObject() : Object
      {
         return this.infoObject;
      }
      
      public function importCostume(character:String, data:Array) : void
      {
         var costume:Object = null;
         if(!this.costumeObject[character])
         {
            this.costumeObject[character] = data;
         }
         else
         {
            for each(costume in data)
            {
               this.costumeObject[character].push(costume);
            }
         }
      }
      
      public function importMetalCostume(character:String, metalObj:Object) : void
      {
         if(metalObj[character])
         {
            this.metalCostumeObject[character] = metalObj[character];
         }
      }
      
      public function importInfo(character:String, data:String) : void
      {
         if(!this.infoObject[character])
         {
            this.infoObject[character] = data;
         }
      }
      
      public function deleteAllData() : void
      {
         var key:String = null;
         for(key in this.characterObject)
         {
            this.characterObject[key] = null;
         }
         for(key in this.stageObject)
         {
            this.stageObject[key] = null;
         }
         for(key in this.bitmapObject)
         {
            BitmapData(this.bitmapObject[key]).dispose();
            this.bitmapObject[key] = null;
         }
         this.characterObject = new Object();
         this.stageObject = new Object();
         this.bitmapObject = new Object();
         this.mappingsObject = ResourceManager.getResourceByID("mappings").getProp("metadata");
         this.costumeObject = ResourceManager.getResourceByID("misc").getProp("metadata").costume_data;
         this.metalCostumeObject = ResourceManager.getResourceByID("misc").getProp("metadata").metal_costume_data;
         this.infoObject = ResourceManager.getResourceByID("misc_fmc_character").getProp("metadata").info;
      }
   }
}

