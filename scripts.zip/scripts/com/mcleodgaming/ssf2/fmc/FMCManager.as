package com.mcleodgaming.ssf2.fmc
{
   import com.mcleodgaming.ssf2.api.*;
   import com.mcleodgaming.ssf2.fmc.loader.*;
   import com.mcleodgaming.ssf2.fmc.template.CharacterTemplate;
   import com.mcleodgaming.ssf2.fmc.template.StageTemplate;
   import com.mcleodgaming.ssf2.net.*;
   import com.mcleodgaming.ssf2.util.*;
   import flash.display.Bitmap;
   import flash.utils.*;
   
   public class FMCManager
   {
      private static const ENABLE_TRACE:Boolean = false;
      
      private static var dataFMC:FMCData = new FMCData();
      
      public static const CHARACTER_COSTUME_FOLDER_URL:String = "assets/char_costume/";
      
      public static const CHARACTER_METAL_COSTUME_URL:String = "assets/char_costume/!MetalPalette.as";
      
      public function FMCManager()
      {
         super();
      }
      
      public static function init(successFunc:Function = null, processFunc:Function = null) : void
      {
         var trueSuccessFunc:Function = function():void
         {
            FMCManager.loadComplete();
            if(successFunc != null)
            {
               successFunc();
            }
         };
         FMCLoader.initLoad(trueSuccessFunc,processFunc);
      }
      
      private static function loadComplete() : void
      {
         var character:String = null;
         var characterList:Object = mergeObject(getMappings().character,getMappings().character_9b);
         var costumeFileName:Object = ResourceManager.getResourceByID("misc_fmc_character").getProp("metadata").costume_additional;
         var classicObject:Object = ResourceManager.getResourceByID("misc_fmc_character").getProp("metadata").classic_screen;
         var allStarObject:Object = ResourceManager.getResourceByID("misc_fmc_character").getProp("metadata").allstar_screen;
         var metalPaletteData:Object = new Object();
         var metalTextData:String = TextAssetLoader.loadSimple(CHARACTER_METAL_COSTUME_URL);
         if(metalTextData != null && metalTextData != "")
         {
            try
            {
               metalPaletteData = JSON.parse(metalTextData);
            }
            catch(e:SyntaxError)
            {
               MultiplayerManager.notify("[FMCManager]" + e.toString());
            }
         }
         else
         {
            MultiplayerManager.notify("[FMCManager] File " + CHARACTER_METAL_COSTUME_URL + " is not found, default metal costume will be used");
         }
         for(character in characterList)
         {
            FMCManager.addCostume(character,costumeFileName);
            FMCManager.addMetalCostume(character,metalPaletteData);
            FMCManager.addInfo(character);
            FMCManager.addCongrats(character,classicObject,allStarObject);
         }
         ResourceManager.getResourceByID("mappings").resetMappings();
      }
      
      public static function getCostumeObject() : Array
      {
         return dataFMC.getCostumeObject();
      }
      
      public static function getMetalCostumeObject() : Object
      {
         return dataFMC.getMetalCostumeObject();
      }
      
      public static function getInfoObject() : Object
      {
         return dataFMC.getInfoObject();
      }
      
      public static function getMappings() : Object
      {
         return dataFMC.getMappings();
      }
      
      public static function getCharacter(id:String) : CharacterTemplate
      {
         return dataFMC.getCharacter(id);
      }
      
      public static function getCharacterBitmap(id:String, bitmapType:int) : Bitmap
      {
         return dataFMC.getCharacterBitmap(id,bitmapType);
      }
      
      public static function getAllCharacterBitmapFileURL() : Array
      {
         return dataFMC.getAllCharacterBitmapFileURL();
      }
      
      public static function getAllStageBitmapFileURL() : Array
      {
         return dataFMC.getAllStageBitmapFileURL();
      }
      
      public static function getStage(id:String) : StageTemplate
      {
         return dataFMC.getStage(id);
      }
      
      public static function getStageBitmap(id:String) : Bitmap
      {
         return dataFMC.getStageBitmap(id);
      }
      
      public static function getStageBitmapHD(id:String) : Bitmap
      {
         return dataFMC.getStageBitmapHD(id);
      }
      
      public static function importCharacter(characterXML:XML) : void
      {
         dataFMC.importCharacter(characterXML);
      }
      
      public static function importStage(stageXML:XML) : void
      {
         dataFMC.importStage(stageXML);
      }
      
      public static function importMappings(mappings:Object) : void
      {
         dataFMC.importMappings(mappings);
      }
      
      public static function cacheBitmap(url:String, bitmap:Bitmap) : void
      {
         dataFMC.cacheBitmap(url,bitmap);
      }
      
      public static function deleteData() : void
      {
         dataFMC.deleteAllData();
      }
      
      private static function addCostume(character:String, costumeFileName:Object) : void
      {
         var costumeData:Array = null;
         var costumeURL:String = null;
         var costumeResult:String = null;
         if(getCharacter(character))
         {
            costumeURL = getCharacter(character).CostumeURL;
         }
         else if(costumeFileName[character] != null)
         {
            costumeURL = CHARACTER_COSTUME_FOLDER_URL.concat(costumeFileName[character]);
         }
         if(costumeURL != null && costumeURL != "")
         {
            costumeResult = TextAssetLoader.loadSimple(costumeURL);
            if(costumeResult != "")
            {
               costumeData = JSON.parse(costumeResult) as Array;
               if(costumeData)
               {
                  dataFMC.importCostume(character,costumeData);
                  if(ENABLE_TRACE)
                  {
                     trace("[FMC Manager] " + character + ": External costume added!");
                  }
               }
            }
         }
      }
      
      private static function addMetalCostume(character:String, metalObject:Object) : void
      {
         if(metalObject == null)
         {
            return;
         }
         dataFMC.importMetalCostume(character,metalObject);
      }
      
      private static function addInfo(character:String) : void
      {
         if(getCharacter(character))
         {
            if(getCharacter(character).CharInfo != "")
            {
               dataFMC.importInfo(character,getCharacter(character).CharInfo);
               if(ENABLE_TRACE)
               {
                  trace("[FMC Manager] " + character + ": External info added!");
               }
            }
         }
      }
      
      private static function addCongrats(character:String, classicObject:Object, allStarObject:Object) : void
      {
         if(classicObject[character])
         {
            SSF2API.setGlobalVar("congrats_" + character,classicObject[character]);
            if(ENABLE_TRACE)
            {
               trace("[FMC Manager] " + character + ": Internal classic congrats added");
            }
         }
         if(allStarObject[character])
         {
            SSF2API.setGlobalVar("allstar_congrats_" + character,allStarObject[character]);
            if(ENABLE_TRACE)
            {
               trace("[FMC Manager] " + character + ": Internal all-star congrats added");
            }
         }
      }
      
      private static function mergeObject(a:Object, b:Object) : Object
      {
         var p:String = null;
         var obj:Object = new Object();
         for(p in a)
         {
            obj[p] = a[p];
         }
         for(p in b)
         {
            obj[p] = b[p];
         }
         return obj;
      }
   }
}

