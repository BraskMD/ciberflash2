package com.mcleodgaming.ssf2.net
{
   import com.mcleodgaming.mgn.events.*;
   import com.mcleodgaming.mgn.net.*;
   import com.mcleodgaming.ssf2.*;
   import com.mcleodgaming.ssf2.audio.*;
   import com.mcleodgaming.ssf2.controllers.*;
   import com.mcleodgaming.ssf2.engine.*;
   import com.mcleodgaming.ssf2.enums.*;
   import com.mcleodgaming.ssf2.fmc.*;
   import com.mcleodgaming.ssf2.menus.*;
   import com.mcleodgaming.ssf2.modes.*;
   import com.mcleodgaming.ssf2.util.*;
   import flash.display.Bitmap;
   import flash.display.BitmapData;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.display.InteractiveObject;
   import flash.display.MovieClip;
   import flash.display.Shape;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.FocusEvent;
   import flash.events.KeyboardEvent;
   import flash.events.MouseEvent;
   import flash.events.TimerEvent;
   import flash.filters.DropShadowFilter;
   import flash.filters.GlowFilter;
   import flash.geom.Matrix;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.net.*;
   import flash.text.StaticText;
   import flash.text.TextField;
   import flash.text.TextFieldAutoSize;
   import flash.text.TextFieldType;
   import flash.text.TextFormat;
   import flash.text.TextLineMetrics;
   import flash.ui.Keyboard;
   import flash.utils.*;
   
   public class MultiplayerManager
   {
      private static var m_controllers:Vector.<Controller>;
      
      private static var m_notifier:MovieClip;
      
      private static var m_notifierText:TextField;
      
      private static var m_permanentBox:Boolean;
      
      private static var m_frameRateTimer:FrameTimer;
      
      private static var m_lastUpdate:Date;
      
      private static var m_pingCount:Number;
      
      private static var m_pingTotal:Number;
      
      private static var m_averagePing:Number;
      
      private static var m_frameRateIncremented:Boolean;
      
      private static var m_randomSeed:Number;
      
      private static var m_matchReady:Boolean;
      
      private static var m_matchEnded:Boolean;
      
      private static var m_roomData:Object;
      
      private static var m_promotionTimer:FrameTimer;
      
      private static var m_readyToLock:Boolean;
      
      private static var m_game:Game;
      
      private static var m_onlineInterface:MGNClient;
      
      private static var chat_panel:Sprite;
      
      private static var chat_bg:Sprite;
      
      private static var chat_log:TextField;
      
      private static var chat_input:TextField;
      
      private static var chat_timer:Timer;
      
      private static var pick_panel:Sprite;
      
      private static var pick_timer:Timer;
      
      private static var vs_logo:MovieClip;
      
      private static var vs_root:Sprite;
      
      private static var vs_items:Array;
      
      private static var vs_holdCb:Function;
      
      private static var vs_finishCb:Function;
      
      private static var vs_vsBox:Sprite;
      
      private static var vs_dots:TextField;
      
      private static var vt_ui:Sprite;
      
      private static var vt_layer:Sprite;
      
      private static var rm_game:Game;
      
      private static const FPS_THRESHOLD:int = 5;
      
      private static const FRAME_RATE_ADJUSTER:Boolean = false;
      
      public static var NORMAL_FPS:int = 30;
      
      public static var MAX_FPS:int = 35;
      
      public static var INPUT_BUFFER:int = 3;
      
      public static var joinRequestPlayerInfoQueue:Vector.<PlayerConnectionInfo> = new Vector.<PlayerConnectionInfo>();
      
      public static var ROOM_CAPACITY:int = 4;
      
      public static const ONLINE_MAXPLAYERS:int = 6;
      
      public static const CHAT_TOGGLE_KEY:int = 34;
      
      private static const CHAT_MAX_STORED:int = 60;
      
      private static const CHAT_MAX_CHARS:int = 120;
      
      private static const CHAT_SHOW_CLOSED:int = 6;
      
      private static const CHAT_SHOW_OPEN:int = 10;
      
      private static const CHAT_VISIBLE_MS:int = 8000;
      
      private static const CHAT_FADE_MS:int = 1500;
      
      private static const CHAT_PANEL_W:Number = 280;
      
      private static const CHAT_LOG_AREA_H:Number = 120;
      
      private static const CHAT_INPUT_H:Number = 16;
      
      private static const CHAT_MARGIN:Number = 6;
      
      private static const CHAT_FONT_SIZE:int = 9;
      
      private static var chat_inited:Boolean = false;
      
      private static var chat_open:Boolean = false;
      
      private static var chat_lines:Array = [];
      
      private static var chat_toggleReleased:Boolean = true;
      
      private static var chat_enterReleased:Boolean = true;
      
      private static var chat_restoreKeys:Boolean = false;
      
      private static var chat_lastText:String = null;
      
      private static var chat_lastOpen:Boolean = false;
      
      private static var chat_draft:String = "";
      
      private static var chat_refocusing:Boolean = false;
      
      private static const TYPING_HEARTBEAT_MS:int = 2000;
      
      private static const TYPING_EXPIRE_MS:int = 5000;
      
      private static const TYPING_NEEDS_TEXT:Boolean = false;
      
      private static var typing_self:Boolean = false;
      
      private static var typing_lastSent:int = 0;
      
      private static var typing_map:Object = {};
      
      private static const PICK_ROW_H:Number = 26;
      
      private static const PICK_ROW_GAP:Number = 3;
      
      private static const PICK_ICON_W:Number = 32;
      
      private static const PICK_BAND_W:Number = 148;
      
      private static const PICK_MAX_ROWS:int = 5;
      
      private static const PICK_MARGIN_RIGHT:Number = 8;
      
      private static const PICK_Y:Number = 218;
      
      private static const PICK_TICK_MS:int = 120;
      
      private static const PICK_OVERSAMPLE:int = 3;
      
      private static const PICK_TOP_CROP:Number = 0.25;
      
      private static var pick_inited:Boolean = false;
      
      private static var pick_map:Object = {};
      
      private static var pick_menu:* = null;
      
      private static var pick_cache:Object = {};
      
      private static var pick_sent:String = null;
      
      private static var pick_sig:String = "";
      
      private static var pick_colors:Array = [13641768,2646240,14727200,2664520];
      
      private static const SYNC_INTERVAL:int = 15;
      
      private static const SYNC_RING:int = 100;
      
      private static const SYNC_BACK:int = 45;
      
      private static var sync_ring:Array = [];
      
      private static var sync_checks:Object = {};
      
      private static var sync_peerChecks:Object = {};
      
      private static var sync_peerDetails:Object = {};
      
      private static var sync_myDetail:Array = null;
      
      private static var sync_reported:Boolean = false;
      
      private static var sync_matchId:String = "";
      
      private static var sync_firstFrame:int = -1;
      
      private static var sync_abortTimer:Timer = null;
      
      private static var sync_abortManual:Boolean = false;
      
      private static var sync_abortBy:String = "";
      
      private static var hold_start:Number = 0;
      
      private static var hold_warned:Boolean = false;
      
      private static const HOLD_ABORT_MS:int = 5000;
      
      private static var sync_fieldNames:Array = ["X","Y","X speed","Y speed","damage","state","facing","animation","attack","stocks"];
      
      private static const VS_MAX:int = 8;
      
      private static const VS_DEBUG:Boolean = true;
      
      private static const VS_ZOOM:Number = 1;
      
      private static const VS_BLEED:Number = 6;
      
      private static const VS_MAX_OVERFLOW:Number = 1.8;
      
      private static const VS_PORTRAIT_CX:Number = 0.3;
      
      private static var vs_lastFull:Boolean = false;
      
      private static const VS_LOGO_LINKAGE:String = "";
      
      private static var vs_vsStarted:Boolean = false;
      
      private static var vs_err:String = "";
      
      private static const VS_MIN_MS:int = 5000;
      
      private static const VS_ONLINE_HOLD_MS:int = 5000;
      
      private static const VS_COLORS:Array = [14170159,3108824,14922267,3123279,9323721,2078153,14710571,14243228];
      
      private static var vs_t0:int = 0;
      
      private static var vs_online:Boolean = false;
      
      private static var vs_want:Boolean = false;
      
      private static var vs_closeT:int = 0;
      
      private static var vs_vsT:int = 0;
      
      private static var vt_options:Array = [];
      
      private static var vt_votes:Object = {};
      
      private static var vt_sel:int = 0;
      
      private static var vt_keys:Boolean = false;
      
      private static var vt_shown:Boolean = false;
      
      private static var vt_thumbs:Object = {};
      
      private static var rm_votes:int = 0;
      
      private static var rm_total:int = 0;
      
      private static var rm_mine:Boolean = false;
      
      private static var rm_pending:Boolean = false;
      
      private static var rm_auto:Boolean = false;
      
      private static var rm_frames:int = 0;
      
      private static var spec_ui:Sprite = null;
      
      private static var spec_title:TextField = null;
      
      private static var spec_info:TextField = null;
      
      private static var spec_list:TextField = null;
      
      private static var spec_hint:TextField = null;
      
      private static var spec_room:String = "";
      
      private static var spec_players:Array = [];
      
      private static var spec_count:int = 0;
      
      private static var spec_inMatch:Boolean = false;
      
      private static var spec_keysOn:Boolean = false;
      
      private static var spec_chatWasOpen:Boolean = false;
      
      private static var spec_frameOn:Boolean = false;
      
      private static var spec_t0:int = 0;
      
      private static const SPEC_SYNC_TIMEOUT_MS:int = 90000;
      
      private static const SPEC_EXIT_HOLD_MS:int = 2000;
      
      public function MultiplayerManager()
      {
         super();
      }
      
      public static function init() : void
      {
         MGNEventManager.dispatcher.addEventListener(MGNEvent.NOTIFY,handlemgn_NOTIFY);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.PLAYER_JOINED,handlemgn_PLAYER_JOINED);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.PLAYER_LEFT,handlemgn_PLAYER_LEFT);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.DATA,handlemgn_DATA);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.MATCH_READY_STATUS,onMatchReadyStatus);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.MATCH_START,handlemgn_MATCH_START);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.MATCH_FINISHED,handlemgn_MATCH_FINISHED);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.MATCH_END,handlemgn_MATCH_END);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.DISCONNECT,handlemgn_DISCONNECT);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.ROOM_JOIN_REQUEST,onRoomJoinRequestReceived);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.ROOM_DATA,roomDataSet);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.ERROR_ROOM_DATA,roomDataSetError);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.LOCK_ROOM,onRoomLocked);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.ERROR_LOCK_ROOM,onRoomLockedError);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.UNLOCK_ROOM,onRoomUnlocked);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.ERROR_UNLOCK_ROOM,onRoomUnlockedError);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.ERROR_PING,onPingError);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.LEAVE_ROOM,onLeaveRoom);
         MGNEventManager.dispatcher.addEventListener("chat",handlemgn_CHAT);
         MGNEventManager.dispatcher.addEventListener("spectateJoined",handlemgn_SPECTATE_JOINED);
         MGNEventManager.dispatcher.addEventListener("spectatorJoin",handlemgn_SPECTATOR_JOIN);
         MGNEventManager.dispatcher.addEventListener("spectatorLeave",handlemgn_SPECTATOR_LEAVE);
         MGNEventManager.dispatcher.addEventListener("typing",handlemgn_TYPING);
         MGNEventManager.dispatcher.addEventListener("voteState",handlemgn_VOTESTATE);
         MGNEventManager.dispatcher.addEventListener("rematchState",handlemgn_REMATCHSTATE);
         MGNEventManager.dispatcher.addEventListener("rematchGo",handlemgn_REMATCHGO);
         chatInit();
         MGNEventManager.dispatcher.addEventListener("pick",handlemgn_PICK);
         pickInit();
         MGNEventManager.dispatcher.addEventListener("sync",handlemgn_SYNC);
         initializeMultiplayerManager();
         trace("MultiplayerManager initialized");
      }
      
      private static function initializeMultiplayerManager() : void
      {
         var i:int = 0;
         m_matchReady = false;
         m_matchEnded = false;
         m_roomData = null;
         m_permanentBox = false;
         m_controllers = new Vector.<Controller>();
         while(i < ONLINE_MAXPLAYERS)
         {
            m_controllers.push(new Controller(i + 1,SaveData.Controllers[i < SaveData.Controllers.length ? i : 0].getControls()));
            i++;
         }
         m_notifier = null;
         m_notifierText = null;
         m_onlineInterface = new MGNClient(ONLINE_MAXPLAYERS);
         m_frameRateTimer = new FrameTimer(30);
         m_promotionTimer = new FrameTimer(30 * 5);
         m_lastUpdate = null;
         m_pingCount = 0;
         m_pingTotal = 0;
         m_averagePing = 0;
         m_frameRateIncremented = true;
         m_randomSeed = 0;
         m_readyToLock = false;
         resetMasterFrame();
      }
      
      public static function get CurrentHostID() : String
      {
         return m_onlineInterface.CurrentHostID;
      }
      
      public static function get Username() : String
      {
         return m_onlineInterface.Username;
      }
      
      public static function get SocketID() : String
      {
         return m_onlineInterface.SocketID;
      }
      
      public static function get RoomList() : Array
      {
         return m_onlineInterface.RoomList;
      }
      
      public static function get MatchReady() : Boolean
      {
         return m_matchReady;
      }
      
      public static function get MatchEnded() : Boolean
      {
         return m_matchEnded;
      }
      
      public static function get RoomKey() : String
      {
         return m_onlineInterface.RoomKey;
      }
      
      public static function get RoomData() : Object
      {
         return m_roomData;
      }
      
      public static function get GameInstance() : Game
      {
         return m_game;
      }
      
      public static function get Controllers() : Vector.<Controller>
      {
         return m_controllers;
      }
      
      public static function get Ping() : Number
      {
         return Math.round(m_averagePing);
      }
      
      public static function get Connected() : Boolean
      {
         return m_onlineInterface.Connected;
      }
      
      public static function get Active() : Boolean
      {
         return m_onlineInterface.Active;
      }
      
      public static function set Active(value:Boolean) : void
      {
         m_onlineInterface.Active = value;
      }
      
      public static function get MasterFrame() : int
      {
         return m_onlineInterface.MasterFrame;
      }
      
      public static function set MasterFrame(value:int) : void
      {
         m_onlineInterface.MasterFrame = value;
      }
      
      public static function get PlayerID() : int
      {
         if(m_onlineInterface.IsSpectator && m_onlineInterface.PlayerID <= 0)
         {
            return 1;
         }
         return m_onlineInterface.PlayerID;
      }
      
      public static function get RoomLocked() : Boolean
      {
         return m_onlineInterface.RoomLocked;
      }
      
      public static function get IsHost() : Boolean
      {
         return m_onlineInterface.IsHost;
      }
      
      public static function get Protocol() : String
      {
         return m_onlineInterface.Protocol;
      }
      
      public static function set Protocol(value:String) : void
      {
         m_onlineInterface.Protocol = value;
      }
      
      public static function get DowngradedConnection() : Boolean
      {
         return m_onlineInterface.DowngradedConnection;
      }
      
      public static function downgradeP2P() : void
      {
         m_onlineInterface.downgradeP2P();
      }
      
      public static function get PromotionTimer() : FrameTimer
      {
         return m_promotionTimer;
      }
      
      public static function get Players() : Vector.<PlayerConnectionInfo>
      {
         return m_onlineInterface.Players;
      }
      
      public static function get PlayerSyncStream() : PlayerDataSyncStream
      {
         return m_onlineInterface.PlayerSyncStream;
      }
      
      public static function reset() : void
      {
         vsKill();
         vtClear();
         rm_pending = false;
         rm_mine = false;
         rm_votes = 0;
         rm_total = 0;
         rm_auto = false;
         m_roomData = null;
         m_matchReady = false;
         m_matchEnded = false;
         joinRequestPlayerInfoQueue.splice(0,joinRequestPlayerInfoQueue.length);
         m_onlineInterface.disconnect();
         initializeMultiplayerManager();
      }
      
      public static function resetMasterFrame() : void
      {
         var i:int = 0;
         m_onlineInterface.resetMasterFrame();
         while(i < m_onlineInterface.Players.length)
         {
            m_controllers[i].flushControlBits();
            i++;
         }
      }
      
      public static function restoreOriginalGameSettings(game:Game) : void
      {
         var i:int = 0;
         game.importSettings(GameController.onlineModeMatchSettings);
         game.GameMode = GameController.onlineModeMatchSettings.gameMode;
         var wasRandom:Boolean = game.PlayerSettings[0].isRandom;
         while(i < game.PlayerSettings.length)
         {
            game.PlayerSettings[i].isRandom = false;
            i++;
         }
         if(wasRandom)
         {
            game.PlayerSettings[0].character = "random";
         }
      }
      
      public static function resetSeed() : void
      {
         m_randomSeed = Utils.random();
      }
      
      public static function setSeed(seed:Number) : void
      {
         m_randomSeed = seed;
      }
      
      public static function notify(msg:String, permanentBox:Boolean = false) : void
      {
         if(m_notifier != null)
         {
            if(m_notifier.currentFrame === 1)
            {
               m_notifierText.text = "";
            }
            m_notifierText.appendText(" > " + msg + "\n");
            m_notifierText.scrollV = m_notifierText.numLines;
            m_notifier.gotoAndPlay("showmsg");
            if(Boolean(m_permanentBox) || permanentBox)
            {
               m_permanentBox = true;
               m_notifier.stop();
            }
         }
         trace(msg);
      }
      
      public static function makeNotifier() : void
      {
         if(m_notifier == null)
         {
            m_notifier = ResourceManager.getLibraryMC("onlineplay_notify");
            m_notifierText = m_notifier.txt_mc.txtbox;
            Main.Root.stage.addChild(m_notifier);
            m_notifier.x = Main.Width / 2;
            m_notifier.y = Main.Height;
         }
      }
      
      public static function connect(userName:String, password:String, version:String) : void
      {
         m_onlineInterface.connect(userName,password,version);
         MultiplayerManager.makeNotifier();
      }
      
      public static function disconnect() : void
      {
         m_onlineInterface.disconnect();
      }
      
      public static function ping() : void
      {
         m_onlineInterface.ping();
      }
      
      public static function createRoom(roomName:String, roomPassword:String, roomCapacity:int, roomData:Object) : void
      {
         ROOM_CAPACITY = ONLINE_MAXPLAYERS;
         m_onlineInterface.createRoom(roomName,roomPassword,ROOM_CAPACITY,roomData);
      }
      
      public static function requestToJoinRoom(roomKey:String, roomPassword:String) : void
      {
         m_onlineInterface.requestToJoinRoom(roomKey,roomPassword);
      }
      
      public static function createJoinRoom(roomName:String, roomPassword:String, roomCapacity:int, roomData:Object) : void
      {
         ROOM_CAPACITY = ONLINE_MAXPLAYERS;
         m_onlineInterface.createJoinRoom(roomName,roomPassword,ROOM_CAPACITY,roomData);
      }
      
      public static function lockRoom() : void
      {
         m_onlineInterface.lockRoom();
      }
      
      public static function unlockRoom() : void
      {
         m_onlineInterface.unlockRoom();
      }
      
      public static function leaveRoom() : void
      {
         m_onlineInterface.leaveRoom();
      }
      
      private static function roomDataSet(e:MGNEvent) : void
      {
         trace("Room data updated");
      }
      
      private static function roomDataSetError(e:MGNEvent) : void
      {
         trace("Error, problem updating room data");
      }
      
      private static function onRoomLocked(e:MGNEvent) : void
      {
         trace("Room locked successfully.");
         m_readyToLock = false;
      }
      
      private static function onRoomLockedError(e:MGNEvent) : void
      {
         MultiplayerManager.notify("There was a problem locking the room.");
         m_readyToLock = false;
      }
      
      private static function onRoomUnlocked(e:MGNEvent) : void
      {
         trace("Room unlocked successfully.");
         m_readyToLock = false;
      }
      
      private static function onRoomUnlockedError(e:MGNEvent) : void
      {
         MultiplayerManager.notify("There was a problem unlocking the room.");
         m_readyToLock = false;
      }
      
      private static function onPingError(e:MGNEvent) : void
      {
         reset();
         MenuController.removeAllMenus();
         MenuController.onlineMenu.show();
         SoundQueue.instance.playMusic("menumusic",0);
      }
      
      private static function onLeaveRoom(e:MGNEvent) : void
      {
         var wasSpec:Boolean = spec_ui != null && spec_ui.parent != null;
         m_roomData = null;
         m_matchReady = false;
         m_matchEnded = false;
         specStopFrame();
         if(wasSpec)
         {
            specHide();
            MenuController.onlineMenu.show();
         }
      }
      
      public static function refreshRoomList(friendsOnly:Boolean = false) : void
      {
         m_onlineInterface.refreshRoomList(friendsOnly);
      }
      
      public static function sendMyDataFrame(frame:int, data:Object) : void
      {
         m_onlineInterface.sendMyDataFrame(frame,data);
      }
      
      public static function sendMatchReadySignal(data:Object) : void
      {
         m_onlineInterface.sendMatchReadySignal(data);
      }
      
      public static function sendMatchFinishedSignal(data:Object) : void
      {
         m_onlineInterface.sendMatchFinishedSignal(data);
      }
      
      public static function sendMatchAbortSignal() : void
      {
         m_onlineInterface.sendMatchAbortSignal();
      }
      
      public static function sendMatchEndSignal() : void
      {
         m_onlineInterface.sendMatchEndSignal();
      }
      
      public static function sendMatchSettings(data:Object) : void
      {
         m_onlineInterface.sendMatchSettings(data);
      }
      
      public static function onRoomJoinRequestReceived(e:MGNEvent) : void
      {
         MultiplayerManager.handleRoomJoinRequest(e.data.playerConnectionInfo);
      }
      
      public static function handleRoomJoinRequest(playerInfo:PlayerConnectionInfo) : void
      {
         var i:int = 0;
         if(RoomLocked || m_onlineInterface.Players.length >= MultiplayerManager.ROOM_CAPACITY)
         {
            m_onlineInterface.declineRoomJoinRequest(playerInfo);
         }
         else
         {
            while(i < m_onlineInterface.Players.length)
            {
               if(m_onlineInterface.Players[i].socket_id == playerInfo.socket_id)
               {
                  return;
               }
               i++;
            }
            SoundQueue.instance.playSoundEffect("menu_unlock");
            m_onlineInterface.acceptRoomJoinRequest(playerInfo);
         }
      }
      
      public static function acceptRoomJoinRequest() : void
      {
         m_onlineInterface.acceptRoomJoinRequest(MenuController.onlinePromptMenu.data as PlayerConnectionInfo);
         MenuController.onlinePromptMenu.removeSelf();
         if(MultiplayerManager.joinRequestPlayerInfoQueue.length > 0)
         {
            setTimeout(function():void
            {
               MultiplayerManager.handleRoomJoinRequest(MultiplayerManager.joinRequestPlayerInfoQueue.splice(0,1)[0]);
            },2000);
         }
      }
      
      public static function declineRoomJoinRequest() : void
      {
         m_onlineInterface.declineRoomJoinRequest(MenuController.onlinePromptMenu.data as PlayerConnectionInfo);
         MenuController.onlinePromptMenu.removeSelf();
         if(MultiplayerManager.joinRequestPlayerInfoQueue.length > 0)
         {
            setTimeout(function():void
            {
               MultiplayerManager.handleRoomJoinRequest(MultiplayerManager.joinRequestPlayerInfoQueue.splice(0,1)[0]);
            },2000);
         }
      }
      
      private static function updateControls() : void
      {
         var updated:Boolean = false;
         var i:int = 0;
         var currentUpdate:Date = null;
         var updatedPing:Number = NaN;
         var averagePing:Number = NaN;
         if(Boolean(m_onlineInterface.Active) && Boolean(m_onlineInterface.Connected))
         {
            updated = false;
            while(m_onlineInterface.ControlBits[0].length > 0)
            {
               updated = true;
               i = 0;
               while(i < m_onlineInterface.Players.length)
               {
                  m_controllers[i].queueControlBits(m_onlineInterface.ControlBits[i][0]);
                  m_onlineInterface.ControlBits[i].splice(0,1);
                  i++;
               }
            }
            m_frameRateTimer.tick();
            m_promotionTimer.tick();
            if(updated)
            {
               if(MultiplayerManager.INPUT_BUFFER === 0)
               {
                  if(MultiplayerManager.IsHost)
                  {
                     if(Main.Root.stage.frameRate != 60)
                     {
                        Main.Root.stage.frameRate = 60;
                     }
                  }
                  else if(Main.Root.stage.frameRate != 60)
                  {
                     Main.Root.stage.frameRate = 60;
                  }
               }
               if(!m_lastUpdate)
               {
                  m_lastUpdate = new Date();
                  m_averagePing = 1000 / MultiplayerManager.NORMAL_FPS;
                  m_pingTotal = m_averagePing;
                  m_pingCount = 1;
               }
               else
               {
                  currentUpdate = new Date();
                  updatedPing = currentUpdate.time - m_lastUpdate.time;
                  m_lastUpdate.setTime(currentUpdate.getTime());
                  ++m_pingCount;
                  m_pingTotal += updatedPing;
                  if(m_frameRateTimer.IsComplete)
                  {
                     m_frameRateTimer.reset();
                     averagePing = m_pingTotal / m_pingCount;
                     if(MultiplayerManager.FRAME_RATE_ADJUSTER)
                     {
                        if(averagePing > 1000 / MultiplayerManager.NORMAL_FPS)
                        {
                           if(averagePing < 1000 / (MultiplayerManager.NORMAL_FPS + MultiplayerManager.FPS_THRESHOLD) && Main.Root.stage.frameRate > MultiplayerManager.NORMAL_FPS)
                           {
                              m_frameRateIncremented = false;
                              --Main.Root.stage.frameRate;
                           }
                           else if(averagePing < m_averagePing + 2)
                           {
                              if(Boolean(m_frameRateIncremented) && Main.Root.stage.frameRate < MultiplayerManager.MAX_FPS)
                              {
                                 ++Main.Root.stage.frameRate;
                              }
                              else if(!m_frameRateIncremented && Main.Root.stage.frameRate > MultiplayerManager.NORMAL_FPS)
                              {
                                 --Main.Root.stage.frameRate;
                              }
                           }
                           else
                           {
                              m_frameRateIncremented = !m_frameRateIncremented;
                              if(Boolean(m_frameRateIncremented) && Main.Root.stage.frameRate < MultiplayerManager.MAX_FPS)
                              {
                                 ++Main.Root.stage.frameRate;
                              }
                              else if(!m_frameRateIncremented && Main.Root.stage.frameRate > MultiplayerManager.NORMAL_FPS)
                              {
                                 --Main.Root.stage.frameRate;
                              }
                           }
                        }
                     }
                     if(Main.DEBUG && MenuController.debugConsole && Boolean(MenuController.debugConsole.PingCapture))
                     {
                        MultiplayerManager.notify(Ping + " ms (" + m_onlineInterface.getFrameDelay() + ")");
                     }
                     m_averagePing = averagePing;
                     m_pingCount = 0;
                     m_pingTotal = 0;
                  }
               }
            }
         }
      }
      
      private static function handlemgn_PLAYER_JOINED(e:MGNEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_unlock");
         if(e.data.is_dev)
         {
            MultiplayerManager.notify("+ " + e.data.username + " has joined the match.");
         }
         else
         {
            MultiplayerManager.notify(e.data.username + " has joined the match.");
         }
      }
      
      private static function handlemgn_PLAYER_LEFT(e:MGNEvent) : void
      {
         if(e.data.is_dev)
         {
            MultiplayerManager.notify("+ " + e.data.username + " has disconnected.");
         }
         else
         {
            MultiplayerManager.notify(e.data.username + " has disconnected.");
         }
         m_matchReady = false;
         if(e.data.host)
         {
            MultiplayerManager.leaveRoom();
         }
         else if(Boolean(MultiplayerManager.RoomLocked) && Boolean(m_onlineInterface.IsHost))
         {
            MultiplayerManager.unlockRoom();
         }
      }
      
      private static function handlemgn_NOTIFY(e:MGNEvent) : void
      {
         MultiplayerManager.notify(e.data.message);
      }
      
      private static function handlemgn_DATA(e:MGNEvent) : void
      {
      }
      
      private static function onMatchReadyStatus(e:MGNEvent) : void
      {
      }
      
      private static function handlemgn_MATCH_START(e:MGNEvent) : void
      {
         var lastTeam:int = 0;
         var foundTeams:Array = null;
         var numTeams:int = 0;
         var possibleTeams:Array = null;
         var i:int = 0;
         var j:int = 0;
         var k:int = 0;
         m_matchEnded = false;
         if(IsSpectator && e.data.room_data.matchSettings.gameMode === Mode.ONLINE_ARENA)
         {
            notify("Las salas Arena no se pueden espectar.");
            specLeave();
            return;
         }
         if(Boolean(GameController.currentGame) && Boolean(GameController.currentGame.SuddenDeath))
         {
            m_matchReady = true;
            return;
         }
         vtClear();
         rm_pending = false;
         m_roomData = {};
         m_roomData.matchSettings = e.data.room_data.matchSettings;
         m_roomData.matchSettings.playerSettings = [];
         var playerSettings:Array = m_roomData.matchSettings.playerSettings;
         MultiplayerManager.INPUT_BUFFER = m_roomData.matchSettings.levelData.inputBuffer;
         if(MultiplayerManager.INPUT_BUFFER === 0)
         {
            MultiplayerManager.notify("Automated input buffer enabled.");
         }
         m_onlineInterface.PlayerID = 0;
         var playerData:Array = e.data.player_data;
         i = 0;
         while(i < playerData.length)
         {
            playerSettings.push(playerData[i].data.playerSettings);
            if(playerData[i].data.playerSettings.socket_id === m_onlineInterface.SocketID)
            {
               m_onlineInterface.PlayerID = i + 1;
            }
            i++;
         }
         if(m_roomData.matchSettings.levelData.unlocks.alternate_tracks)
         {
            ResourceManager.FORCE_ENABLE_ALT_TRACKS = true;
         }
         Utils.setRandSeed(m_roomData.matchSettings.levelData.randSeed);
         Utils.shuffleRandom();
         Main.prepRandomCharacters(playerSettings.length);
         ResourceManager.queueResources([m_roomData.matchSettings.levelData.stage]);
         if(m_roomData.matchSettings.levelData.teams)
         {
            lastTeam = -1;
            foundTeams = new Array();
            numTeams = 0;
            possibleTeams = m_roomData.matchSettings.gameMode === Mode.ONLINE_ARENA ? [1,3] : [1,2,3];
            i = 0;
            while(i < playerSettings.length)
            {
               if(possibleTeams.indexOf(playerSettings[i].team) < 0)
               {
                  if(lastTeam < 0)
                  {
                     playerSettings[i].team = 1;
                     lastTeam = 1;
                     foundTeams[lastTeam] = true;
                     numTeams++;
                  }
                  else
                  {
                     playerSettings[i].team = lastTeam;
                     if(!foundTeams[lastTeam])
                     {
                        numTeams++;
                     }
                     foundTeams[lastTeam] = true;
                  }
               }
               else
               {
                  if(!foundTeams[playerSettings[i].team])
                  {
                     numTeams++;
                  }
                  lastTeam = int(playerSettings[i].team);
                  foundTeams[lastTeam] = true;
               }
               i++;
            }
            if(numTeams <= 1)
            {
               i = 0;
               while(i < playerSettings.length)
               {
                  if(possibleTeams.indexOf(playerSettings[i].team) >= 0)
                  {
                     possibleTeams.splice(possibleTeams.indexOf(playerSettings[i].team),1);
                  }
                  if(i == playerSettings.length - 1)
                  {
                     playerSettings[i].team = possibleTeams[0];
                  }
                  i++;
               }
            }
         }
         i = 0;
         while(i < playerSettings.length)
         {
            playerSettings[i].lives = m_roomData.matchSettings.levelData.lives;
            playerSettings[i].damageRatio = m_roomData.matchSettings.levelData.damageRatio;
            playerSettings[i].finalSmashMeter = m_roomData.matchSettings.levelData.finalSmashMeter;
            playerSettings[i].startDamage = m_roomData.matchSettings.levelData.startDamage;
            if(playerSettings[i].character != null && playerSettings[i].character != "xp")
            {
               ResourceManager.queueResources([playerSettings[i].character == "random" ? Main.RandCharList[i].StatsName : playerSettings[i].character]);
            }
            i++;
         }
         MultiplayerManager.m_game = new Game();
         MultiplayerManager.GameInstance.GameMode = Mode.ONLINE;
         MultiplayerManager.GameInstance.importSettings(MultiplayerManager.RoomData.matchSettings);
         if(m_roomData.matchSettings.gameMode === Mode.ONLINE_ARENA)
         {
            MultiplayerManager.GameInstance.GameMode = Mode.ONLINE_ARENA;
            MultiplayerManager.GameInstance.CustomModeObj = new ArenaMode(MultiplayerManager.GameInstance,{"arenaModeID":m_roomData.matchSettings.arenaModeID},{"classAPI":ResourceManager.getResourceByID("arena_mode").getProp("mode")});
            MultiplayerManager.m_game = MultiplayerManager.GameInstance.CustomModeObj.GameInstance;
            ResourceManager.queueResources([MultiplayerManager.GameInstance.LevelData.stage]);
         }
         if(m_roomData.matchSettings.levelData.musicOverride)
         {
            ResourceManager.queueResources([m_roomData.matchSettings.levelData.musicOverride]);
         }
         vsShow(playerSettings,true);
         ResourceManager.load({"oncomplete":onMatchReady});
         if(IsSpectator)
         {
            specBeginMatch();
         }
      }
      
      private static function onMatchReady() : void
      {
         vsHold(vsSetMatchReady);
      }
      
      private static function handlemgn_MATCH_END(e:MGNEvent) : void
      {
         m_matchEnded = true;
      }
      
      private static function handlemgn_DISCONNECT(e:MGNEvent) : void
      {
         var wasSpec:Boolean = spec_ui != null && spec_ui.parent != null;
         specStopFrame();
         specHide();
         reset();
         if(wasSpec)
         {
            MenuController.onlineMenu.show();
         }
      }
      
      private static function handlemgn_MATCH_FINISHED(e:MGNEvent) : void
      {
         vsKill();
         m_matchReady = false;
         if(IsSpectator)
         {
            spec_inMatch = false;
            specRefresh();
         }
         trace("Match end signal received from other player.");
      }
      
      public static function toWaitingRoom(game:Game, callback:Function) : void
      {
         game.LevelData.randSeed = Math.round(Math.random() * 1000000 + 1);
         game.PlayerSettings[0].socket_id = m_onlineInterface.SocketID;
         GameController.onlineModeMatchSettings = game.exportSettings();
         GameController.onlineModeMatchSettings.gameMode = game.GameMode;
         GameController.onlineModeMatchSettings.arenaModeID = ArenaModeMenu.SELECTED_ARENA_MODE;
         if(IsHost)
         {
            voteHostInit(String(game.LevelData.stage));
         }
         game.GameMode = Mode.ONLINE_WAITING_ROOM;
         game.LevelData.stage = "waitingroom";
         game.LevelData.usingLives = false;
         game.LevelData.usingTime = false;
         game.LevelData.usingStamina = false;
         game.LevelData.teams = false;
         game.LevelData.showEntrances = false;
         game.PlayerSettings.push(new PlayerSetting());
         game.PlayerSettings[1].exist = true;
         game.PlayerSettings[1].character = "sandbag";
         game.PlayerSettings[0].team = -1;
         game.PlayerSettings[1].team = -1;
         Utils.setRandSeed(game.LevelData.randSeed);
         Utils.shuffleRandom();
         Main.prepRandomCharacters(game.PlayerSettings.length);
         if(game.PlayerSettings[0].character == "random")
         {
            GameController.onlineModeMatchSettings.playerSettings[0].character = Main.RandCharList[0].StatsName;
            game.PlayerSettings[0].character = GameController.onlineModeMatchSettings.playerSettings[0].character;
            game.PlayerSettings[0].isRandom = true;
            GameController.onlineModeMatchSettings.playerSettings[0].isRandom = true;
         }
         ResourceManager.queueResources([game.LevelData.stage]);
         ResourceManager.queueResources(["sandbag"]);
         var i:int = 1;
         while(i <= game.PlayerSettings.length)
         {
            if(game.PlayerSettings[i - 1] && game.PlayerSettings[i - 1].exist && game.PlayerSettings[i - 1].character != null && game.PlayerSettings[i - 1].character != "xp")
            {
               ResourceManager.queueResources([game.PlayerSettings[i - 1].character == "random" ? Main.RandCharList[i - 1].StatsName : game.PlayerSettings[i - 1].character]);
            }
            i++;
         }
         ResourceManager.load({"oncomplete":callback});
      }
      
      public static function PERFORMALL() : void
      {
         if(Active)
         {
            m_onlineInterface.PERFORMALL();
            updateControls();
            abortHoldTick();
         }
      }
      
      private static function abortHoldTick() : void
      {
         var sd:* = GameController.stageData;
         var c:Controller = null;
         var held:Boolean = false;
         var ms:Number = 0;
         if(sd != null && Boolean(sd.OnlineMode) && !sd.WasReset && !MatchEnded && (sync_matchId != "" || IsSpectator) && (MasterFrame >= 4 || IsSpectator) && sync_abortTimer == null && !chat_open && SaveData.Controllers != null && SaveData.Controllers.length > 0)
         {
            c = SaveData.Controllers[0];
            held = c != null && c.IsDown(c._START);
         }
         if(!held)
         {
            hold_start = 0;
            hold_warned = false;
            return;
         }
         if(hold_start == 0)
         {
            hold_start = getTimer();
            return;
         }
         ms = getTimer() - hold_start;
         if(ms >= 1000 && !hold_warned)
         {
            hold_warned = true;
            notify(IsSpectator ? "Manten START para salir de la sala..." : "Manten START para abortar la partida...");
         }
         if(ms >= (IsSpectator ? SPEC_EXIT_HOLD_MS : HOLD_ABORT_MS))
         {
            hold_start = 0;
            hold_warned = false;
            if(IsSpectator)
            {
               specExitMatch();
            }
            else
            {
               syncScheduleAbort(true,true,Username);
            }
         }
      }
      
      public static function get ChatOpen() : Boolean
      {
         return chat_open;
      }
      
      public static function get IsSpectator() : Boolean
      {
         return m_onlineInterface != null && Boolean(m_onlineInterface.IsSpectator);
      }
      
      public static function spectateRoom(roomKey:String, roomPassword:String) : void
      {
         m_onlineInterface.spectateRoom(roomKey,roomPassword);
      }
      
      private static function handlemgn_SPECTATE_JOINED(e:MGNEvent) : void
      {
         spec_room = String(e.data.room_name);
         spec_players = e.data.players != null ? e.data.players as Array : [];
         spec_count = 1;
         spec_inMatch = e.data.in_match == 1 || e.data.in_match === true;
         specShow();
         notify("Estas espectando la sala " + spec_room + ".");
      }
      
      private static function handlemgn_SPECTATOR_JOIN(e:MGNEvent) : void
      {
         spec_count = int(e.data.total);
         notify(String(e.data.username) + " esta espectando.");
         specRefresh();
      }
      
      private static function handlemgn_SPECTATOR_LEAVE(e:MGNEvent) : void
      {
         spec_count = int(e.data.total);
         notify(String(e.data.username) + " dejo de espectar.");
         specRefresh();
      }
      
      private static function specMakeText(size:int, color:uint, bold:Boolean) : TextField
      {
         var tf:TextField = new TextField();
         tf.defaultTextFormat = new TextFormat("_sans",size,color,bold);
         tf.selectable = false;
         tf.mouseEnabled = false;
         tf.multiline = true;
         tf.autoSize = TextFieldAutoSize.LEFT;
         return tf;
      }
      
      private static function specShow() : void
      {
         if(spec_ui == null)
         {
            spec_ui = new Sprite();
            spec_ui.mouseEnabled = false;
            spec_title = specMakeText(26,16777215,true);
            spec_info = specMakeText(13,14148588,false);
            spec_list = specMakeText(13,16763238,false);
            spec_hint = specMakeText(11,10465220,false);
            spec_ui.addChild(spec_title);
            spec_ui.addChild(spec_info);
            spec_ui.addChild(spec_list);
            spec_ui.addChild(spec_hint);
         }
         spec_ui.graphics.clear();
         spec_ui.graphics.beginFill(731670);
         spec_ui.graphics.drawRect(0,0,Main.Width,Main.Height);
         spec_ui.graphics.endFill();
         spec_ui.graphics.beginFill(3055835);
         spec_ui.graphics.drawRect(0,0,8,Main.Height);
         spec_ui.graphics.endFill();
         spec_title.text = "ESPECTANDO";
         spec_title.x = 28;
         spec_title.y = 20;
         if(spec_ui.parent != Main.Root)
         {
            Main.Root.addChild(spec_ui);
         }
         else
         {
            Main.Root.setChildIndex(spec_ui,Main.Root.numChildren - 1);
         }
         spec_ui.visible = true;
         if(!spec_keysOn)
         {
            Main.Root.stage.addEventListener(KeyboardEvent.KEY_DOWN,specPreKey,false,200);
            Main.Root.stage.addEventListener(KeyboardEvent.KEY_DOWN,specOnKey,false,90);
            spec_keysOn = true;
         }
         specRefresh();
      }
      
      private static function specRefresh() : void
      {
         if(spec_ui == null || spec_ui.parent == null)
         {
            return;
         }
         spec_info.text = spec_inMatch ? "Hay una partida en curso.\nEmpezaras a verla en la siguiente, desde el principio." : "Esperando a que empiece la partida...";
         spec_info.x = 28;
         spec_info.y = 64;
         spec_list.text = "Sala: " + spec_room + "\nJugadores: " + (spec_players.length > 0 ? spec_players.join("   vs   ") : "...") + "\nEspectadores: " + spec_count;
         spec_list.x = 28;
         spec_list.y = 112;
         spec_hint.text = "ESC: salir de la sala\nAV PAG: chat";
         spec_hint.x = Main.Width - spec_hint.width - 16;
         spec_hint.y = 22;
      }
      
      private static function specHide() : void
      {
         if(spec_ui != null && spec_ui.parent != null)
         {
            spec_ui.parent.removeChild(spec_ui);
         }
         if(spec_keysOn)
         {
            Main.Root.stage.removeEventListener(KeyboardEvent.KEY_DOWN,specPreKey);
            Main.Root.stage.removeEventListener(KeyboardEvent.KEY_DOWN,specOnKey);
            spec_keysOn = false;
         }
      }
      
      private static function specPreKey(e:KeyboardEvent) : void
      {
         spec_chatWasOpen = chat_open;
      }
      
      private static function specOnKey(e:KeyboardEvent) : void
      {
         if(e.keyCode == 27 && !spec_chatWasOpen && spec_ui != null && spec_ui.parent != null)
         {
            specLeave();
         }
      }
      
      public static function specLeave() : void
      {
         if(IsSpectator)
         {
            m_onlineInterface.leaveRoom();
         }
      }
      
      public static function specReturn() : void
      {
         spec_inMatch = false;
         specStopFrame();
         vsKill();
         specShow();
         SoundQueue.instance.playMusic("menumusic",0);
      }
      
      private static function specBeginMatch() : void
      {
         specHide();
         spec_t0 = getTimer();
         if(!spec_frameOn)
         {
            Main.Root.stage.addEventListener(Event.ENTER_FRAME,specOnFrame);
            spec_frameOn = true;
         }
      }
      
      private static function specStopFrame() : void
      {
         if(spec_frameOn)
         {
            Main.Root.stage.removeEventListener(Event.ENTER_FRAME,specOnFrame);
            spec_frameOn = false;
         }
      }
      
      private static function specOnFrame(e:Event) : void
      {
         if(!IsSpectator || !InRoom)
         {
            specStopFrame();
            return;
         }
         if(!m_matchReady)
         {
            if(getTimer() - spec_t0 > SPEC_SYNC_TIMEOUT_MS * 2)
            {
               specStopFrame();
               notify("No se pudo cargar la partida. Esperando la siguiente...");
               specReturn();
            }
            return;
         }
         m_onlineInterface.Active = true;
         if(m_onlineInterface.PlayerSyncStream.Pointer > 2)
         {
            specStopFrame();
            GameController.startMatch(GameInstance);
         }
         else if(getTimer() - spec_t0 > SPEC_SYNC_TIMEOUT_MS)
         {
            specStopFrame();
            notify("No se pudo sincronizar con la partida. Esperando la siguiente...");
            specReturn();
         }
      }
      
      private static function specExitMatch() : void
      {
         var sd:* = GameController.stageData;
         m_onlineInterface.leaveRoom();
         if(sd != null && !sd.WasReset)
         {
            try
            {
               sd.endGame(true);
            }
            catch(err:Error)
            {
            }
         }
      }
      
      public static function chatInit() : void
      {
         if(chat_inited)
         {
            return;
         }
         chat_inited = true;
         var fmt:TextFormat = new TextFormat("_sans",CHAT_FONT_SIZE,16777215);
         chat_panel = new Sprite();
         chat_panel.mouseEnabled = false;
         chat_panel.mouseChildren = false;
         chat_panel.visible = false;
         chat_bg = new Sprite();
         chat_bg.mouseEnabled = false;
         chat_panel.addChild(chat_bg);
         chat_log = new TextField();
         chat_log.defaultTextFormat = fmt;
         chat_log.multiline = true;
         chat_log.wordWrap = true;
         chat_log.selectable = false;
         chat_log.mouseEnabled = false;
         chat_log.x = 4;
         chat_log.width = CHAT_PANEL_W - 8;
         chat_log.autoSize = TextFieldAutoSize.LEFT;
         chat_panel.addChild(chat_log);
         chat_input = new TextField();
         chat_input.defaultTextFormat = fmt;
         chat_input.type = TextFieldType.INPUT;
         chat_input.multiline = false;
         chat_input.maxChars = CHAT_MAX_CHARS;
         chat_input.border = true;
         chat_input.borderColor = 9474192;
         chat_input.background = true;
         chat_input.backgroundColor = 2105376;
         chat_input.width = CHAT_PANEL_W;
         chat_input.height = CHAT_INPUT_H;
         chat_input.y = CHAT_LOG_AREA_H + 2;
         chat_input.visible = false;
         chat_input.addEventListener(FocusEvent.FOCUS_OUT,chatOnFocusOut);
         chat_panel.addChild(chat_input);
         chat_panel.x = CHAT_MARGIN;
         chat_panel.y = Main.Height - CHAT_MARGIN - (CHAT_LOG_AREA_H + 2 + CHAT_INPUT_H);
         Main.Root.stage.addEventListener(KeyboardEvent.KEY_DOWN,voteOnKey,false,101);
         Main.Root.stage.addEventListener(KeyboardEvent.KEY_DOWN,chatOnKeyDown,false,100);
         Main.Root.stage.addEventListener(KeyboardEvent.KEY_UP,chatOnKeyUp,false,100);
         chat_timer = new Timer(250);
         chat_timer.addEventListener(TimerEvent.TIMER,chatOnTick);
         chat_timer.start();
      }
      
      public static function chatReceive(from:String, text:String) : void
      {
         if(!chat_inited)
         {
            return;
         }
         var clean:String = text.replace(/[\x00-\x1f]/g,"");
         if(clean.length > 200)
         {
            clean = clean.substr(0,200);
         }
         chat_lines.push({
            "t":from + ": " + clean,
            "at":getTimer()
         });
         while(chat_lines.length > CHAT_MAX_STORED)
         {
            chat_lines.shift();
         }
         chatRefresh(true);
      }
      
      private static function chatOnKeyDown(e:KeyboardEvent) : void
      {
         if(e.keyCode == CHAT_TOGGLE_KEY)
         {
            if(chat_open || InRoom)
            {
               if(chat_toggleReleased)
               {
                  chat_toggleReleased = false;
                  if(chat_open)
                  {
                     chatClose();
                  }
                  else
                  {
                     chatOpen();
                  }
               }
               e.stopImmediatePropagation();
            }
            return;
         }
         if(!chat_open)
         {
            return;
         }
         if(e.keyCode == Keyboard.ESCAPE)
         {
            chatClose();
         }
         else if(e.keyCode == Keyboard.ENTER)
         {
            if(chat_enterReleased)
            {
               chat_enterReleased = false;
               chatSubmit();
            }
         }
         e.stopImmediatePropagation();
      }
      
      private static function chatOnKeyUp(e:KeyboardEvent) : void
      {
         if(e.keyCode == CHAT_TOGGLE_KEY)
         {
            chat_toggleReleased = true;
         }
         if(e.keyCode == Keyboard.ENTER)
         {
            chat_enterReleased = true;
         }
      }
      
      private static function chatOpen() : void
      {
         if(chat_open || chatLoading() || vt_ui != null)
         {
            return;
         }
         chat_open = true;
         chat_panel.mouseChildren = true;
         chat_input.visible = true;
         chat_input.text = chat_draft;
         chat_restoreKeys = Key.CaptureStarted;
         if(chat_restoreKeys)
         {
            Key.endCapture();
         }
         Main.setFocus(chat_input);
         chat_input.setSelection(chat_input.text.length,chat_input.text.length);
         typingUpdate();
         chatRefresh(true);
      }
      
      private static function chatClose() : void
      {
         if(!chat_open)
         {
            return;
         }
         chat_draft = chat_input.text;
         chat_open = false;
         typingUpdate();
         chat_panel.mouseChildren = false;
         chat_input.visible = false;
         Main.fixFocus();
         if(chat_restoreKeys)
         {
            Key.beginCapture(Main.Root.stage);
            chat_restoreKeys = false;
         }
         chatRefresh(true);
      }
      
      private static function chatSubmit() : void
      {
         var t:String = chat_input.text.replace(/^\s+|\s+$/g,"");
         chat_input.text = "";
         if(t.length > CHAT_MAX_CHARS)
         {
            t = t.substr(0,CHAT_MAX_CHARS);
         }
         if(t.length > 0)
         {
            sendChat(t);
         }
         chatClose();
      }
      
      private static function chatOnTick(e:TimerEvent) : void
      {
         if(!InRoom)
         {
            if(chat_open)
            {
               chatClose();
            }
            if(chat_lines.length > 0)
            {
               chat_lines = [];
               chatRefresh(true);
            }
            chat_panel.visible = false;
            chat_draft = "";
            typing_map = {};
            typing_self = false;
            return;
         }
         var host:DisplayObjectContainer = Main.Root;
         if(chat_panel.parent != host)
         {
            host.addChild(chat_panel);
         }
         else if(host.getChildIndex(chat_panel) != host.numChildren - 1)
         {
            host.setChildIndex(chat_panel,host.numChildren - 1);
         }
         chat_panel.visible = true;
         if(chat_open)
         {
            if(chatLoading())
            {
               chatClose();
            }
            else
            {
               chatEnsureFocus();
            }
         }
         typingUpdate();
         voteCheck();
         chatRefresh(false);
      }
      
      private static function chatLoading() : Boolean
      {
         return !ResourceManager.isFullyLoaded();
      }
      
      private static function chatCanTakeFocus() : Boolean
      {
         var f:InteractiveObject = Main.Root.stage.focus;
         return f == null || f == Main.Root.stage || !(f is TextField);
      }
      
      private static function chatEnsureFocus() : void
      {
         if(chat_open && Main.Root.stage.focus != chat_input && chatCanTakeFocus())
         {
            Main.setFocus(chat_input);
            chat_input.setSelection(chat_input.text.length,chat_input.text.length);
         }
      }
      
      private static function chatOnFocusOut(e:FocusEvent) : void
      {
         if(chat_open && !chat_refocusing)
         {
            chat_refocusing = true;
            Main.Root.stage.addEventListener(Event.ENTER_FRAME,chatRefocus);
         }
      }
      
      private static function chatRefocus(e:Event) : void
      {
         Main.Root.stage.removeEventListener(Event.ENTER_FRAME,chatRefocus);
         chat_refocusing = false;
         if(chat_open && !chatLoading())
         {
            chatEnsureFocus();
         }
      }
      
      private static function typingUpdate() : void
      {
         var want:Boolean = false;
         var now:int = int(getTimer());
         if(!InRoom)
         {
            typing_self = false;
            return;
         }
         want = chat_open && (!TYPING_NEEDS_TEXT || chat_input.text.length > 0);
         if(want != typing_self || want && now - typing_lastSent >= TYPING_HEARTBEAT_MS)
         {
            typing_self = want;
            typing_lastSent = now;
            m_onlineInterface.sendTyping(want);
         }
      }
      
      public static function isTyping(sid:String) : Boolean
      {
         var until:Number = NaN;
         if(sid == null || sid == "")
         {
            return false;
         }
         if(sid == SocketID)
         {
            return typing_self;
         }
         until = Number(typing_map[sid]);
         if(isNaN(until))
         {
            return false;
         }
         if(int(getTimer()) > until)
         {
            delete typing_map[sid];
            return false;
         }
         return true;
      }
      
      private static function handlemgn_TYPING(e:MGNEvent) : void
      {
         var sid:String = String(e.data.sid);
         if(e.data.on)
         {
            typing_map[sid] = int(getTimer()) + TYPING_EXPIRE_MS;
         }
         else
         {
            delete typing_map[sid];
         }
      }
      
      private static function chatRefresh(force:Boolean) : void
      {
         var now:int = int(getTimer());
         var shown:Array = [];
         var newestAge:int = 0;
         var a:Number = 1;
         if(chat_open)
         {
            var i:int = Math.max(0,chat_lines.length - CHAT_SHOW_OPEN);
            while(i < chat_lines.length)
            {
               shown.push(chat_lines[i].t);
               i++;
            }
         }
         else
         {
            i = chat_lines.length - 1;
            while(i >= 0 && shown.length < CHAT_SHOW_CLOSED)
            {
               if(now - chat_lines[i].at >= CHAT_VISIBLE_MS)
               {
                  break;
               }
               shown.unshift(chat_lines[i].t);
               i--;
            }
            if(shown.length > 0)
            {
               newestAge = now - chat_lines[chat_lines.length - 1].at;
            }
         }
         var txt:String = shown.join("\n");
         if(!chat_open && newestAge > CHAT_VISIBLE_MS - CHAT_FADE_MS)
         {
            a = Math.max(0,(CHAT_VISIBLE_MS - newestAge) / CHAT_FADE_MS);
         }
         chat_log.alpha = a;
         chat_bg.alpha = a;
         if(!force && txt == chat_lastText && chat_open == chat_lastOpen)
         {
            return;
         }
         chat_lastText = txt;
         chat_lastOpen = chat_open;
         chat_log.text = txt;
         chat_log.y = CHAT_LOG_AREA_H - chat_log.height;
         chat_bg.graphics.clear();
         var k:int = 0;
         while(k < chat_log.numLines)
         {
            var lm:TextLineMetrics = chat_log.getLineMetrics(k);
            var cb:Rectangle = chat_log.getCharBoundaries(chat_log.getLineOffset(k));
            if(cb != null && lm.width > 0)
            {
               chat_bg.graphics.beginFill(0,chat_open ? 0.75 : 0.6);
               chat_bg.graphics.drawRect(chat_log.x,chat_log.y + cb.y,lm.width + 4,cb.height);
               chat_bg.graphics.endFill();
            }
            k++;
         }
      }
      
      public static function get InRoom() : Boolean
      {
         return m_onlineInterface != null && m_onlineInterface.Connected && m_onlineInterface.RoomKey != null && m_onlineInterface.RoomKey != "";
      }
      
      public static function sendChat(text:String) : void
      {
         if(InRoom)
         {
            m_onlineInterface.sendChat(text);
         }
      }
      
      private static function handlemgn_CHAT(e:MGNEvent) : void
      {
         chatReceive((e.data.spectator === true ? "[ESP] " : "") + String(e.data.from),String(e.data.text));
      }
      
      private static function handlemgn_PICK(e:MGNEvent) : void
      {
         pick_map[String(e.data.sid)] = String(e.data.character);
      }
      
      public static function vsShow(settings:*, online:Boolean) : Boolean
      {
         var list:Array = [];
         var i:int = 0;
         var ps:* = null;
         var ch:String = null;
         var nick:String = null;
         vsKill();
         if(settings == null)
         {
            return false;
         }
         while(i < settings.length && list.length < VS_MAX)
         {
            ps = settings[i];
            if(ps != null && ps.exist !== false && ps.character != null && ps.character != "" && ps.character != "xp")
            {
               ch = String(ps.character);
               if(ch == "random" && Main.RandCharList != null && Main.RandCharList[i] != null)
               {
                  ch = String(Main.RandCharList[i].StatsName);
               }
               nick = ps.name != null ? String(ps.name) : "";
               if(nick == "P" + (i + 1))
               {
                  nick = "";
               }
               list.push({
                  "slot":i,
                  "ch":ch,
                  "nick":nick,
                  "team":(ps.team != null ? int(ps.team) : -1),
                  "costume":(ps.costume != null ? int(ps.costume) : -1)
               });
            }
            i++;
         }
         if(list.length < 2)
         {
            return false;
         }
         try
         {
            vsBuild(list);
         }
         catch(err:Error)
         {
            vsKill();
            return false;
         }
         vs_online = online;
         vs_t0 = int(getTimer());
         Main.Root.addChild(vs_root);
         Main.Root.stage.addEventListener(Event.ENTER_FRAME,vsTick);
         return true;
      }
      
      public static function vsFinish(cb:Function) : void
      {
         if(vs_root == null)
         {
            if(cb != null)
            {
               cb();
            }
            return;
         }
         if(vs_online)
         {
            vsKill();
            if(cb != null)
            {
               cb();
            }
            return;
         }
         vs_finishCb = cb;
         vs_want = true;
      }
      
      public static function vsKill() : void
      {
         if(vs_root != null && vs_root.parent != null)
         {
            vs_root.parent.removeChild(vs_root);
         }
         try
         {
            Main.Root.stage.removeEventListener(Event.ENTER_FRAME,vsTick);
         }
         catch(err:Error)
         {
         }
         vs_root = null;
         vs_items = null;
         vs_vsBox = null;
         vs_logo = null;
         vs_vsStarted = false;
         vs_dots = null;
         vs_holdCb = null;
         vs_finishCb = null;
         vs_want = false;
         vs_closeT = 0;
         vs_online = false;
      }
      
      private static function vsHold(cb:Function) : void
      {
         if(vs_root == null || !vs_online)
         {
            cb();
            return;
         }
         vs_holdCb = cb;
      }
      
      private static function vsSetMatchReady() : void
      {
         m_matchReady = true;
      }
      
      private static function vsRows(n:int) : Array
      {
         if(n <= 3)
         {
            return [n];
         }
         if(n == 4)
         {
            return [2,2];
         }
         if(n == 5)
         {
            return [3,2];
         }
         if(n == 6)
         {
            return [3,3];
         }
         if(n == 7)
         {
            return [4,3];
         }
         return [4,4];
      }
      
      private static function vsX(k:int, m:int, y:Number, W:Number, H:Number, slant:Number) : Number
      {
         return W * k / m + slant * (0.5 - y / H);
      }
      
      private static function vsY(b:int, x:Number, W:Number, H:Number, R:int, tilt:Number) : Number
      {
         return H * b / R + tilt * (1 - 2 * x / W);
      }
      
      private static function vsShade(c:int, f:Number) : int
      {
         var r:int = int((c >> 16 & 0xFF) * f);
         var g:int = int((c >> 8 & 0xFF) * f);
         var b:int = int((c & 0xFF) * f);
         return r << 16 | g << 8 | b;
      }
      
      private static function vsClamp(p:Number) : Number
      {
         return p < 0 ? 0 : (p > 1 ? 1 : p);
      }
      
      private static function vsBack(p:Number) : Number
      {
         var q:Number = p - 1;
         return 1 + 2.70158 * q * q * q + 1.70158 * q * q;
      }
      
      private static function vsText(s:String, size:int, color:int) : TextField
      {
         var tf:TextField = new TextField();
         tf.defaultTextFormat = new TextFormat("_sans",size,color,true,true);
         tf.selectable = false;
         tf.mouseEnabled = false;
         tf.autoSize = TextFieldAutoSize.LEFT;
         tf.text = s;
         return tf;
      }
      
      private static function vsDrawPoly(g:*, pts:Array) : void
      {
         var i:int = 1;
         g.moveTo(pts[0].x,pts[0].y);
         while(i < pts.length)
         {
            g.lineTo(pts[i].x,pts[i].y);
            i++;
         }
         g.lineTo(pts[0].x,pts[0].y);
      }
      
      private static function vsRender(holder:Sprite, w:int, h:int) : BitmapData
      {
         var b:Rectangle = holder.getBounds(holder);
         var sc:Number = 0;
         var tmp:BitmapData = null;
         var cr:Rectangle = null;
         var out:BitmapData = null;
         var tx:Number = 0;
         var ty:Number = 0;
         var hx0:Number = 0;
         var hy0:Number = 0;
         var hw:Number = 0;
         var hh:Number = 0;
         var sc2:Number = 0;
         if(b.width < 2 || b.height < 2)
         {
            return null;
         }
         sc = Math.min(w / b.width,h / b.height);
         tx = (w - b.width * sc) / 2 - b.x * sc;
         ty = (h - b.height * sc) / 2 - b.y * sc;
         tmp = new BitmapData(w,h,true,0);
         tmp.draw(holder,new Matrix(sc,0,0,sc,tx,ty),null,null,new Rectangle(0,0,w,h),true);
         cr = tmp.getColorBoundsRect(4278190080,0,false);
         if(cr.width < 2 || cr.height < 2)
         {
            tmp.dispose();
            return null;
         }
         if(cr.width < w * 0.85 && cr.height < h * 0.85)
         {
            hx0 = (cr.x - tx) / sc;
            hy0 = (cr.y - ty) / sc;
            hw = cr.width / sc;
            hh = cr.height / sc;
            sc2 = Math.min(Math.min(w / hw,h / hh) * 0.97,sc * 6);
            tmp.fillRect(tmp.rect,0);
            tmp.draw(holder,new Matrix(sc2,0,0,sc2,(w - hw * sc2) / 2 - hx0 * sc2,(h - hh * sc2) / 2 - hy0 * sc2),null,null,new Rectangle(0,0,w,h),true);
            cr = tmp.getColorBoundsRect(4278190080,0,false);
            if(cr.width < 2 || cr.height < 2)
            {
               tmp.dispose();
               return null;
            }
         }
         out = new BitmapData(int(cr.width),int(cr.height),true,0);
         out.copyPixels(tmp,cr,new Point(0,0));
         tmp.dispose();
         return out;
      }
      
      private static function vsSettle(d:DisplayObject, depth:int) : void
      {
         var mc:MovieClip = d as MovieClip;
         var dc:DisplayObjectContainer = d as DisplayObjectContainer;
         var i:int = 0;
         if(mc != null && mc.totalFrames > 1)
         {
            mc.gotoAndStop(mc.totalFrames);
         }
         if(dc != null && depth < 4)
         {
            while(i < dc.numChildren)
            {
               vsSettle(dc.getChildAt(i),depth + 1);
               i++;
            }
         }
      }
      
      private static function vsSlotPortrait(id:String, w:int, h:int) : BitmapData
      {
         var slot:MovieClip = null;
         var src:DisplayObject = null;
         var hidden:Array = [];
         var b:Rectangle = null;
         var trim:Number = 0;
         var sc:Number = 0;
         var out:BitmapData = null;
         var i:int = 0;
         try
         {
            slot = pickBuildSlot(id);
            if(slot == null)
            {
               vs_err += "sin slot ";
               return null;
            }
            trim = pickTrim(id);
            src = slot.mc != null ? slot.mc as DisplayObject : slot as DisplayObject;
            pickHideTexts(src,hidden);
            b = src.getBounds(src);
            if(b.width >= 2 && b.height >= 2)
            {
               sc = Math.max(w / b.width,h / (b.height * (1 - trim)));
               out = new BitmapData(w,h,true,4279242776);
               out.draw(src,new Matrix(sc,0,0,sc,(w - b.width * sc) / 2 - b.x * sc,h - (b.y + b.height) * sc),null,null,new Rectangle(0,0,w,h),true);
            }
            while(i < hidden.length)
            {
               hidden[i].visible = true;
               i++;
            }
         }
         catch(err:Error)
         {
            vs_err += "E2:" + String(err.message).substr(0,50) + " ";
            return null;
         }
         return out;
      }
      
      private static function vsPortrait(id:String, team:int, costume:int, w:int, h:int) : BitmapData
      {
         var mc:MovieClip = null;
         var holder:Sprite = null;
         var portrait:Bitmap = null;
         var out:BitmapData = null;
         var alt:BitmapData = null;
         var direct:Boolean = false;
         vs_err = "";
         vs_lastFull = false;
         try
         {
            if(FMCManager.getCharacterBitmap(id,FMCData.CHARACTER_PORTRAIT))
            {
               mc = new MovieClip();
               portrait = FMCManager.getCharacterBitmap(id,FMCData.CHARACTER_PORTRAIT);
               portrait = new Bitmap(portrait.bitmapData.clone());
               mc.addChild(portrait);
               direct = true;
            }
            else if(ResourceManager.getLibraryMC(Stats.getStats(id,-1).StatsName + "_charselect") != null)
            {
               mc = ResourceManager.getLibraryMC(Stats.getStats(id,-1).StatsName + "_charselect");
            }
            if(mc == null)
            {
               vs_err += "sin charselect ";
            }
            else
            {
               mc.filters = null;
               try
               {
                  Utils.setColorFilterCharacter(mc,team,id,costume,true,true);
               }
               catch(errC:Error)
               {
                  vs_err += "col:" + String(errC.message).substr(0,40) + " ";
               }
               holder = new Sprite();
               holder.addChild(mc);
               if(direct)
               {
                  out = new BitmapData(portrait.bitmapData.width,portrait.bitmapData.height,true,0);
                  out.draw(holder,null,null,null,null,true);
                  portrait.bitmapData.dispose();
                  vs_lastFull = true;
               }
               else
               {
                  out = vsRender(holder,w,h);
                  if(out == null || out.width * 2.5 < out.height)
                  {
                     vsSettle(mc,0);
                     try
                     {
                        Utils.setColorFilterCharacter(mc,team,id,costume,true,true);
                     }
                     catch(errS:Error)
                     {
                     }
                     alt = vsRender(holder,w,h);
                     if(alt != null && (out == null || alt.width * alt.height > out.width * out.height * 1.15))
                     {
                        if(out != null)
                        {
                           out.dispose();
                        }
                        out = alt;
                     }
                     else if(alt != null)
                     {
                        alt.dispose();
                     }
                  }
               }
               if(out == null)
               {
                  vs_err += "vacio ";
               }
            }
         }
         catch(err:Error)
         {
            vs_err += "E1:" + String(err.message).substr(0,50) + " ";
         }
         if(out == null)
         {
            vs_lastFull = false;
            out = vsSlotPortrait(id,320,260);
         }
         return out;
      }
      
      private static function vsCenterX(bd:BitmapData) : Number
      {
         var n:int = 24;
         var sm:BitmapData = new BitmapData(n,n,true,0);
         var px:Vector.<uint> = null;
         var x:int = 0;
         var y:int = 0;
         var a:Number = 0;
         var sum:Number = 0;
         var wx:Number = 0;
         sm.draw(bd,new Matrix(n / bd.width,0,0,n / bd.height),null,null,null,true);
         px = sm.getVector(sm.rect);
         while(y < int(n * 0.4))
         {
            x = 0;
            while(x < n)
            {
               a = px[y * n + x] >>> 24;
               sum += a;
               wx += a * (x + 0.5);
               x++;
            }
            y++;
         }
         sm.dispose();
         if(sum <= 0)
         {
            return bd.width / 2;
         }
         return (wx / sum / n * 0.8 + 0.1) * bd.width;
      }
      
      private static function vsMakeLogo(size:int) : Sprite
      {
         var tf:TextField = vsText("VS.",size,16777215);
         var bd:BitmapData = new BitmapData(int(tf.width) + 6,int(tf.height) + 6,true,0);
         var bm:Bitmap = null;
         var grad:Sprite = new Sprite();
         var out:Sprite = new Sprite();
         var mt:Matrix = new Matrix();
         bd.draw(tf,new Matrix(1,0,0,1,3,3));
         bm = new Bitmap(bd,"auto",true);
         mt.createGradientBox(bd.width,bd.height,Math.PI / 2,0,0);
         grad.graphics.beginGradientFill("linear",[12582911,4235519,1593087,534885],[1,1,1,1],[0,105,150,255],mt);
         grad.graphics.drawRect(0,0,bd.width,bd.height);
         grad.graphics.endFill();
         grad.graphics.beginFill(16777215,0.3);
         grad.graphics.drawRect(0,0,bd.width,bd.height * 0.42);
         grad.graphics.endFill();
         grad.cacheAsBitmap = true;
         bm.cacheAsBitmap = true;
         out.addChild(grad);
         out.addChild(bm);
         grad.mask = bm;
         out.filters = [new GlowFilter(16777215,1,3,3,10,2),new GlowFilter(0,1,6,6,14,2),new GlowFilter(2783231,0.55,14,14,2,2)];
         return out;
      }
      
      private static function vsFindLogo() : MovieClip
      {
         var names:Array = [VS_LOGO_LINKAGE,"vs_logo","vslogo","logo_vs","classic_vs","vs_mc","versus_mc","vs"];
         var i:int = 0;
         var mc:MovieClip = null;
         while(true)
         {
            if(i >= names.length)
            {
               return null;
            }
            if(String(names[i]) != "")
            {
               try
               {
                  mc = ResourceManager.getLibraryMC(String(names[i]));
               }
               catch(err:Error)
               {
                  mc = null;
               }
               if(mc != null)
               {
                  break;
               }
            }
            i++;
         }
         return mc;
      }
      
      private static function vsBuild(list:Array) : void
      {
         var W:Number = Main.Width;
         var H:Number = Main.Height;
         var n:int = int(list.length);
         var rows:Array = vsRows(n);
         var R:int = int(rows.length);
         var tilt:Number = R > 1 ? H * 0.035 : 0;
         var slant:Number = W * 0.07;
         var bg:Shape = new Shape();
         var bar:Shape = new Shape();
         var idx:int = 0;
         var r:int = 0;
         var k:int = 0;
         var m:int = 0;
         var x:Number = 0;
         var vsArt:Sprite = null;
         var lb:Rectangle = null;
         var ls:Number = 1;
         vs_root = new Sprite();
         vs_root.mouseEnabled = false;
         vs_root.mouseChildren = false;
         bg.graphics.beginFill(1380895);
         bg.graphics.drawRect(-14,-14,W + 28,H + 28);
         bg.graphics.endFill();
         bg.graphics.lineStyle(2,1907242,1);
         x = -H;
         while(x < W)
         {
            bg.graphics.moveTo(x,H + 14);
            bg.graphics.lineTo(x + H * 0.6,-14);
            x += 26;
         }
         vs_root.addChild(bg);
         vs_items = [];
         while(r < R)
         {
            m = int(rows[r]);
            k = 0;
            while(k < m && idx < n)
            {
               vsAddPanel(list[idx],idx,n,r,k,m,R,W,H,tilt,slant);
               idx++;
               k++;
            }
            r++;
         }
         vs_vsBox = new Sprite();
         vs_logo = vsFindLogo();
         if(vs_logo != null)
         {
            vsSettle(vs_logo,0);
            lb = vs_logo.getBounds(vs_logo);
            if(lb.width >= 2 && lb.height >= 2)
            {
               ls = Math.min((n <= 2 ? 210 : 160) / lb.width,H * 0.42 / lb.height);
               vs_logo.scaleX = ls;
               vs_logo.scaleY = ls;
               vs_logo.x = -(lb.x + lb.width / 2) * ls;
               vs_logo.y = -(lb.y + lb.height / 2) * ls;
               vs_vsBox.addChild(vs_logo);
            }
            else
            {
               vs_logo = null;
            }
         }
         if(vs_logo == null)
         {
            vsArt = vsMakeLogo(n <= 2 ? 96 : 68);
            lb = vsArt.getBounds(vsArt);
            vsArt.x = -(lb.x + lb.width / 2);
            vsArt.y = -(lb.y + lb.height / 2);
            vs_vsBox.addChild(vsArt);
         }
         vs_vsBox.x = W / 2;
         vs_vsBox.y = H / 2;
         vs_vsBox.visible = false;
         vs_vsT = 60 + (n - 1) * 95 + 560;
         vs_root.addChild(vs_vsBox);
         bar.graphics.beginFill(0,0.85);
         bar.graphics.drawRect(0,H - 22,W,22);
         bar.graphics.endFill();
         vs_root.addChild(bar);
         vs_dots = vsText("CARGANDO",11,16777215);
         vs_dots.x = 12;
         vs_dots.y = H - 20;
         vs_root.addChild(vs_dots);
      }
      
      private static function vsAddPanel(info:Object, idx:int, n:int, r:int, k:int, m:int, R:int, W:Number, H:Number, tilt:Number, slant:Number) : void
      {
         var gap:Number = 3;
         var yt:Number = H * r / R;
         var yb:Number = H * (r + 1) / R;
         var xtl:Number = k == 0 ? -8 : vsX(k,m,yt,W,H,slant);
         var xtr:Number = k == m - 1 ? W + 8 : vsX(k + 1,m,yt,W,H,slant);
         var xbl:Number = k == 0 ? -8 : vsX(k,m,yb,W,H,slant);
         var xbr:Number = k == m - 1 ? W + 8 : vsX(k + 1,m,yb,W,H,slant);
         var ytl:Number = r == 0 ? -8 : vsY(r,xtl,W,H,R,tilt);
         var ytr:Number = r == 0 ? -8 : vsY(r,xtr,W,H,R,tilt);
         var ybl:Number = r == R - 1 ? H + 8 : vsY(r + 1,xbl,W,H,R,tilt);
         var ybr:Number = r == R - 1 ? H + 8 : vsY(r + 1,xbr,W,H,R,tilt);
         var pts:Array = null;
         var minX:Number = 0;
         var maxX:Number = 0;
         var minY:Number = 0;
         var maxY:Number = 0;
         var cx:Number = 0;
         var topY:Number = 0;
         var botY:Number = 0;
         var col:int = int(VS_COLORS[int(info.slot) % VS_COLORS.length]);
         var dark:int = vsShade(col,0.72);
         var pnl:Sprite = new Sprite();
         var art:Sprite = new Sprite();
         var mk:Shape = new Shape();
         var ol:Shape = new Shape();
         var x:Number = 0;
         var cellW:Number = W / m;
         var cellH:Number = H / R;
         var s:Number = 0;
         var pw:int = 0;
         var ph:int = 0;
         var bd:BitmapData = null;
         var bm:Bitmap = null;
         var card:Sprite = new Sprite();
         var dbg:TextField = null;
         var fg:Sprite = new Sprite();
         var mk2:Shape = new Shape();
         var plate:Sprite = new Sprite();
         var disp:String = pickDisplayName(String(info.ch)).toUpperCase();
         var fs:int = n <= 3 ? 16 : (n <= 6 ? 13 : 10);
         var nm:TextField = null;
         var nk:TextField = null;
         var bt:TextField = null;
         var hasNick:Boolean = String(info.nick) != "";
         var ph2:Number = hasNick ? 30 : 22;
         var pwid:Number = 0;
         var maxW:Number = 0;
         var dx:Number = 0;
         var dy:Number = 0;
         var cxc:Number = 0;
         var full:Boolean = false;
         if(k > 0)
         {
            xtl += gap;
            xbl += gap;
         }
         if(k < m - 1)
         {
            xtr -= gap;
            xbr -= gap;
         }
         if(r > 0)
         {
            ytl += gap;
            ytr += gap;
         }
         if(r < R - 1)
         {
            ybl -= gap;
            ybr -= gap;
         }
         pts = [new Point(xtl,ytl),new Point(xtr,ytr),new Point(xbr,ybr),new Point(xbl,ybl)];
         minX = Math.max(0,Math.min(xtl,xbl));
         maxX = Math.min(W,Math.max(xtr,xbr));
         minY = Math.max(0,Math.min(ytl,ytr));
         maxY = Math.min(H - 22,Math.max(ybl,ybr));
         cx = (minX + maxX) / 2;
         topY = Math.max(0,ytl + (ytr - ytl) * (cx - xtl) / (xtr - xtl));
         botY = Math.min(H - 22,ybl + (ybr - ybl) * (cx - xbl) / (xbr - xbl));
         art.graphics.beginFill(col);
         art.graphics.drawRect(minX - 12,minY - 12,maxX - minX + 24,maxY - minY + 24);
         art.graphics.endFill();
         art.graphics.lineStyle(9,dark,0.6);
         x = minX - (maxY - minY);
         while(x < maxX + 20)
         {
            art.graphics.moveTo(x,maxY + 12);
            art.graphics.lineTo(x + (maxY - minY + 24) * 0.45,minY - 12);
            x += 30;
         }
         art.graphics.lineStyle();
         art.graphics.beginFill(0,0.25);
         art.graphics.drawRect(minX - 12,maxY - (maxY - minY) * 0.38,maxX - minX + 24,(maxY - minY) * 0.38 + 12);
         art.graphics.endFill();
         mk.graphics.beginFill(0);
         vsDrawPoly(mk.graphics,pts);
         mk.graphics.endFill();
         pnl.addChild(art);
         pnl.addChild(mk);
         art.mask = mk;
         ol.graphics.lineStyle(3,0,1);
         vsDrawPoly(ol.graphics,pts);
         bd = vsPortrait(String(info.ch),int(info.team),int(info.costume),int(cellW * 2),int(cellH * 2));
         full = vs_lastFull && bd != null;
         if(bd == null)
         {
            bd = pickGeneric(false);
         }
         bm = new Bitmap(bd,"auto",true);
         if(full)
         {
            s = (botY - topY + VS_BLEED * 2) / bd.height * VS_ZOOM;
         }
         else
         {
            s = Math.min((botY - topY + VS_BLEED * 2) / bd.height,cellW * VS_MAX_OVERFLOW / bd.width) * VS_ZOOM;
         }
         bm.scaleX = s;
         bm.scaleY = s;
         bm.x = -bm.width / 2;
         if(full)
         {
            bm.x = -bd.width * VS_PORTRAIT_CX * s;
            if(bm.width > cellW)
            {
               bm.x = Math.max(cellW / 2 - bm.width,Math.min(-cellW / 2,bm.x));
            }
         }
         else if(bm.width > cellW)
         {
            cxc = vsCenterX(bd) * s;
            bm.x = Math.max(cellW / 2 - bm.width,Math.min(-cellW / 2,-cxc));
         }
         bm.y = -bm.height;
         card.addChild(bm);
         if(VS_DEBUG && vs_err != "")
         {
            dbg = vsText(vs_err,9,16777215);
            dbg.x = -dbg.width / 2;
            dbg.y = -bm.height + 6;
            dbg.background = true;
            dbg.backgroundColor = 0;
            card.addChild(dbg);
         }
         card.x = cx;
         card.y = botY + VS_BLEED;
         card.filters = [new DropShadowFilter(6,45,0,1,0,0,1,1)];
         card.visible = false;
         fg.addChild(card);
         mk2.graphics.beginFill(0);
         vsDrawPoly(mk2.graphics,pts);
         mk2.graphics.endFill();
         fg.mask = mk2;
         pnl.addChild(fg);
         pnl.addChild(mk2);
         pnl.addChild(ol);
         nm = vsText(disp,fs,16777215);
         maxW = cellW * 0.8;
         if(nm.width > maxW)
         {
            nm.scaleX = maxW / nm.width;
         }
         bt = vsText("P" + (int(info.slot) + 1),fs > 10 ? 11 : 9,16777215);
         pwid = 30 + nm.width * nm.scaleX + 14;
         plate.graphics.beginFill(0);
         plate.graphics.moveTo(6,0);
         plate.graphics.lineTo(pwid,0);
         plate.graphics.lineTo(pwid - 6,ph2);
         plate.graphics.lineTo(0,ph2);
         plate.graphics.endFill();
         plate.graphics.beginFill(col);
         plate.graphics.moveTo(6,0);
         plate.graphics.lineTo(28,0);
         plate.graphics.lineTo(22,ph2);
         plate.graphics.lineTo(0,ph2);
         plate.graphics.endFill();
         bt.x = 4;
         bt.y = (ph2 - bt.height) / 2;
         bt.filters = [new DropShadowFilter(1,45,0,1,0,0,1,1)];
         nm.x = 32;
         nm.y = hasNick ? -1 : (ph2 - nm.height) / 2;
         plate.addChild(bt);
         plate.addChild(nm);
         if(hasNick)
         {
            nk = vsText(String(info.nick),9,col == 14922267 ? 16774000 : 16777215);
            nk.x = 32;
            nk.y = 14;
            nk.alpha = 0.9;
            plate.addChild(nk);
         }
         plate.x = cx - pwid / 2;
         plate.y = maxY - ph2 - 8;
         plate.alpha = 0;
         pnl.addChild(plate);
         if(m % 2 == 1 && k == (m - 1) / 2)
         {
            dy = r == 0 ? -(H + 40) : H + 40;
         }
         else
         {
            dx = k < m / 2 ? -(W + 40) : W + 40;
         }
         pnl.x = dx;
         pnl.y = dy;
         pnl.visible = false;
         vs_root.addChild(pnl);
         vs_items.push({
            "pnl":pnl,
            "card":card,
            "plate":plate,
            "py":plate.y,
            "dx":dx,
            "dy":dy,
            "t":60 + idx * 95
         });
      }
      
      private static function vsTick(e:Event) : void
      {
         var now:int = 0;
         var i:int = 0;
         var it:Object = null;
         var p:Number = 0;
         var q:Number = 0;
         var top:int = 0;
         var cb:Function = null;
         var dots:int = 0;
         if(vs_root == null)
         {
            vsKill();
            return;
         }
         now = int(getTimer()) - vs_t0;
         if(vs_online && !InRoom || now > 120000)
         {
            vsKill();
            return;
         }
         if(vs_root.parent == Main.Root)
         {
            top = Main.Root.numChildren - 1;
            if(chat_panel != null && chat_panel.parent == Main.Root)
            {
               top--;
            }
            if(top >= 0 && Main.Root.getChildIndex(vs_root) != top)
            {
               Main.Root.setChildIndex(vs_root,top);
            }
         }
         i = 0;
         while(i < vs_items.length)
         {
            it = vs_items[i];
            if(now >= it.t)
            {
               it.pnl.visible = true;
               p = vsBack(vsClamp((now - it.t) / 380));
               it.pnl.x = it.dx * (1 - p);
               it.pnl.y = it.dy * (1 - p);
               q = vsClamp((now - it.t - 260) / 260);
               it.card.visible = q > 0;
               it.card.scaleX = 0.6 + 0.4 * vsBack(q);
               it.card.scaleY = it.card.scaleX;
               q = vsClamp((now - it.t - 400) / 220);
               it.plate.alpha = q;
               it.plate.y = it.py + 14 * (1 - q);
            }
            i++;
         }
         if(now >= vs_vsT)
         {
            q = vsClamp((now - vs_vsT) / 220);
            vs_vsBox.visible = true;
            if(!vs_vsStarted)
            {
               vs_vsStarted = true;
               if(vs_logo != null)
               {
                  vs_logo.gotoAndPlay(1);
               }
            }
            vs_vsBox.scaleX = 1 + 1.6 * (1 - q) * (1 - q);
            vs_vsBox.scaleY = vs_vsBox.scaleX;
            vs_vsBox.rotation = vs_logo != null ? 0 : -6;
            if(now < vs_vsT + 380)
            {
               q = 1 - (now - vs_vsT) / 380;
               vs_root.x = (Math.random() * 2 - 1) * 7 * q;
               vs_root.y = (Math.random() * 2 - 1) * 5 * q;
            }
            else
            {
               vs_root.x = 0;
               vs_root.y = 0;
            }
         }
         dots = int(now / 300) % 4;
         vs_dots.text = "CARGANDO" + (dots == 0 ? "" : (dots == 1 ? "." : (dots == 2 ? ".." : "...")));
         if(vs_holdCb != null && now >= VS_ONLINE_HOLD_MS)
         {
            cb = vs_holdCb;
            vs_holdCb = null;
            cb();
         }
         if(vs_want)
         {
            if(vs_closeT == 0 && now >= VS_MIN_MS)
            {
               vs_closeT = int(getTimer());
            }
            if(vs_closeT != 0)
            {
               q = (int(getTimer()) - vs_closeT) / 220;
               vs_root.alpha = 1 - vsClamp(q);
               if(q >= 1)
               {
                  cb = vs_finishCb;
                  vsKill();
                  if(cb != null)
                  {
                     cb();
                  }
               }
            }
         }
      }
      
      public static function get RematchPending() : Boolean
      {
         return rm_pending;
      }
      
      public static function get RematchVotes() : int
      {
         return rm_votes;
      }
      
      public static function get RematchTotal() : int
      {
         return rm_total > 0 ? rm_total : Players.length;
      }
      
      public static function get RematchMine() : Boolean
      {
         return rm_mine;
      }
      
      public static function rematchToggle() : void
      {
         if(!Connected)
         {
            return;
         }
         rm_mine = !rm_mine;
         m_onlineInterface.sendRematch(rm_mine);
         SoundQueue.instance.playSoundEffect("menu_hover");
      }
      
      public static function rematchEnter(game:Game) : void
      {
         rm_pending = false;
         rm_mine = false;
         rm_votes = 0;
         rm_auto = IsHost;
         rm_frames = 0;
         rm_game = game;
         vtClear();
         MenuController.pleaseWaitMenu.show();
         toWaitingRoom(game,rematchWaitingRoomReady);
      }
      
      private static function rematchWaitingRoomReady(e:* = null) : void
      {
         MenuController.disposeAllMenus();
         GameController.startMatch(rm_game);
      }
      
      public static function rematchAutoReady() : Boolean
      {
         var cnt:int = 0;
         var k:String = null;
         if(!rm_auto)
         {
            return false;
         }
         ++rm_frames;
         if(rm_frames < 150)
         {
            return false;
         }
         for(k in vt_votes)
         {
            cnt++;
         }
         if(vt_options.length == 0 || cnt >= Players.length || rm_frames >= 600)
         {
            rm_auto = false;
            return true;
         }
         return false;
      }
      
      private static function handlemgn_REMATCHSTATE(e:MGNEvent) : void
      {
         var sids:Array = e.data.sids != null ? e.data.sids : [];
         rm_votes = int(e.data.votes);
         rm_total = int(e.data.total);
         rm_mine = sids.indexOf(SocketID) >= 0;
      }
      
      private static function handlemgn_REMATCHGO(e:MGNEvent) : void
      {
         rm_pending = true;
         rm_mine = false;
         rm_votes = 0;
      }
      
      private static function handlemgn_VOTESTATE(e:MGNEvent) : void
      {
         var opts:Array = e.data.options != null ? e.data.options : [];
         if(opts.join("|") != vt_options.join("|"))
         {
            vt_shown = false;
         }
         vt_options = opts;
         vt_votes = e.data.votes != null ? e.data.votes : {};
         if(vt_ui != null)
         {
            vtRender();
         }
      }
      
      private static function vtClear() : void
      {
         vt_options = [];
         vt_votes = {};
         vt_shown = false;
         voteClose();
      }
      
      private static function inWaitingRoom() : Boolean
      {
         return GameController.currentGame != null && GameController.currentGame.GameMode === Mode.ONLINE_WAITING_ROOM && GameController.stageData != null;
      }
      
      private static function voteHostInit(stage:String) : void
      {
         var opts:Array = [];
         var tries:int = 0;
         var r:String = null;
         if(!IsHost)
         {
            return;
         }
         if(!SaveData.OnlineStageVote)
         {
            m_onlineInterface.sendVoteOptions([]);
            return;
         }
         if(stage == null || stage == "" || stage == "waitingroom" || stage == "random")
         {
            return;
         }
         opts.push(stage);
         while(opts.length < 4 && tries < 40)
         {
            r = String(StageSetting.getRandomStage());
            if(r != "" && r != "random" && r != "waitingroom" && opts.indexOf(r) < 0)
            {
               opts.push(r);
            }
            tries++;
         }
         m_onlineInterface.sendVoteOptions(opts);
         m_onlineInterface.sendVote(stage);
      }
      
      public static function voteApply() : void
      {
         var counts:Object = {};
         var best:int = 0;
         var tied:Array = [];
         var k:String = null;
         var i:int = 0;
         var st:String = null;
         rm_auto = false;
         if(vt_options.length == 0)
         {
            return;
         }
         for(k in vt_votes)
         {
            st = String(vt_votes[k]);
            if(vt_options.indexOf(st) >= 0)
            {
               counts[st] = int(counts[st]) + 1;
            }
         }
         while(i < vt_options.length)
         {
            st = String(vt_options[i]);
            if(int(counts[st]) > best)
            {
               best = int(counts[st]);
               tied = [st];
            }
            else if(best > 0 && int(counts[st]) == best)
            {
               tied.push(st);
            }
            i++;
         }
         if(tied.length == 0)
         {
            return;
         }
         st = String(tied[int(Math.random() * tied.length)]);
         if(GameController.onlineModeMatchSettings != null && GameController.onlineModeMatchSettings.levelData != null)
         {
            GameController.onlineModeMatchSettings.levelData.stage = st;
         }
         notify("Escenario elegido por votacion: " + vtName(st));
      }
      
      private static function vtName(id:String) : String
      {
         var info:* = null;
         try
         {
            info = ResourceManager.getResourceByID("mappings").getProp("metadata").stage[id];
            if(info != null && info.name != null)
            {
               return String(info.name);
            }
         }
         catch(err:Error)
         {
         }
         return id;
      }
      
      private static function vtCount(id:String) : int
      {
         var n:int = 0;
         var k:String = null;
         for(k in vt_votes)
         {
            if(String(vt_votes[k]) == id)
            {
               n++;
            }
         }
         return n;
      }
      
      private static function vtSnapshot(id:String, fw:int, fh:int) : BitmapData
      {
         var prev:MovieClip = null;
         var inner:MovieClip = null;
         var bmp:Bitmap = null;
         var tmpBmp:Bitmap = null;
         var b:Rectangle = null;
         var bd:BitmapData = null;
         var fin:BitmapData = null;
         var ss:Number = 0;
         try
         {
            prev = MovieClip(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer);
            inner = MovieClip(prev.getChildByName("mc"));
            if(FMCManager.getStage(id) != null)
            {
               Utils.tryToGotoAndStop(inner,"external");
               bmp = FMCManager.getStageBitmap(id);
               if(bmp != null && inner.mc != null)
               {
                  tmpBmp = new Bitmap(bmp.bitmapData);
                  tmpBmp.x = -tmpBmp.width / 2;
                  tmpBmp.y = -tmpBmp.height / 2;
                  inner.mc.addChild(tmpBmp);
               }
            }
            else
            {
               Utils.tryToGotoAndStop(inner,id);
            }
            b = prev.getBounds(prev);
            if(b.width >= 2 && b.height >= 2)
            {
               bd = new BitmapData(int(b.width * 2),int(b.height * 2),true,0);
               bd.draw(prev,new Matrix(2,0,0,2,-b.x * 2,-b.y * 2),null,null,null,true);
               ss = Math.max(fw / bd.width,fh / bd.height);
               fin = new BitmapData(fw,fh,true,0);
               fin.draw(bd,new Matrix(ss,0,0,ss,(fw - bd.width * ss) / 2,(fh - bd.height * ss) / 2),null,null,null,false);
               bd.dispose();
            }
            if(tmpBmp != null && tmpBmp.parent != null)
            {
               tmpBmp.parent.removeChild(tmpBmp);
            }
         }
         catch(err:Error)
         {
            return null;
         }
         return fin;
      }
      
      private static function vtThumb(id:String, w:Number, h:Number) : Bitmap
      {
         var bd:BitmapData = vt_thumbs[id];
         var bm:Bitmap = null;
         if(bd == null)
         {
            bd = vtSnapshot(id,int(w * 3),int(h * 3));
            vt_thumbs[id] = bd;
         }
         if(bd == null)
         {
            return null;
         }
         bm = new Bitmap(bd,"auto",true);
         bm.scaleX = 1 / 3;
         bm.scaleY = 1 / 3;
         return bm;
      }
      
      private static function vtText(parent:Sprite, s:String, x:Number, y:Number, size:int, color:int, w:Number = 0, align:String = "left") : TextField
      {
         var tf:TextField = new TextField();
         tf.defaultTextFormat = new TextFormat("_sans",size,color,true,false,null,null,null,align);
         tf.selectable = false;
         tf.mouseEnabled = false;
         tf.multiline = false;
         tf.wordWrap = false;
         if(w > 0)
         {
            tf.width = w;
            tf.height = size + 6;
         }
         else
         {
            tf.autoSize = TextFieldAutoSize.LEFT;
         }
         tf.text = s;
         tf.x = x;
         tf.y = y;
         parent.addChild(tf);
         return tf;
      }
      
      private static function voteCheck() : void
      {
         if(vt_ui != null)
         {
            return;
         }
         if(!vt_shown && !IsHost && vt_options.length > 0 && inWaitingRoom() && !chat_open && vs_root == null)
         {
            vt_shown = true;
            voteOpen();
         }
      }
      
      public static function voteOpen() : void
      {
         var W:Number = Main.Width;
         var dim:Sprite = new Sprite();
         var tab:Sprite = new Sprite();
         var i:int = 0;
         if(vt_ui != null || vt_options.length == 0 || chat_open)
         {
            return;
         }
         vt_sel = 0;
         while(i < vt_options.length)
         {
            if(String(vt_votes[SocketID]) == String(vt_options[i]))
            {
               vt_sel = i;
            }
            i++;
         }
         vt_ui = new Sprite();
         dim.graphics.beginFill(0,0.72);
         dim.graphics.drawRect(-2,-2,W + 4,Main.Height + 4);
         dim.graphics.endFill();
         vt_ui.addChild(dim);
         tab.graphics.beginFill(9426829);
         tab.graphics.moveTo(0,0);
         tab.graphics.lineTo(220,0);
         tab.graphics.lineTo(212,26);
         tab.graphics.lineTo(-8,26);
         tab.graphics.endFill();
         tab.x = (W - 220) / 2;
         tab.y = 70;
         vt_ui.addChild(tab);
         vtText(tab,"VOTA EL ESCENARIO",-8,5,13,736528,228,"center");
         vtText(vt_ui,"IZQ / DER  elegir      ENTER  votar      ESC  cerrar      V  volver a abrir",0,248,8,13300422,W,"center");
         vt_layer = new Sprite();
         vt_ui.addChild(vt_layer);
         Main.Root.addChild(vt_ui);
         vt_keys = Key.CaptureStarted;
         if(vt_keys)
         {
            Key.endCapture();
         }
         Main.Root.stage.addEventListener(Event.ENTER_FRAME,voteFrame);
         vtRender();
      }
      
      public static function voteClose() : void
      {
         if(vt_ui == null)
         {
            return;
         }
         Main.Root.stage.removeEventListener(Event.ENTER_FRAME,voteFrame);
         if(vt_ui.parent != null)
         {
            vt_ui.parent.removeChild(vt_ui);
         }
         vt_ui = null;
         vt_layer = null;
         Main.fixFocus();
         if(vt_keys)
         {
            Key.beginCapture(Main.Root.stage);
            vt_keys = false;
         }
      }
      
      private static function voteFrame(e:Event) : void
      {
         var top:int = 0;
         if(vt_ui == null)
         {
            Main.Root.stage.removeEventListener(Event.ENTER_FRAME,voteFrame);
            return;
         }
         if(!InRoom || !inWaitingRoom())
         {
            voteClose();
            return;
         }
         if(vt_ui.parent == Main.Root)
         {
            top = Main.Root.numChildren - 1;
            if(chat_panel != null && chat_panel.parent == Main.Root)
            {
               top--;
            }
            if(top >= 0 && Main.Root.getChildIndex(vt_ui) != top)
            {
               Main.Root.setChildIndex(vt_ui,top);
            }
         }
      }
      
      private static function voteCast(i:int) : void
      {
         var id:String = null;
         if(i < 0 || i >= vt_options.length)
         {
            return;
         }
         id = String(vt_options[i]);
         vt_votes[SocketID] = id;
         m_onlineInterface.sendVote(id);
         SoundQueue.instance.playSoundEffect("menu_select");
         voteClose();
      }
      
      private static function vtCardClick(e:MouseEvent) : void
      {
         var i:int = int(String(Sprite(e.currentTarget).name).substr(1));
         vt_sel = i;
         voteCast(i);
      }
      
      private static function voteOnKey(e:KeyboardEvent) : void
      {
         var n:int = int(vt_options.length);
         if(vt_ui == null)
         {
            if(e.keyCode == 86 && !e.ctrlKey && !chat_open && InRoom && n > 0 && inWaitingRoom())
            {
               voteOpen();
               e.stopImmediatePropagation();
            }
            return;
         }
         if(n > 0 && e.keyCode == 37)
         {
            vt_sel = (vt_sel + n - 1) % n;
            SoundQueue.instance.playSoundEffect("menu_hover");
         }
         else if(n > 0 && e.keyCode == 39)
         {
            vt_sel = (vt_sel + 1) % n;
            SoundQueue.instance.playSoundEffect("menu_hover");
         }
         else if(e.keyCode == 13 || e.keyCode == 32)
         {
            voteCast(vt_sel);
         }
         else if(e.keyCode == 27 || e.keyCode == 86)
         {
            voteClose();
         }
         if(vt_ui != null)
         {
            vtRender();
         }
         e.stopImmediatePropagation();
      }
      
      private static function vtRender() : void
      {
         var W:Number = Main.Width;
         var n:int = int(vt_options.length);
         var cw:Number = 140;
         var gap:Number = 12;
         var x0:Number = 0;
         var i:int = 0;
         var j:int = 0;
         var id:String = null;
         var card:Sprite = null;
         var cnt:int = 0;
         var mine:Boolean = false;
         var th:Bitmap = null;
         var tm:Shape = null;
         var nm:TextField = null;
         var t:String = null;
         if(vt_ui == null || vt_layer == null)
         {
            return;
         }
         while(vt_layer.numChildren > 0)
         {
            vt_layer.removeChildAt(0);
         }
         if(n == 0)
         {
            return;
         }
         if(vt_sel >= n)
         {
            vt_sel = 0;
         }
         x0 = (W - (n * cw + (n - 1) * gap)) / 2;
         while(i < n)
         {
            id = String(vt_options[i]);
            cnt = vtCount(id);
            mine = String(vt_votes[SocketID]) == id;
            card = new Sprite();
            card.x = x0 + i * (cw + gap);
            card.y = 112;
            card.name = "c" + i;
            card.buttonMode = true;
            card.graphics.beginFill(658699);
            card.graphics.lineStyle(i == vt_sel ? 3 : (mine ? 2 : 1),i == vt_sel ? 2873643 : (mine ? 9426829 : 5925724));
            card.graphics.drawRect(0,0,cw,116);
            card.graphics.endFill();
            th = vtThumb(id,cw - 6,76);
            if(th != null)
            {
               th.x = 3;
               th.y = 3;
               tm = new Shape();
               tm.graphics.beginFill(0);
               tm.graphics.drawRect(3,3,cw - 6,76);
               tm.graphics.endFill();
               card.addChild(th);
               card.addChild(tm);
               th.mask = tm;
            }
            else
            {
               card.graphics.beginFill(1849890);
               card.graphics.drawRect(3,3,cw - 6,76);
               card.graphics.endFill();
            }
            nm = vtText(card,"",6,82,9,16777215,cw - 12);
            t = vtName(id);
            nm.text = t;
            while(nm.textWidth > cw - 16 && t.length > 1)
            {
               t = t.substr(0,t.length - 1);
               nm.text = t + "...";
            }
            if(cnt == 0)
            {
               vtText(card,"sin votos",6,99,7,9083532);
            }
            else
            {
               j = 0;
               while(j < cnt && j < 8)
               {
                  card.graphics.beginFill(9426829);
                  card.graphics.drawRect(6 + j * 11,101,8,8);
                  card.graphics.endFill();
                  j++;
               }
               vtText(card,String(cnt),6 + Math.min(cnt,8) * 11 + 2,98,9,13300422);
            }
            if(mine)
            {
               vtText(card,"TU VOTO",cw - 56,99,8,2873643,52,"right");
            }
            card.addEventListener(MouseEvent.CLICK,vtCardClick);
            vt_layer.addChild(card);
            i++;
         }
      }
      
      public static function replayIcon(id:String, w:int, h:int) : BitmapData
      {
         vs_err = "";
         return vsSlotPortrait(id,w,h);
      }
      
      public static function replayCharName(id:String) : String
      {
         return pickDisplayName(id);
      }
      
      public static function pickInit() : void
      {
         if(pick_inited)
         {
            return;
         }
         pick_inited = true;
         pick_panel = new Sprite();
         pick_panel.mouseEnabled = false;
         pick_panel.mouseChildren = false;
         pick_panel.visible = false;
         pick_timer = new Timer(PICK_TICK_MS);
         pick_timer.addEventListener(TimerEvent.TIMER,pickOnTick);
         pick_timer.start();
      }
      
      private static function pickOnTick(e:TimerEvent) : void
      {
         var cur:String = null;
         var inRoom:Boolean = InRoom;
         var m:* = MenuController.CurrentCharacterSelectMenu;
         var active:Boolean = inRoom && m is OnlineCharacterMenu && Boolean(m.isOnscreen()) && Boolean(m.Container.visible);
         if(!inRoom)
         {
            pick_map = {};
            pick_sent = null;
         }
         if(active)
         {
            if(pick_menu != m)
            {
               pick_menu = m;
               pick_cache = {};
               pick_sig = "";
               pick_sent = null;
            }
            try
            {
               cur = m.GameObj.PlayerSettings[0].character;
            }
            catch(err:Error)
            {
               cur = null;
            }
            if(cur == null)
            {
               cur = "";
            }
            if(cur != pick_sent)
            {
               pick_sent = cur;
               m_onlineInterface.sendPick(cur);
            }
         }
         else
         {
            pick_menu = null;
            pick_sig = "";
         }
         pickRefresh(active);
      }
      
      private static function pickAttach() : Boolean
      {
         var ri:int = 0;
         var pi:int = 0;
         var target:int = 0;
         var sub:DisplayObjectContainer = pick_menu.SubMenu as DisplayObjectContainer;
         var ref:DisplayObject = pick_menu.CharSelectionMC as DisplayObject;
         if(sub == null)
         {
            return false;
         }
         if(pick_panel.parent != sub)
         {
            sub.addChild(pick_panel);
         }
         if(ref != null && ref.parent == sub)
         {
            ri = sub.getChildIndex(ref);
            pi = sub.getChildIndex(pick_panel);
            target = pi < ri ? ri : ri + 1;
            if(pi != target)
            {
               sub.setChildIndex(pick_panel,target);
            }
         }
         var gp:Point = Main.Root.localToGlobal(new Point(Main.Width - PICK_MARGIN_RIGHT - (PICK_ICON_W + PICK_BAND_W),PICK_Y));
         var lp:Point = sub.globalToLocal(gp);
         pick_panel.x = lp.x;
         pick_panel.y = lp.y;
         return true;
      }
      
      private static function pickRefresh(active:Boolean) : void
      {
         var rows:Array = [];
         var sig:String = "";
         var i:int = 0;
         var p:PlayerConnectionInfo = null;
         var ch:String = null;
         var players:Vector.<PlayerConnectionInfo> = null;
         if(!active || !pickAttach())
         {
            pick_panel.visible = false;
            if(pick_panel.parent != null)
            {
               pick_panel.parent.removeChild(pick_panel);
            }
            return;
         }
         pick_panel.visible = true;
         players = Players;
         while(i < players.length)
         {
            p = players[i];
            if(p != null && p.socket_id != SocketID)
            {
               ch = pick_map[p.socket_id];
               ch = ch == null ? "" : ch;
               if(rows.length < PICK_MAX_ROWS)
               {
                  rows.push({
                     "slot":i,
                     "name":p.username,
                     "ch":ch,
                     "chn":pickDisplayName(ch)
                  });
                  sig += i + "|" + p.username + "|" + ch + ";";
               }
            }
            i++;
         }
         if(sig == pick_sig)
         {
            return;
         }
         pick_sig = sig;
         pickRebuild(rows);
      }
      
      private static function pickRebuild(rows:Array) : void
      {
         var k:int = 0;
         var r:Object = null;
         var row:Sprite = null;
         var color:uint = 0;
         var textColor:uint = 0;
         var band:Shape = null;
         var icon:Bitmap = null;
         var nameTf:TextField = null;
         var charTf:TextField = null;
         var tagTf:TextField = null;
         while(pick_panel.numChildren > 0)
         {
            pick_panel.removeChildAt(0);
         }
         while(k < rows.length)
         {
            r = rows[k];
            row = new Sprite();
            row.y = k * (PICK_ROW_H + PICK_ROW_GAP);
            color = uint(Utils.getPlayerRGB(int(r.slot) + 1));
            textColor = uint(Utils.getPlayerTextRGB(int(r.slot) + 1));
            band = new Shape();
            band.graphics.beginFill(color,0.92);
            band.graphics.drawRect(PICK_ICON_W,0,PICK_BAND_W,PICK_ROW_H);
            band.graphics.endFill();
            band.graphics.beginFill(16777215,0.18);
            band.graphics.drawRect(PICK_ICON_W,0,PICK_BAND_W,3);
            band.graphics.endFill();
            row.addChild(band);
            icon = new Bitmap(pickIcon(r.ch),"auto",true);
            icon.scaleX = 1 / PICK_OVERSAMPLE;
            icon.scaleY = 1 / PICK_OVERSAMPLE;
            row.addChild(icon);
            row.graphics.lineStyle(1.5,16777215,0.9);
            row.graphics.drawRect(0.75,0.75,PICK_ICON_W + PICK_BAND_W - 1.5,PICK_ROW_H - 1.5);
            nameTf = new TextField();
            nameTf.defaultTextFormat = new TextFormat("_sans",10,textColor,true);
            nameTf.selectable = false;
            nameTf.mouseEnabled = false;
            nameTf.x = PICK_ICON_W + 5;
            nameTf.width = PICK_BAND_W - 38;
            nameTf.height = 15;
            nameTf.y = 0;
            nameTf.text = String(r.name);
            if(textColor == 16777215)
            {
               nameTf.filters = [new DropShadowFilter(1,45,0,0.9,2,2,2)];
            }
            row.addChild(nameTf);
            charTf = new TextField();
            charTf.defaultTextFormat = new TextFormat("_sans",8,textColor,false);
            charTf.selectable = false;
            charTf.mouseEnabled = false;
            charTf.alpha = 0.9;
            charTf.x = PICK_ICON_W + 5;
            charTf.width = PICK_BAND_W - 38;
            charTf.height = 12;
            charTf.y = 13;
            charTf.text = String(r.chn);
            if(textColor == 16777215)
            {
               charTf.filters = [new DropShadowFilter(1,45,0,0.9,2,2,2)];
            }
            row.addChild(charTf);
            tagTf = new TextField();
            tagTf.defaultTextFormat = new TextFormat("_sans",10,textColor,true,null,null,null,null,"right");
            tagTf.selectable = false;
            tagTf.mouseEnabled = false;
            tagTf.alpha = 0.85;
            tagTf.width = 30;
            tagTf.height = 16;
            tagTf.x = PICK_ICON_W + PICK_BAND_W - 34;
            tagTf.y = (PICK_ROW_H - 16) / 2;
            tagTf.text = "P" + (int(r.slot) + 1);
            row.addChild(tagTf);
            pick_panel.addChild(row);
            k++;
         }
      }
      
      private static function pickDisplayName(id:String) : String
      {
         var ext:* = null;
         var nm:String = null;
         if(id == null || id == "")
         {
            return "";
         }
         if(id == "random")
         {
            return "Random";
         }
         try
         {
            ext = FMCManager.getCharacter(id);
            if(ext != null)
            {
               nm = String(ext.CharName);
            }
            else
            {
               nm = String(Stats.getStats(id,-1).DisplayName);
            }
         }
         catch(err:Error)
         {
            nm = id;
         }
         return nm == null || nm == "null" || nm == "" ? id : nm;
      }
      
      private static function pickIcon(id:String) : BitmapData
      {
         var slot:MovieClip = null;
         var bd:BitmapData = pick_cache[id];
         if(bd != null)
         {
            return bd;
         }
         if(id != "")
         {
            try
            {
               slot = pick_menu.CharMCHash[id];
               if(slot != null)
               {
                  bd = pickSnapshot(slot,pickTrim(id));
               }
            }
            catch(err:Error)
            {
               bd = null;
            }
            if(bd == null)
            {
               try
               {
                  slot = pickBuildSlot(id);
                  if(slot != null)
                  {
                     bd = pickSnapshot(slot,pickTrim(id));
                  }
               }
               catch(err2:Error)
               {
                  bd = null;
               }
            }
         }
         if(bd == null)
         {
            bd = pickGeneric(id == "");
         }
         pick_cache[id] = bd;
         return bd;
      }
      
      private static function pickBuildSlot(id:String) : MovieClip
      {
         var child:MovieClip = null;
         var portrait:Bitmap = null;
         var ext:* = FMCManager.getCharacter(id);
         if(!ext)
         {
            child = ResourceManager.getLibraryMC(id + "_select");
         }
         else
         {
            child = ResourceManager.getLibraryMC("template_select");
         }
         if(!child)
         {
            return null;
         }
         child.gotoAndStop(1);
         if(ext)
         {
            portrait = FMCManager.getCharacterBitmap(id,FMCData.CHARACTER_CSS);
            if(!portrait)
            {
               return null;
            }
            portrait.x -= 43 / 2 + 2;
            portrait.y -= 40 / 2 + 3;
            portrait.scaleX = 0.25;
            portrait.scaleY = 0.25;
            child.mc.addChild(portrait);
         }
         return child;
      }
      
      private static function pickTrim(id:String) : Number
      {
         var ext:* = null;
         try
         {
            ext = FMCManager.getCharacter(id);
         }
         catch(err:Error)
         {
            ext = null;
         }
         return ext == null ? PICK_TOP_CROP : 0;
      }
      
      private static function pickHideTexts(d:DisplayObject, list:Array) : void
      {
         var c:DisplayObjectContainer = d as DisplayObjectContainer;
         var i:int = 0;
         if((d is TextField || d is StaticText) && d.visible)
         {
            d.visible = false;
            list.push(d);
         }
         if(c != null)
         {
            while(i < c.numChildren)
            {
               pickHideTexts(c.getChildAt(i),list);
               i++;
            }
         }
      }
      
      private static function pickSnapshot(slot:MovieClip, trim:Number) : BitmapData
      {
         var src:DisplayObject = slot.mc != null ? slot.mc as DisplayObject : slot as DisplayObject;
         var hidden:Array = [];
         var b:Rectangle = null;
         var cw:int = int(PICK_ICON_W) * PICK_OVERSAMPLE;
         var ch:int = int(PICK_ROW_H) * PICK_OVERSAMPLE;
         var sc:Number = 0;
         var tmp:BitmapData = null;
         var cr:Rectangle = null;
         var out:BitmapData = null;
         var i:int = 0;
         pickHideTexts(src,hidden);
         b = src.getBounds(src);
         if(b.width < 2 || b.height < 2)
         {
            while(i < hidden.length)
            {
               hidden[i].visible = true;
               i++;
            }
            return null;
         }
         sc = Math.max(cw / b.width,ch / (b.height * (1 - trim)));
         tmp = new BitmapData(cw,ch,true,0);
         tmp.draw(src,new Matrix(sc,0,0,sc,(cw - b.width * sc) / 2 - b.x * sc,ch - (b.y + b.height) * sc),null,null,new Rectangle(0,0,cw,ch),true);
         i = 0;
         while(i < hidden.length)
         {
            hidden[i].visible = true;
            i++;
         }
         cr = tmp.getColorBoundsRect(4278190080,0,false);
         if(cr.width < 2 || cr.height < 2)
         {
            tmp.dispose();
            return null;
         }
         out = new BitmapData(cw,ch,true,4279242776);
         out.copyPixels(tmp,new Rectangle(0,0,cw,ch),new Point(0,0),null,null,true);
         tmp.dispose();
         return out;
      }
      
      private static function pickGeneric(dim:Boolean) : BitmapData
      {
         var os:int = PICK_OVERSAMPLE;
         var bd:BitmapData = new BitmapData(int(PICK_ICON_W) * os,int(PICK_ROW_H) * os,true,4279769124);
         var tf:TextField = new TextField();
         tf.defaultTextFormat = new TextFormat("_sans",16 * os,dim ? 5592422 : 11579592,true);
         tf.autoSize = TextFieldAutoSize.LEFT;
         tf.text = "?";
         bd.draw(tf,new Matrix(1,0,0,1,(PICK_ICON_W * os - tf.width) / 2,(PICK_ROW_H * os - tf.height) / 2));
         return bd;
      }
      
      public static function syncBegin() : void
      {
         if(sync_abortTimer != null)
         {
            sync_abortTimer.stop();
            sync_abortTimer = null;
         }
         sync_abortManual = false;
         hold_start = 0;
         hold_warned = false;
         try
         {
            sync_matchId = String(m_roomData.matchSettings.levelData.randSeed);
         }
         catch(err:Error)
         {
            sync_matchId = "";
         }
         sync_ring = [];
         sync_checks = {};
         sync_peerChecks = {};
         sync_peerDetails = {};
         sync_myDetail = null;
         sync_reported = false;
         sync_firstFrame = -1;
      }
      
      public static function syncHash(s:String) : int
      {
         var h:int = 0;
         var i:int = 0;
         if(s == null)
         {
            return 0;
         }
         while(i < s.length)
         {
            h = h * 31 + s.charCodeAt(i) & 0xFFFFFF;
            i++;
         }
         return h;
      }
      
      public static function syncRecord(frame:int, n:Array, s:Array) : void
      {
         var peerSid:* = undefined;
         var entry:Object = {
            "f":frame,
            "n":n,
            "s":s
         };
         sync_ring.push(entry);
         while(sync_ring.length > SYNC_RING)
         {
            sync_ring.shift();
         }
         if(frame % SYNC_INTERVAL != 0)
         {
            return;
         }
         sync_checks[frame] = n;
         if(InRoom)
         {
            m_onlineInterface.sendSync({
               "k":"c",
               "m":sync_matchId,
               "f":frame,
               "n":n
            });
         }
         for(peerSid in sync_peerChecks)
         {
            syncCompare(String(peerSid),frame);
         }
         if(frame % 300 == 0)
         {
            syncPrune(frame - 300);
         }
      }
      
      private static function syncPrune(minFrame:int) : void
      {
         var k:* = undefined;
         var sid:* = undefined;
         for(k in sync_checks)
         {
            if(int(k) < minFrame)
            {
               delete sync_checks[k];
            }
         }
         for(sid in sync_peerChecks)
         {
            for(k in sync_peerChecks[sid])
            {
               if(int(k) < minFrame)
               {
                  delete sync_peerChecks[sid][k];
               }
            }
         }
      }
      
      private static function handlemgn_SYNC(e:MGNEvent) : void
      {
         var sid:String = String(e.data.sid);
         var d:Object = e.data.d;
         if(d == null || String(d.m) != sync_matchId)
         {
            return;
         }
         if(d.k == "x")
         {
            syncScheduleAbort(false);
         }
         else if(d.k == "q")
         {
            syncScheduleAbort(false,true,String(d.n));
         }
         else if(d.k == "c")
         {
            if(sync_peerChecks[sid] == null)
            {
               sync_peerChecks[sid] = {};
            }
            sync_peerChecks[sid][int(d.f)] = d.n;
            syncCompare(sid,int(d.f));
         }
         else if(d.k == "d")
         {
            sync_peerDetails[sid] = d.fr;
            if(sync_myDetail != null)
            {
               syncAnalyze(sid);
            }
         }
      }
      
      private static function syncPeerName(sid:String) : String
      {
         var i:int = 0;
         var players:Vector.<PlayerConnectionInfo> = Players;
         while(i < players.length)
         {
            if(players[i] != null && players[i].socket_id == sid)
            {
               return players[i].username;
            }
            i++;
         }
         return "?";
      }
      
      private static function syncWindow(frame:int) : Array
      {
         var out:Array = [];
         var i:int = 0;
         while(i < sync_ring.length)
         {
            if(int(sync_ring[i].f) >= frame - SYNC_BACK)
            {
               out.push(sync_ring[i]);
            }
            i++;
         }
         return out;
      }
      
      private static function syncCompare(sid:String, frame:int) : void
      {
         var theirs:Array = null;
         var k:* = undefined;
         var i:int = 0;
         var same:Boolean = true;
         var mine:Array = sync_checks[frame];
         if(mine == null || sync_peerChecks[sid] == null)
         {
            return;
         }
         theirs = sync_peerChecks[sid][frame];
         if(theirs == null)
         {
            return;
         }
         if(mine.length != theirs.length)
         {
            same = false;
         }
         while(same && i < mine.length)
         {
            if(mine[i] != theirs[i])
            {
               same = false;
            }
            i++;
         }
         if(same)
         {
            return;
         }
         if(sync_reported)
         {
            if(frame > sync_firstFrame)
            {
               syncScheduleAbort(true);
            }
            return;
         }
         sync_reported = true;
         sync_firstFrame = frame;
         sync_myDetail = syncWindow(frame);
         notify("DESYNC detected near frame " + frame + " (vs " + syncPeerName(sid) + "). Analyzing...");
         if(InRoom)
         {
            m_onlineInterface.sendSync({
               "k":"d",
               "m":sync_matchId,
               "f":frame,
               "fr":sync_myDetail
            });
         }
         for(k in sync_peerDetails)
         {
            syncAnalyze(String(k));
         }
      }
      
      private static function syncFieldText(field:int, v:*, names:Array, slot:int) : String
      {
         if(field <= 4)
         {
            return String(Number(v) / 100);
         }
         if(field == 7)
         {
            return String(names[slot * 3 + 1]);
         }
         if(field == 8)
         {
            return String(names[slot * 3 + 2]);
         }
         return String(v);
      }
      
      private static function syncAnalyze(sid:String) : void
      {
         var m:Object = null;
         var t:Object = null;
         var prev:Object = null;
         var diffs:Array = null;
         var idx:int = 0;
         var ctx:int = 0;
         var slot:int = 0;
         var field:int = 0;
         var desc:String = null;
         var others:String = "";
         var line1:String = null;
         var line2:String = null;
         var report:Array = null;
         var theirs:Array = sync_peerDetails[sid];
         var byFrame:Object = {};
         var peer:String = syncPeerName(sid);
         var first:int = -1;
         var overlap:int = 0;
         var i:int = 0;
         var j:int = 0;
         if(theirs == null || sync_myDetail == null)
         {
            return;
         }
         delete sync_peerDetails[sid];
         while(i < theirs.length)
         {
            byFrame[int(theirs[i].f)] = theirs[i];
            i++;
         }
         i = 0;
         while(i < sync_myDetail.length && first < 0)
         {
            m = sync_myDetail[i];
            t = byFrame[int(m.f)];
            if(t != null)
            {
               overlap++;
               diffs = [];
               j = 0;
               while(j < m.n.length && j < t.n.length)
               {
                  if(m.n[j] != t.n[j])
                  {
                     diffs.push(j);
                  }
                  j++;
               }
               if(diffs.length > 0)
               {
                  first = i;
               }
            }
            i++;
         }
         if(first < 0)
         {
            if(overlap == 0)
            {
               line1 = "vs " + peer + ": the two histories do not overlap, cannot locate the first difference.";
            }
            else
            {
               line1 = "vs " + peer + ": no difference in " + overlap + " shared frames (it started earlier).";
            }
            report = [line1];
         }
         else
         {
            idx = int(diffs[0]);
            ctx = idx == 0 && diffs.length > 1 ? int(diffs[1]) : idx;
            prev = first > 0 ? sync_myDetail[first - 1] : null;
            if(idx == 0)
            {
               desc = "RNG " + m.n[0] + " vs " + t.n[0];
            }
            else
            {
               slot = int((idx - 1) / 10);
               field = (idx - 1) % 10;
               desc = "P" + (slot + 1) + " (" + m.s[slot * 3] + ") " + sync_fieldNames[field] + " " + syncFieldText(field,m.n[idx],m.s,slot) + " vs " + syncFieldText(field,t.n[idx],t.s,slot);
            }
            j = 1;
            while(j < diffs.length && j < 4)
            {
               idx = int(diffs[j]);
               others += (idx == 0 ? " RNG" : " P" + (int((idx - 1) / 10) + 1) + "." + sync_fieldNames[(idx - 1) % 10]) + ",";
               j++;
            }
            line1 = "vs " + peer + " frame " + m.f + ": " + desc;
            if(others != "")
            {
               line1 += " | also:" + others;
            }
            if(ctx == 0)
            {
               line2 = "Only the RNG value differs: a Utils.random() call happened on one side only.";
            }
            else
            {
               slot = int((ctx - 1) / 10);
               line2 = "P" + (slot + 1) + " " + m.s[slot * 3] + " | before: " + (prev != null ? prev.s[slot * 3 + 1] + "/" + prev.s[slot * 3 + 2] : "?") + " | mine: " + m.s[slot * 3 + 1] + "/" + m.s[slot * 3 + 2] + " theirs: " + t.s[slot * 3 + 1] + "/" + t.s[slot * 3 + 2];
            }
            report = [line1,line2];
         }
         i = 0;
         while(i < report.length)
         {
            chatReceive("DESYNC",String(report[i]));
            i++;
         }
         notify("DESYNC " + String(report[0]));
      }
      
      private static function syncScheduleAbort(announce:Boolean, manual:Boolean = false, who:String = "") : void
      {
         if(sync_abortTimer != null)
         {
            return;
         }
         sync_abortManual = manual;
         sync_abortBy = who;
         if(announce && InRoom)
         {
            m_onlineInterface.sendSync({
               "k":(manual ? "q" : "x"),
               "m":sync_matchId,
               "n":who
            });
         }
         if(manual)
         {
            notify(who + " aborto la partida. Terminando en 2 segundos...");
         }
         else
         {
            notify("Desync confirmed. Ending the match in 3 seconds...");
         }
         sync_abortTimer = new Timer(manual ? 2000 : 3000,1);
         sync_abortTimer.addEventListener(TimerEvent.TIMER_COMPLETE,syncAbortNow);
         sync_abortTimer.start();
      }
      
      private static function syncAbortNow(e:TimerEvent) : void
      {
         var sd:* = GameController.stageData;
         sync_abortTimer = null;
         if(sd != null && Boolean(sd.OnlineMode) && !sd.WasReset)
         {
            notify(sync_abortManual ? "Partida abortada por " + sync_abortBy + "." : "Match ended because of the desync.");
            sendMatchAbortSignal();
            sd.endGame(true);
         }
      }
   }
}

