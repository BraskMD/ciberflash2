package com.mcleodgaming.ssf2.engine
{
   import com.mcleodgaming.ssf2.*;
   import com.mcleodgaming.ssf2.util.*;
   
   public class StageSetting
   {
      public function StageSetting()
      {
         super();
      }
      
      public static function getStagesArray(includeHidden:Boolean = false) : Vector.<String>
      {
         var i:int = 0;
         var settingsArray:Vector.<String> = new Vector.<String>();
         var mappings:Object = ResourceManager.getResourceByID("mappings").getProp("metadata");
         var stagesObj:Array = mappings.random_stages.stages;
         while(i < stagesObj.length)
         {
            if((Boolean(Main.DEBUG) || includeHidden || !includeHidden && SaveData.Unlocks[stagesObj[i]] !== false) && (Boolean(mappings.stage[stagesObj[i]]) || Boolean(mappings.stage_9b[stagesObj[i]])))
            {
               settingsArray.push(stagesObj[i]);
            }
            i++;
         }
         return settingsArray;
      }
      
      public static function getRandomStage(includeHidden:Boolean = false, includeDisabled:Boolean = false) : String
      {
         var settingsArray:Vector.<String> = getStagesArray(includeHidden);
         var i:int = int(settingsArray.length - 1);
         while(i >= 0 && !includeDisabled)
         {
            if(SaveData.VSStageDataObj[settingsArray[i]] === false)
            {
               settingsArray.splice(i,1);
            }
            i--;
         }
         if(settingsArray.length == 0)
         {
            return "battlefield";
         }
         return settingsArray[Utils.randomInteger(0,settingsArray.length - 1)];
      }
   }
}

