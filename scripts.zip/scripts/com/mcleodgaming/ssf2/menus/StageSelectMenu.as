package com.mcleodgaming.ssf2.menus
{
   import com.mcleodgaming.ssf2.*;
   import com.mcleodgaming.ssf2.audio.*;
   import com.mcleodgaming.ssf2.controllers.*;
   import com.mcleodgaming.ssf2.engine.*;
   import com.mcleodgaming.ssf2.fmc.*;
   import com.mcleodgaming.ssf2.net.*;
   import com.mcleodgaming.ssf2.util.*;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.*;
   
   public class StageSelectMenu extends Menu
   {
      private var stageButtons:Vector.<StageButton>;
      
      private var previewer:MovieClip;
      
      private var selectHand:StageSelectHand;
      
      protected var normalStageTable:DisplayObjectTable;
      
      protected var pastStageTable:DisplayObjectTable;
      
      protected var m_stageMCHash:Object;
      
      private var m_normal_btn:MovieClip;
      
      private var m_past_btn:MovieClip;
      
      private var m_unlockable_btn:MovieClip;
      
      private var m_other_btn:MovieClip;
      
      private var _rowsCurrent:int;
      
      private var _rowsMax:int;
      
      private var _game:Game;
      
      public function StageSelectMenu()
      {
         super();
         this._game = null;
         this.m_stageMCHash = {};
         m_subMenu = ResourceManager.getLibraryMC("menu_stageselect");
         m_backgroundID = "space";
         this.stageButtons = new Vector.<StageButton>();
         this.previewer = MovieClip(m_subMenu.stage_sample.previewer.addChild(ResourceManager.getLibraryMC("stagePreviewerFMC")));
         this.previewer.name = "mc";
         var mappings:Object = ResourceManager.getResourceByID("mappings").getProp("metadata");
         var normalStagesObj:Object = mappings.stage_select_screen.normal;
         this.normalStageTable = new DisplayObjectTable(new Rectangle(normalStagesObj.position.x,normalStagesObj.position.y,normalStagesObj.icon_size.width,normalStagesObj.icon_size.height));
         this._rowsCurrent = 1;
         this._rowsMax = normalStagesObj.rows_max;
         this.updateSSS();
         this.addIcons();
         this.selectHand = new StageSelectHand(m_subMenu,this.stageButtons,this.backCharSelect_CLICK);
         this.selectHand.addClickEventClipCheckBounds(m_subMenu.normal_btn);
         this.selectHand.addClickEventClipCheckBounds(m_subMenu.past_btn);
         this.selectHand.addClickEventClipHitTest(m_subMenu.bg_top.back_btn);
         this.selectHand.addClickEventClipHitTest(m_subMenu.hazardsbut);
         this.m_normal_btn = m_subMenu.normal_btn;
         this.m_past_btn = m_subMenu.past_btn;
         this.m_unlockable_btn = m_subMenu.unlockable_btn;
         this.m_other_btn = m_subMenu.other_btn;
         this.m_normal_btn.visible = false;
         this.m_past_btn.visible = false;
         this.m_unlockable_btn.visible = false;
         this.m_other_btn.visible = false;
         this.m_normal_btn.gotoAndStop("on");
         this.m_past_btn.gotoAndStop("off");
         this.m_unlockable_btn.gotoAndStop("off");
         this.m_other_btn.gotoAndStop("off");
         m_container.addChild(m_subMenu);
         m_subMenu.x = Main.Width / 2;
         m_subMenu.y = Main.Height / 2;
         this.m_stageMCHash["xpstage"].visible = false;
         this.normalStageTable.showAll();
         m_subMenu.stage_sample.creatorLabel.visible = false;
         m_subMenu.stage_sample.noteLabel.visible = false;
         m_subMenu.stage_sample.creator_txt.text = "";
         m_subMenu.stage_sample.note_txt.text = "";
         this.selectHand.addClickEventClipCheckBounds(m_subMenu.prevBtn);
         this.selectHand.addClickEventClipCheckBounds(m_subMenu.nextBtn);
      }
      
      public function get StageSelectionIconsMC() : MovieClip
      {
         return m_subMenu.stageSelect;
      }
      
      public function updateSSS() : void
      {
         var mappings:Object;
         var normalStagesObj:Object;
         var allStages:Array;
         var i:int = 0;
         var j:int = 0;
         var child:MovieClip = null;
         var key:String = null;
         var tmpBmp:Bitmap = null;
         var useFallback:Boolean = false;
         var iconError:String = "";
         m_subMenu.alternateBtn.visible = false;
         mappings = ResourceManager.getResourceByID("mappings").getProp("metadata");
         normalStagesObj = mappings.stage_select_screen.normal;
         allStages = Utils.flatten(normalStagesObj["rows_" + this._rowsCurrent] as Array);
         m_subMenu.pageTxt.text = normalStagesObj["rows_" + this._rowsCurrent + "_name"] || "PAGE " + this._rowsCurrent;
         while(0 < this.StageSelectionIconsMC.numChildren)
         {
            if(this.StageSelectionIconsMC.getChildAt(0) is MovieClip)
            {
               child = MovieClip(this.StageSelectionIconsMC.getChildAt(0));
               if(Boolean(child.mc) && child.mc.numChildren > 0)
               {
                  if(child.mc.getChildAt(0) is Bitmap)
                  {
                     child.mc.getChildAt(0).bitmapData.dispose();
                  }
               }
               child.parent.removeChild(child);
            }
         }
         if(this.stageButtons.length > 0)
         {
            this.stageButtons.splice(0,this.stageButtons.length);
         }
         for(key in this.m_stageMCHash)
         {
            this.m_stageMCHash[key] = null;
         }
         this.m_stageMCHash = {};
         this.stageButtons = new Vector.<StageButton>();
         this.m_stageMCHash["xpstage"] = m_subMenu.sxp;
         i = 0;
         while(i < allStages.length)
         {
            if(mappings.stage[allStages[i]] || allStages[i] === "xpstage" || allStages[i] === "random")
            {
               try
               {
                  child = null;
                  useFallback = false;
                  if(!FMCManager.getStage(allStages[i]))
                  {
                     child = MovieClip(ResourceManager.getLibraryMC(allStages[i] + "_stage_select"));
                  }
                  else
                  {
                     child = MovieClip(ResourceManager.getLibraryMC("template_stage_select"));
                     if(child == null)
                     {
                        useFallback = true;
                        child = MovieClip(ResourceManager.getLibraryMC("zcity_stage_select"));
                     }
                     if(child == null)
                     {
                        child = MovieClip(ResourceManager.getLibraryMC("battlefield_stage_select"));
                     }
                     if(child != null)
                     {
                        if(child.isAlternate)
                        {
                           child.isAlternate.visible = mappings.stage[allStages[i]].alternate_id != null;
                        }
                        tmpBmp = FMCManager.getStageBitmap(allStages[i]);
                        if(tmpBmp)
                        {
                           tmpBmp.scaleX = 0.203125;
                           tmpBmp.scaleY = 0.201389;
                           tmpBmp.x -= 25;
                           tmpBmp.y -= 15;
                           if(child.mc)
                           {
                              child.mc.addChild(tmpBmp);
                           }
                           else if(child.numChildren > 1)
                           {
                              child.addChildAt(tmpBmp,1);
                           }
                           else
                           {
                              child.addChild(tmpBmp);
                           }
                        }
                     }
                  }
                  if(child == null)
                  {
                     trace("[StageSelectMenu] No icon clip for stage: " + allStages[i]);
                     iconError = allStages[i] + ": no icon clip";
                     i++;
                     continue;
                  }
                  child.gotoAndStop(1);
                  if(useFallback)
                  {
                     child.stageID = allStages[i];
                  }
                  child.stageID = child.stageID || allStages[i];
                  this.m_stageMCHash[child.stageID] = child;
                  this.StageSelectionIconsMC.addChild(child);
                  this.stageButtons.push(new StageButton(GameController.currentGame,child,child.stageID));
               }
               catch(iconErr:Error)
               {
                  trace("[StageSelectMenu] Icon error for " + allStages[i] + ": " + iconErr.message);
                  iconError = allStages[i] + ": " + iconErr.message;
                  if(Boolean(child) && Boolean(child.parent))
                  {
                     child.parent.removeChild(child);
                  }
                  if(Boolean(child) && this.m_stageMCHash[allStages[i]] == child)
                  {
                     delete this.m_stageMCHash[allStages[i]];
                  }
               }
            }
            child = null;
            i++;
         }
         i = 0;
         while(i < m_subMenu.numChildren)
         {
            if(m_subMenu.getChildAt(i) is MovieClip)
            {
               child = MovieClip(m_subMenu.getChildAt(i));
               if(child.name === "normal_btn" || child.name === "past_btn")
               {
                  this.m_stageMCHash[child.name] = child;
               }
            }
            i++;
         }
         if(iconError != "")
         {
            m_subMenu.pageTxt.text = iconError.substr(0,70);
         }
      }
      
      public function addIcons() : void
      {
         var j:int = 0;
         this.normalStageTable.empty();
         var mappings:Object = ResourceManager.getResourceByID("mappings").getProp("metadata");
         var normalStagesObj:Object = mappings.stage_select_screen.normal;
         var i:int = 0;
         while(i < normalStagesObj["rows_" + this._rowsCurrent].length)
         {
            j = 0;
            while(j < normalStagesObj["rows_" + this._rowsCurrent][i].length)
            {
               if(this.m_stageMCHash[normalStagesObj["rows_" + this._rowsCurrent][i][j]] != null)
               {
                  this.normalStageTable.insertObject(i,this.m_stageMCHash[normalStagesObj["rows_" + this._rowsCurrent][i][j]]);
               }
               j++;
            }
            i++;
         }
         this.normalStageTable.fixDepths();
         this.normalStageTable.spaceObjects();
      }
      
      override public function makeEvents() : void
      {
         var i:int = 0;
         if(m_showCount == 0)
         {
            findSubMenuButtons();
            findSpecificMenuButtons(m_subMenu.bg_top);
            findSpecificMenuButtons(m_subMenu);
         }
         super.makeEvents();
         m_subMenu.prevBtn.addEventListener(MouseEvent.CLICK,this.prevBtn_CLICK);
         m_subMenu.nextBtn.addEventListener(MouseEvent.CLICK,this.nextBtn_CLICK);
         m_subMenu.bg_top.back_btn.addEventListener(MouseEvent.CLICK,this.backCharSelect_CLICK);
         m_subMenu.bg_top.back_btn.addEventListener(MouseEvent.MOUSE_OVER,this.backCharSelect_OVER);
         m_subMenu.hazardsbut.addEventListener(MouseEvent.CLICK,this.hazards_CLICK);
         this.m_normal_btn.addEventListener(MouseEvent.CLICK,this.showNormalStages);
         this.m_past_btn.addEventListener(MouseEvent.CLICK,this.showPastStages);
         this.m_other_btn.addEventListener(MouseEvent.CLICK,this.showOtherStages);
         this.selectHand.makeEvents();
         while(i < this.stageButtons.length)
         {
            this.stageButtons[i].makeEvents();
            i++;
         }
         this.updateFields();
      }
      
      override public function killEvents() : void
      {
         var i:int = 0;
         super.killEvents();
         m_subMenu.prevBtn.removeEventListener(MouseEvent.CLICK,this.prevBtn_CLICK);
         m_subMenu.nextBtn.removeEventListener(MouseEvent.CLICK,this.nextBtn_CLICK);
         m_subMenu.bg_top.back_btn.removeEventListener(MouseEvent.CLICK,this.backCharSelect_CLICK);
         m_subMenu.bg_top.back_btn.removeEventListener(MouseEvent.MOUSE_OVER,this.backCharSelect_OVER);
         m_subMenu.hazardsbut.removeEventListener(MouseEvent.CLICK,this.hazards_CLICK);
         this.m_normal_btn.removeEventListener(MouseEvent.CLICK,this.showNormalStages);
         this.m_past_btn.removeEventListener(MouseEvent.CLICK,this.showPastStages);
         this.m_other_btn.removeEventListener(MouseEvent.CLICK,this.showOtherStages);
         this.selectHand.killEvents();
         while(i < this.stageButtons.length)
         {
            this.stageButtons[i].killEvents();
            i++;
         }
      }
      
      private function updateFields() : void
      {
         if(!SaveData.Hazards)
         {
            m_subMenu.hazardsbut.gotoAndStop("off");
         }
         else
         {
            m_subMenu.hazardsbut.gotoAndStop("on");
         }
      }
      
      public function setCurrentGame(game:Game) : void
      {
         var i:int = 0;
         this._game = game;
         while(i < this.stageButtons.length)
         {
            this.stageButtons[i].setCurrentGame(game);
            i++;
         }
      }
      
      private function showNormalStages(e:MouseEvent) : void
      {
      }
      
      private function showPastStages(e:MouseEvent) : void
      {
      }
      
      private function showUnlockableStages(e:MouseEvent) : void
      {
      }
      
      private function showOtherStages(e:MouseEvent) : void
      {
      }
      
      private function resetAll() : void
      {
         this.normalStageTable.hideAll();
         this.m_normal_btn.gotoAndStop("off");
         this.m_past_btn.gotoAndStop("off");
         this.m_unlockable_btn.gotoAndStop("off");
         this.m_other_btn.gotoAndStop("off");
      }
      
      private function updateIcons() : void
      {
         var k:* = undefined;
         if(!Main.DEBUG)
         {
            for(k in this.m_stageMCHash)
            {
               if(SaveData.Unlocks[k] === false)
               {
                  this.m_stageMCHash[k].visible = false;
               }
            }
         }
         else
         {
            this.m_stageMCHash["xpstage"].visible = ResourceManager.getResourceByID("xpstage",true) != null;
         }
         Utils.setBrightness(this.m_unlockable_btn,-100);
         Utils.setBrightness(this.m_other_btn,-100);
         this.m_stageMCHash["xpstage"].visible = Main.DEBUG;
      }
      
      override public function show() : void
      {
         this.resetAll();
         this.normalStageTable.showAll();
         this.updateIcons();
         this.normalStageTable.spaceObjects();
         this.m_normal_btn.gotoAndStop("on");
         MovieClip(m_subMenu.stage_sample.previewer.getChildByName("mc")).gotoAndStop("paused");
         m_subMenu.stage_sample.stage_txt.text = "";
         this.selectHand.resetPosition();
         GameController.isStarted = false;
         super.show();
      }
      
      private function backCharSelect_CLICK(e:MouseEvent) : void
      {
         removeSelf();
         SoundQueue.instance.playSoundEffect("menu_back");
         MenuController.CurrentCharacterSelectMenu.show();
      }
      
      private function backCharSelect_OVER(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_hover");
      }
      
      private function hazards_CLICK(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_hover");
         SaveData.toggleHazards();
         if(Boolean(MenuController.CurrentCharacterSelectMenu) && Boolean(MenuController.CurrentCharacterSelectMenu.GameObj))
         {
            MenuController.CurrentCharacterSelectMenu.GameObj.LevelData.hazards = SaveData.Hazards;
         }
         this.updateFields();
      }
      
      protected function nextBtn_CLICK(e:MouseEvent) : void
      {
         var stageButton:StageButton = null;
         SoundQueue.instance.playSoundEffect("menu_hover");
         for each(stageButton in this.stageButtons)
         {
            stageButton.killEvents();
         }
         ++this._rowsCurrent;
         if(this._rowsCurrent > this._rowsMax)
         {
            this._rowsCurrent = 1;
         }
         this.updateSSS();
         this.addIcons();
         this.updateIcons();
         this.selectHand.replaceStageButtons(this.stageButtons);
         this.normalStageTable.spaceObjects();
         var i:int = 0;
         while(i < this.stageButtons.length)
         {
            this.stageButtons[i].setCurrentGame(this._game);
            this.stageButtons[i].makeEvents();
            i++;
         }
      }
      
      protected function prevBtn_CLICK(e:MouseEvent) : void
      {
         var stageButton:StageButton = null;
         SoundQueue.instance.playSoundEffect("menu_hover");
         for each(stageButton in this.stageButtons)
         {
            stageButton.killEvents();
         }
         --this._rowsCurrent;
         if(this._rowsCurrent <= 0)
         {
            this._rowsCurrent = this._rowsMax;
         }
         this.updateSSS();
         this.addIcons();
         this.updateIcons();
         this.selectHand.replaceStageButtons(this.stageButtons);
         this.normalStageTable.spaceObjects();
         var i:int = 0;
         while(i < this.stageButtons.length)
         {
            this.stageButtons[i].setCurrentGame(this._game);
            this.stageButtons[i].makeEvents();
            i++;
         }
      }
   }
}

