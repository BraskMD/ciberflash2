package com.mcleodgaming.ssf2.menus
{
   import com.mcleodgaming.mgn.events.*;
   import com.mcleodgaming.ssf2.*;
   import com.mcleodgaming.ssf2.audio.*;
   import com.mcleodgaming.ssf2.controllers.*;
   import com.mcleodgaming.ssf2.engine.*;
   import com.mcleodgaming.ssf2.enums.*;
   import com.mcleodgaming.ssf2.net.*;
   import com.mcleodgaming.ssf2.util.*;
   import flash.display.Sprite;
   import flash.events.*;
   import flash.text.TextField;
   import flash.text.TextFormat;
   
   public class OnlineCharacterMenu extends CharacterSelectMenu
   {
      private var m_voteBtn:Sprite;
      
      private var m_voteTxt:TextField;
      
      public function OnlineCharacterMenu(linkage:String)
      {
         super(linkage);
         m_playerLimit = 1;
         gameMode = Mode.ONLINE;
      }
      
      override public function reset() : void
      {
         super.reset();
         var i:int = 1;
         while(i < m_game.PlayerSettings.length)
         {
            m_game.PlayerSettings[i].exist = false;
            i++;
         }
         m_game.PlayerSettings[0].name = m_game.PlayerSettings[0].name || MultiplayerManager.Username.substr(0,10) || null;
         if(Boolean(SaveData.Controllers[0].GamepadInstance) && Boolean(m_game.PlayerSettings[0].name))
         {
            SaveData.reimportNamedPlayerControls(1,m_game.PlayerSettings[0].name);
         }
         if(MultiplayerManager.Connected)
         {
            m_game.LevelData.inputBuffer = MultiplayerManager.INPUT_BUFFER;
         }
         updateDisplay();
      }
      
      override public function show() : void
      {
         super.show();
         if(m_game)
         {
            m_game.GameMode = Mode.ONLINE;
            updateDisplay();
         }
         this.buildVoteToggle();
         SoundQueue.instance.playMusic("menumusic",0);
      }
      
      private function buildVoteToggle() : void
      {
         var px:Number = 0;
         var py:Number = 0;
         if(this.m_voteBtn != null && this.m_voteBtn.parent != null)
         {
            this.m_voteBtn.parent.removeChild(this.m_voteBtn);
         }
         this.m_voteBtn = null;
         if(!MultiplayerManager.IsHost)
         {
            return;
         }
         px = Main.Width / 2 - 196;
         py = Main.Height / 2 - 48;
         this.m_voteBtn = new Sprite();
         this.m_voteBtn.x = px;
         this.m_voteBtn.y = py;
         this.m_voteBtn.buttonMode = true;
         this.m_voteTxt = new TextField();
         this.m_voteTxt.defaultTextFormat = new TextFormat("_sans",9,16777215,true,false,null,null,null,"center");
         this.m_voteTxt.selectable = false;
         this.m_voteTxt.mouseEnabled = false;
         this.m_voteTxt.width = 172;
         this.m_voteTxt.height = 16;
         this.m_voteTxt.y = 4;
         this.m_voteBtn.addChild(this.m_voteTxt);
         this.m_voteBtn.addEventListener(MouseEvent.CLICK,this.voteToggle_CLICK);
         this.m_voteBtn.addEventListener(MouseEvent.ROLL_OVER,this.menu_open_ROLL_OVER);
         m_subMenu.addChild(this.m_voteBtn);
         this.updateVoteToggle();
      }
      
      private function updateVoteToggle() : void
      {
         var on:Boolean = SaveData.OnlineStageVote;
         var g:* = null;
         if(this.m_voteBtn == null)
         {
            return;
         }
         g = this.m_voteBtn.graphics;
         g.clear();
         g.beginFill(on ? 3070251 : 0);
         g.lineStyle(2,on ? 12582840 : 9361293);
         g.moveTo(8,0);
         g.lineTo(172,0);
         g.lineTo(164,22);
         g.lineTo(0,22);
         g.lineTo(8,0);
         g.endFill();
         this.m_voteTxt.textColor = on ? 736272 : 13234886;
         this.m_voteTxt.text = "VOTAR ESCENARIO: " + (on ? "SI" : "NO");
      }
      
      private function voteToggle_CLICK(e:MouseEvent) : void
      {
         e.stopPropagation();
         SaveData.OnlineStageVote = !SaveData.OnlineStageVote;
         SoundQueue.instance.playSoundEffect("menu_select");
         this.updateVoteToggle();
      }
      
      override public function makeEvents() : void
      {
         if(m_showCount == 0)
         {
            findSubMenuButtons();
            findSpecificMenuButtons(m_subMenu.bg_top);
         }
         super.makeEvents();
         m_subMenu.menu_open.addEventListener(MouseEvent.CLICK,this.menu_open_CLICK);
         m_subMenu.menu_open.addEventListener(MouseEvent.ROLL_OVER,this.menu_open_ROLL_OVER);
         m_subMenu.bnGameMode.addEventListener(MouseEvent.CLICK,this.gameMode_CLICK);
         m_subMenu.incShortcut.addEventListener(MouseEvent.CLICK,this.inc_CLICK);
         m_subMenu.decShortcut.addEventListener(MouseEvent.CLICK,this.dec_CLICK);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.LEAVE_ROOM,this.onLeaveRoom);
         MGNEventManager.dispatcher.addEventListener(MGNEvent.ERROR_LEAVE_ROOM,this.onLeaveRoomError);
      }
      
      override public function killEvents() : void
      {
         super.killEvents();
         m_subMenu.menu_open.removeEventListener(MouseEvent.CLICK,this.menu_open_CLICK);
         m_subMenu.menu_open.removeEventListener(MouseEvent.ROLL_OVER,this.menu_open_ROLL_OVER);
         m_subMenu.bnGameMode.removeEventListener(MouseEvent.CLICK,this.gameMode_CLICK);
         m_subMenu.incShortcut.removeEventListener(MouseEvent.CLICK,this.inc_CLICK);
         m_subMenu.decShortcut.removeEventListener(MouseEvent.CLICK,this.dec_CLICK);
         MGNEventManager.dispatcher.removeEventListener(MGNEvent.LEAVE_ROOM,this.onLeaveRoom);
         MGNEventManager.dispatcher.removeEventListener(MGNEvent.ERROR_LEAVE_ROOM,this.onLeaveRoomError);
      }
      
      override public function initMatch() : void
      {
         SoundQueue.instance.playSoundEffect("menu_selectstage");
         MenuController.CurrentCharacterSelectMenu.removeSelf();
         if(MultiplayerManager.IsHost)
         {
            MenuController.stageSelectMenu.setCurrentGame(MenuController.CurrentCharacterSelectMenu.GameObj);
            MenuController.stageSelectMenu.show();
         }
         else
         {
            MenuController.pleaseWaitMenu.show();
            MultiplayerManager.toWaitingRoom(m_game,this.waitingRoomReady);
         }
      }
      
      private function waitingRoomReady(e:* = null) : void
      {
         MenuController.disposeAllMenus();
         GameController.startMatch(m_game);
      }
      
      override public function backMain_CLICK(e:MouseEvent) : void
      {
         if(MultiplayerManager.IsHost)
         {
            super.backMain_CLICK(e);
            MenuController.onlineGroupMenu.show();
         }
         else
         {
            MultiplayerManager.leaveRoom();
            m_container.visible = false;
         }
      }
      
      private function onLeaveRoom(e:MGNEvent) : void
      {
         m_container.visible = true;
         super.backMain_CLICK(null);
         MenuController.onlineMenu.show();
         MenuController.onlineMenu.refreshRoomsList();
      }
      
      private function onLeaveRoomError(e:MGNEvent) : void
      {
         m_container.visible = true;
      }
      
      public function menu_open_CLICK(e:MouseEvent) : void
      {
         if(hasVisibleKeypad())
         {
            SoundQueue.instance.playSoundEffect("menu_error");
            return;
         }
         SoundQueue.instance.playSoundEffect("menu_select");
         MenuController.rulesMenu.show();
      }
      
      public function menu_open_ROLL_OVER(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_hover");
      }
      
      public function gameMode_CLICK(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_hover");
         toggleGameMode();
      }
      
      protected function inc_CLICK(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_hover");
         incrementShortcut();
      }
      
      protected function dec_CLICK(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_hover");
         decrementShortcut();
      }
   }
}

