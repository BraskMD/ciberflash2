package com.mcleodgaming.ssf2.menus
{
   import com.mcleodgaming.ssf2.*;
   import com.mcleodgaming.ssf2.audio.*;
   import com.mcleodgaming.ssf2.controllers.*;
   import com.mcleodgaming.ssf2.engine.*;
   import com.mcleodgaming.ssf2.enums.*;
   import com.mcleodgaming.ssf2.fmc.*;
   import com.mcleodgaming.ssf2.net.*;
   import com.mcleodgaming.ssf2.util.*;
   import flash.display.Bitmap;
   import flash.display.BitmapData;
   import flash.display.DisplayObject;
   import flash.display.MovieClip;
   import flash.display.Shape;
   import flash.display.Sprite;
   import flash.events.*;
   import flash.filters.DropShadowFilter;
   import flash.geom.Matrix;
   import flash.geom.Rectangle;
   import flash.text.TextField;
   import flash.text.TextFieldAutoSize;
   import flash.text.TextFieldType;
   import flash.text.TextFormat;
   import flash.ui.Keyboard;
   import flash.utils.*;
   
   public class VaultMenu extends Menu
   {
      private static var s_prompt:Sprite;
      
      private static var s_input:TextField;
      
      private static var s_data:ReplayData;
      
      private static var s_default:String;
      
      private static var s_fade:BitmapData;
      
      private static const RP_C_DK:int = 1006100;
      
      private static const RP_C_LN:int = 2074666;
      
      private static const RP_C_TAB:int = 9426829;
      
      private static const RP_C_TABD:int = 6272094;
      
      private static const RP_C_LT:int = 12449208;
      
      private static const RP_C_BR:int = 2873643;
      
      private static const RP_C_TXT:int = 736528;
      
      private static const RP_C_CREAM:int = 16509382;
      
      private static const RP_PCOL:Array = [14170159,3108824,14922267,3123279,9323721,2078153,14710571,14243228];
      
      private static const RP_ROWS:int = 5;
      
      private static const RP_ROW_H:int = 36;
      
      private static const RP_LIST_X:int = 44;
      
      private static const RP_LIST_Y:int = 60;
      
      private static const RP_FOLDER:String = "replays";
      
      private static const RP_DEBUG:Boolean = true;
      
      private static var s_restoreKeys:Boolean = false;
      
      private static var s_refocus:Boolean = false;
      
      private var m_replayNode:MenuMapperNode;
      
      private var m_introNode:MenuMapperNode;
      
      private var m_intro2Node:MenuMapperNode;
      
      private var m_intro3Node:MenuMapperNode;
      
      protected var m_loadingMask:MovieClip;
      
      private var rp_active:Boolean = false;
      
      private var rp_mapper:MenuMapper;
      
      private var rp_vaultMapper:MenuMapper;
      
      private var rp_hidden:Array;
      
      private var rp_ui:MovieClip;
      
      private var rp_rows:Array;
      
      private var rp_entries:Array;
      
      private var rp_cache:Object;
      
      private var rp_icons:Object;
      
      private var rp_sel:int = 0;
      
      private var rp_top:int = 0;
      
      private var rp_detail:Sprite;
      
      private var rp_info:Sprite;
      
      private var rp_thumb:Shape;
      
      private var rp_page:TextField;
      
      private var rp_empty:TextField;
      
      private var rp_node:MenuMapperNode;
      
      private var rp_backBtn:Sprite;
      
      private var rp_path:TextField;
      
      private var rp_pvErr:String = "";
      
      public function VaultMenu()
      {
         super();
         m_subMenu = ResourceManager.getLibraryMC("menu_vault");
         m_backgroundID = "space";
         m_container.addChild(m_subMenu);
         this.initMenuMappings();
         m_subMenu.x = Main.Width / 2;
         m_subMenu.y = Main.Height / 2;
         this.m_loadingMask = ResourceManager.getLibraryMC("loadingMask");
         this.m_loadingMask.x = Main.Width / 2;
         this.m_loadingMask.y = Main.Height / 2;
      }
      
      private static function rpText(parent:Sprite, s:String, x:Number, y:Number, size:int, color:int, w:Number = 0, align:String = "left") : TextField
      {
         var tf:TextField = new TextField();
         tf.defaultTextFormat = new TextFormat("_sans",size,color,true,false,null,null,null,align);
         tf.selectable = false;
         tf.mouseEnabled = false;
         tf.multiline = false;
         tf.wordWrap = false;
         if(w > 0)
         {
            tf.width = w;
            tf.height = size + 6;
         }
         else
         {
            tf.autoSize = TextFieldAutoSize.LEFT;
         }
         tf.text = s;
         tf.x = x;
         tf.y = y;
         parent.addChild(tf);
         return tf;
      }
      
      private static function rpFit(tf:TextField, s:String, maxW:Number) : void
      {
         var t:String = s;
         tf.text = t;
         while(tf.textWidth > maxW && t.length > 1)
         {
            t = t.substr(0,t.length - 1);
            tf.text = t + "...";
         }
      }
      
      private static function rpPoly(g:*, pts:Array) : void
      {
         var i:int = 1;
         g.moveTo(pts[0][0],pts[0][1]);
         while(i < pts.length)
         {
            g.lineTo(pts[i][0],pts[i][1]);
            i++;
         }
         g.lineTo(pts[0][0],pts[0][1]);
      }
      
      private static function rpPad(n:int) : String
      {
         return n < 10 ? "0" + n : "" + n;
      }
      
      private static function rpDate(d:Date) : String
      {
         return d.getFullYear() + "-" + rpPad(d.getMonth() + 1) + "-" + rpPad(d.getDate()) + " " + rpPad(d.getHours()) + ":" + rpPad(d.getMinutes());
      }
      
      private static function rpLen(frames:int) : String
      {
         var secs:int = int(frames / 60);
         return int(secs / 60) + ":" + rpPad(secs % 60);
      }
      
      private static function rpMode(m:int) : String
      {
         if(m == Mode.ONLINE)
         {
            return "Online";
         }
         if(m == Mode.ONLINE_ARENA)
         {
            return "Arena online";
         }
         if(m == Mode.ARENA)
         {
            return "Arena";
         }
         if(m == Mode.TARGET_TEST)
         {
            return "Targets";
         }
         if(m == Mode.HOME_RUN_CONTEST)
         {
            return "Home-Run";
         }
         if(m == Mode.MULTIMAN)
         {
            return "Multi-man";
         }
         if(m == Mode.CRYSTAL_SMASH)
         {
            return "Cristales";
         }
         return "Versus";
      }
      
      public static function replaysFolder() : *
      {
         var FileClass:Class = Class(getDefinitionByName("flash.filesystem.File"));
         var dir:* = null;
         try
         {
            dir = FileClass.applicationDirectory.resolvePath(RP_FOLDER);
            if(!dir.exists)
            {
               dir.createDirectory();
            }
            if(!dir.isDirectory)
            {
               dir = null;
            }
         }
         catch(err:Error)
         {
            dir = null;
         }
         if(dir == null)
         {
            dir = FileClass.userDirectory.resolvePath("SSF2Replays");
            try
            {
               if(!dir.exists)
               {
                  dir.createDirectory();
               }
            }
            catch(err2:Error)
            {
            }
         }
         return dir;
      }
      
      private static function rpRead(f:*) : ByteArray
      {
         var FSClass:Class = Class(getDefinitionByName("flash.filesystem.FileStream"));
         var fs:* = new FSClass();
         var ba:ByteArray = new ByteArray();
         fs.open(f,"read");
         fs.readBytes(ba,0,fs.bytesAvailable);
         fs.close();
         return ba;
      }
      
      private static function rpLoad(f:*) : ReplayData
      {
         var ba:ByteArray = null;
         var rd:ReplayData = null;
         try
         {
            ba = rpRead(f);
            ba.uncompress();
            rd = new ReplayData(Main.MAXPLAYERS);
            rd.importReplay(ba.readUTF());
         }
         catch(err:Error)
         {
            return null;
         }
         return rd;
      }
      
      private static function rpCompat(rd:ReplayData) : Boolean
      {
         return rd.VersionNumber == Version.getVersion() || ReplayData.COMPATIBLE_VERSIONS.indexOf(rd.VersionNumber) >= 0;
      }
      
      private static function rpFadeMask(w:int, h:int) : BitmapData
      {
         var bd:BitmapData = null;
         var x:int = 0;
         var y:int = 0;
         var a:Number = 0;
         var av:Number = 0;
         var ah:Number = 0;
         var tt:Number = 0;
         if(s_fade != null && s_fade.width == w && s_fade.height == h)
         {
            return s_fade;
         }
         bd = new BitmapData(w,h,true,0);
         while(y < h)
         {
            tt = y / h;
            av = tt < 0.45 ? 1 : Math.pow(1 - (tt - 0.45) / 0.55,1.3);
            x = 0;
            while(x < w)
            {
               ah = Math.min(1,Math.min(x / (w * 0.4),(w - 1 - x) / (w * 0.12)));
               a = av * ah;
               bd.setPixel32(x,y,uint(int(a * 255) << 24 | 0xFFFFFF));
               x++;
            }
            y++;
         }
         s_fade = bd;
         return bd;
      }
      
      public static function startReplay(loadedReplayData:ReplayData) : void
      {
         MenuController.removeAllMenus();
         if(loadedReplayData.GameMode === Mode.ONLINE)
         {
            MenuController.vsMenu.reset();
            MenuController.CurrentCharacterSelectMenu = MenuController.vsMenu;
            GameController.currentGame = new Game(loadedReplayData.PlayerData.length,Mode.VS);
         }
         else if(loadedReplayData.GameMode === Mode.ONLINE_ARENA || loadedReplayData.GameMode === Mode.ARENA)
         {
            MenuController.arenaCharacterSelectMenu.reset();
            MenuController.CurrentCharacterSelectMenu = MenuController.arenaCharacterSelectMenu;
            GameController.currentGame = new Game(loadedReplayData.PlayerData.length,Mode.ARENA);
         }
         else if(loadedReplayData.GameMode === Mode.TARGET_TEST)
         {
            MenuController.targetTestMenu.reset();
            MenuController.CurrentCharacterSelectMenu = MenuController.targetTestMenu;
            GameController.currentGame = new Game(loadedReplayData.PlayerData.length,Mode.TARGET_TEST);
         }
         else if(loadedReplayData.GameMode === Mode.HOME_RUN_CONTEST)
         {
            MenuController.homeRunContestMenu.reset();
            MenuController.CurrentCharacterSelectMenu = MenuController.homeRunContestMenu;
            GameController.currentGame = new Game(loadedReplayData.PlayerData.length,Mode.HOME_RUN_CONTEST);
         }
         else if(loadedReplayData.GameMode === Mode.MULTIMAN)
         {
            MenuController.multimanCharacterSelectMenu.reset();
            MenuController.CurrentCharacterSelectMenu = MenuController.multimanCharacterSelectMenu;
            GameController.currentGame = new Game(loadedReplayData.PlayerData.length,Mode.MULTIMAN);
         }
         else if(loadedReplayData.GameMode === Mode.CRYSTAL_SMASH)
         {
            MenuController.crystalSmashCharacterMenu.reset();
            MenuController.CurrentCharacterSelectMenu = MenuController.crystalSmashCharacterMenu;
            GameController.currentGame = new Game(loadedReplayData.PlayerData.length,Mode.CRYSTAL_SMASH);
         }
         else
         {
            MenuController.vsMenu.reset();
            MenuController.CurrentCharacterSelectMenu = MenuController.vsMenu;
            GameController.currentGame = new Game(loadedReplayData.PlayerData.length,loadedReplayData.GameMode);
         }
         MenuController.CurrentCharacterSelectMenu.GameObj.ReplayDataObj = loadedReplayData;
         MenuController.CurrentCharacterSelectMenu.initReplay();
      }
      
      private static function rpClean(s:String) : String
      {
         var t:String = s == null ? "" : s;
         t = t.replace(/[\\\/:*?"<>|\r\n\t]/g,"");
         t = t.replace(/^\s+|[\s.]+$/g,"");
         if(t.length > 80)
         {
            t = t.substr(0,80);
         }
         return t;
      }
      
      public static function saveReplayFile(rd:ReplayData, name:String) : String
      {
         var base:String = rpClean(name);
         var ba:ByteArray = new ByteArray();
         var dir:* = null;
         var f:* = null;
         var n:int = 1;
         var FSClass:Class = Class(getDefinitionByName("flash.filesystem.FileStream"));
         var fs:* = null;
         var tries:int = 0;
         var finalName:String = null;
         if(base == "")
         {
            base = rpClean(s_default);
         }
         if(base == "")
         {
            base = "Replay";
         }
         rd.Name = base;
         ba.writeUTF(rd.exportReplay());
         ba.compress();
         while(tries < 2)
         {
            dir = tries == 0 ? replaysFolder() : Class(getDefinitionByName("flash.filesystem.File")).userDirectory.resolvePath("SSF2Replays");
            try
            {
               if(!dir.exists)
               {
                  dir.createDirectory();
               }
               n = 1;
               finalName = base;
               f = dir.resolvePath(finalName + ".ssfrec");
               while(f.exists && n < 500)
               {
                  n++;
                  finalName = base + " (" + n + ")";
                  f = dir.resolvePath(finalName + ".ssfrec");
               }
               fs = new FSClass();
               fs.open(f,"write");
               fs.writeBytes(ba,0,ba.length);
               fs.close();
               return finalName;
            }
            catch(err:Error)
            {
               tries++;
            }
         }
         return null;
      }
      
      public static function promptSave(rd:ReplayData, defaultName:String) : void
      {
         var W:Number = Main.Width;
         var H:Number = Main.Height;
         var box:Sprite = new Sprite();
         var dim:Sprite = new Sprite();
         var mt:Matrix = new Matrix();
         var tab:Shape = new Shape();
         var ok:Sprite = new Sprite();
         var no:Sprite = new Sprite();
         var fld:Shape = new Shape();
         if(s_prompt != null)
         {
            return;
         }
         s_data = rd;
         s_default = defaultName;
         s_prompt = new Sprite();
         dim.graphics.beginFill(0,0.65);
         dim.graphics.drawRect(-2,-2,W + 4,H + 4);
         dim.graphics.endFill();
         dim.buttonMode = false;
         s_prompt.addChild(dim);
         box.x = (W - 330) / 2;
         box.y = (H - 138) / 2;
         mt.createGradientBox(330,138,0,0,0);
         box.graphics.beginGradientFill("linear",[2830893,658699,0],[1,1,1],[0,160,255],mt);
         box.graphics.lineStyle(1.5,16777215);
         box.graphics.drawRect(0,0,330,138);
         box.graphics.endFill();
         tab.graphics.beginFill(RP_C_TAB);
         rpPoly(tab.graphics,[[-6,-13],[170,-13],[162,9],[-6,9]]);
         tab.graphics.endFill();
         box.addChild(tab);
         rpText(box,"GUARDAR REPLAY",-4,-11,12,RP_C_TXT,164,"center");
         rpText(box,"NOMBRE",14,18,8,RP_C_LT);
         fld.graphics.beginFill(0);
         fld.graphics.lineStyle(1.5,9282446);
         fld.graphics.drawRect(14,32,302,24);
         fld.graphics.endFill();
         box.addChild(fld);
         s_input = new TextField();
         s_input.defaultTextFormat = new TextFormat("_sans",10,16777215,true);
         s_input.type = TextFieldType.INPUT;
         s_input.maxChars = 80;
         s_input.x = 20;
         s_input.y = 36;
         s_input.width = 290;
         s_input.height = 17;
         s_input.text = defaultName;
         box.addChild(s_input);
         rpText(box,"Se guardara en la carpeta replays junto al juego.",14,62,7,10991784);
         rpText(box,"Si lo dejas vacio se usa el nombre por defecto.",14,73,7,10991784);
         ok.graphics.beginFill(RP_C_TAB);
         rpPoly(ok.graphics,[[7,0],[116,0],[109,24],[0,24]]);
         ok.graphics.endFill();
         ok.x = 200;
         ok.y = 100;
         ok.buttonMode = true;
         rpText(ok,"GUARDAR",0,5,11,RP_C_TXT,116,"center");
         ok.addEventListener(MouseEvent.CLICK,promptConfirm);
         no.graphics.beginFill(1712155);
         no.graphics.lineStyle(1,6979692);
         rpPoly(no.graphics,[[7,0],[116,0],[109,24],[0,24]]);
         no.graphics.endFill();
         no.x = 14;
         no.y = 100;
         no.buttonMode = true;
         rpText(no,"CANCELAR",0,5,11,13688016,116,"center");
         no.addEventListener(MouseEvent.CLICK,promptCancel);
         box.addChild(ok);
         box.addChild(no);
         s_prompt.addChild(box);
         Main.Root.addChild(s_prompt);
         s_restoreKeys = Key.CaptureStarted;
         if(s_restoreKeys)
         {
            Key.endCapture();
         }
         Main.Root.stage.addEventListener(KeyboardEvent.KEY_DOWN,promptKey,false,200);
         Main.Root.stage.addEventListener(Event.ENTER_FRAME,promptTick);
         s_input.addEventListener(FocusEvent.FOCUS_OUT,promptFocusOut);
         Main.setFocus(s_input);
         s_input.setSelection(0,s_input.text.length);
      }
      
      private static function promptFocusOut(e:FocusEvent) : void
      {
         s_refocus = true;
      }
      
      private static function promptTick(e:Event) : void
      {
         if(s_prompt == null)
         {
            return;
         }
         if(Main.Root.getChildIndex(s_prompt) != Main.Root.numChildren - 1)
         {
            Main.Root.setChildIndex(s_prompt,Main.Root.numChildren - 1);
         }
         if(s_refocus)
         {
            s_refocus = false;
            if(Main.Root.stage.focus == null || Main.Root.stage.focus == Main.Root.stage)
            {
               Main.setFocus(s_input);
               s_input.setSelection(s_input.text.length,s_input.text.length);
            }
         }
      }
      
      private static function promptKey(e:KeyboardEvent) : void
      {
         if(s_prompt == null)
         {
            return;
         }
         if(e.keyCode == Keyboard.ESCAPE)
         {
            promptCancel(null);
         }
         else if(e.keyCode == Keyboard.ENTER)
         {
            promptConfirm(null);
         }
         e.stopImmediatePropagation();
      }
      
      private static function promptClose() : void
      {
         Main.Root.stage.removeEventListener(KeyboardEvent.KEY_DOWN,promptKey);
         Main.Root.stage.removeEventListener(Event.ENTER_FRAME,promptTick);
         if(s_prompt != null && s_prompt.parent != null)
         {
            s_prompt.parent.removeChild(s_prompt);
         }
         s_prompt = null;
         s_input = null;
         s_data = null;
         Main.fixFocus();
         if(s_restoreKeys)
         {
            Key.beginCapture(Main.Root.stage);
            s_restoreKeys = false;
         }
      }
      
      private static function promptCancel(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_back");
         promptClose();
      }
      
      private static function promptConfirm(e:MouseEvent) : void
      {
         var rd:ReplayData = s_data;
         var typed:String = s_input != null ? s_input.text : "";
         var saved:String = null;
         promptClose();
         if(rd == null)
         {
            return;
         }
         saved = saveReplayFile(rd,typed);
         MultiplayerManager.makeNotifier();
         if(saved != null)
         {
            SoundQueue.instance.playSoundEffect("menu_select");
            MultiplayerManager.notify("Replay guardado: " + saved);
         }
         else
         {
            MultiplayerManager.notify("No se pudo guardar el replay.");
         }
      }
      
      override public function initMenuMappings() : void
      {
         this.m_replayNode = new MenuMapperNode(m_subMenu.replays_btn);
         this.m_introNode = new MenuMapperNode(m_subMenu.intro_btn);
         this.m_intro2Node = new MenuMapperNode(m_subMenu.intro2_btn);
         this.m_intro3Node = new MenuMapperNode(m_subMenu.intro3_btn);
         this.m_replayNode.updateNodes(null,null,[this.m_intro3Node],[this.m_introNode],this.replay_MOUSE_OVER,null,this.replay_CLICK,this.back_CLICK_vault,null,null);
         this.m_introNode.updateNodes(null,null,[this.m_replayNode],[this.m_intro2Node],this.intro_MOUSE_OVER,null,this.play_intro,this.back_CLICK_vault,null,null);
         this.m_intro2Node.updateNodes(null,null,[this.m_introNode],[this.m_intro3Node],this.intro2_MOUSE_OVER,null,this.play_intro2,this.back_CLICK_vault,null,null);
         this.m_intro3Node.updateNodes(null,null,[this.m_intro2Node],[this.m_replayNode],this.intro3_MOUSE_OVER,null,this.play_intro3,this.back_CLICK_vault,null,null);
         m_menuMapper = new MenuMapper(this.m_replayNode);
         m_menuMapper.init();
      }
      
      override public function show() : void
      {
         this.rpClose();
         super.show();
         SoundQueue.instance.playMusic("menumusic",0);
      }
      
      override public function makeEvents() : void
      {
         if(m_showCount == 0)
         {
            findSubMenuButtons();
            findSpecificMenuButtons(m_subMenu.bg_top);
         }
         super.makeEvents();
         resetAllButtons();
         m_subMenu.bg_top.back_btn.addEventListener(MouseEvent.CLICK,this.back_CLICK_vault);
         m_subMenu.bg_top.back_btn.addEventListener(MouseEvent.ROLL_OVER,this.back_ROLL_OVER_vault);
         m_subMenu.intro_btn.addEventListener(MouseEvent.CLICK,this.play_intro);
         m_subMenu.intro2_btn.addEventListener(MouseEvent.CLICK,this.play_intro2);
         m_subMenu.intro3_btn.addEventListener(MouseEvent.CLICK,this.play_intro3);
         m_subMenu.intro_btn.addEventListener(MouseEvent.MOUSE_OVER,this.intro_MOUSE_OVER);
         m_subMenu.intro2_btn.addEventListener(MouseEvent.MOUSE_OVER,this.intro2_MOUSE_OVER);
         m_subMenu.intro3_btn.addEventListener(MouseEvent.MOUSE_OVER,this.intro3_MOUSE_OVER);
         m_subMenu.intro_btn.addEventListener(MouseEvent.MOUSE_OUT,this.intro_MOUSE_OUT);
         m_subMenu.intro2_btn.addEventListener(MouseEvent.MOUSE_OUT,this.intro_MOUSE_OUT);
         m_subMenu.intro3_btn.addEventListener(MouseEvent.MOUSE_OUT,this.intro_MOUSE_OUT);
         m_subMenu.replays_btn.addEventListener(MouseEvent.CLICK,this.replay_CLICK);
         m_subMenu.replays_btn.addEventListener(MouseEvent.MOUSE_OVER,this.replay_MOUSE_OVER);
         m_subMenu.replays_btn.addEventListener(MouseEvent.MOUSE_OUT,this.replay_MOUSE_OUT);
         m_subMenu.bg_top.home_btn.addEventListener(MouseEvent.CLICK,this.home_CLICK);
         Main.Root.stage.addEventListener(Event.ENTER_FRAME,manageMenuMappings);
         Main.Root.stage.addEventListener(Event.ENTER_FRAME,this.rpTick);
         setMenuMappingFocus();
      }
      
      override public function killEvents() : void
      {
         super.killEvents();
         m_subMenu.bg_top.back_btn.removeEventListener(MouseEvent.CLICK,this.back_CLICK_vault);
         m_subMenu.bg_top.back_btn.removeEventListener(MouseEvent.ROLL_OVER,this.back_ROLL_OVER_vault);
         m_subMenu.intro_btn.removeEventListener(MouseEvent.CLICK,this.play_intro);
         m_subMenu.intro2_btn.removeEventListener(MouseEvent.CLICK,this.play_intro2);
         m_subMenu.intro3_btn.removeEventListener(MouseEvent.CLICK,this.play_intro3);
         m_subMenu.intro_btn.removeEventListener(MouseEvent.MOUSE_OVER,this.intro_MOUSE_OVER);
         m_subMenu.intro2_btn.removeEventListener(MouseEvent.MOUSE_OVER,this.intro2_MOUSE_OVER);
         m_subMenu.intro3_btn.removeEventListener(MouseEvent.MOUSE_OVER,this.intro3_MOUSE_OVER);
         m_subMenu.intro_btn.removeEventListener(MouseEvent.MOUSE_OUT,this.intro_MOUSE_OUT);
         m_subMenu.intro2_btn.removeEventListener(MouseEvent.MOUSE_OUT,this.intro_MOUSE_OUT);
         m_subMenu.intro3_btn.removeEventListener(MouseEvent.MOUSE_OUT,this.intro_MOUSE_OUT);
         m_subMenu.replays_btn.removeEventListener(MouseEvent.CLICK,this.replay_CLICK);
         m_subMenu.replays_btn.removeEventListener(MouseEvent.MOUSE_OVER,this.replay_MOUSE_OVER);
         m_subMenu.replays_btn.removeEventListener(MouseEvent.MOUSE_OUT,this.replay_MOUSE_OUT);
         m_subMenu.bg_top.home_btn.removeEventListener(MouseEvent.CLICK,this.home_CLICK);
         Main.Root.stage.removeEventListener(Event.ENTER_FRAME,manageMenuMappings);
         Main.Root.stage.removeEventListener(Event.ENTER_FRAME,this.rpTick);
      }
      
      private function play_intro(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_selectstage");
         if(ResourceManager.getResourceByID("ssf2intro_v8").Loaded)
         {
            SoundQueue.instance.stopMusic();
            removeSelf();
            if(!MenuController.introMenu)
            {
               MenuController.introMenu = new IntroMenu();
            }
            MenuController.introMenu.show();
         }
         else
         {
            Main.Root.addChild(this.m_loadingMask);
            ResourceManager.queueResources(["ssf2intro_v8"]);
            ResourceManager.load({"oncomplete":this.introLoaded});
         }
      }
      
      private function introLoaded(e:Event = null) : void
      {
         SoundQueue.instance.stopMusic();
         removeSelf();
         Main.Root.removeChild(this.m_loadingMask);
         if(!MenuController.introMenu)
         {
            MenuController.introMenu = new IntroMenu();
         }
         MenuController.introMenu.show();
      }
      
      private function play_intro2(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_selectstage");
         if(ResourceManager.getResourceByID("ssf2intro_v9").Loaded)
         {
            SoundQueue.instance.stopMusic();
            removeSelf();
            if(!MenuController.intro2Menu)
            {
               MenuController.intro2Menu = new Intro2Menu();
            }
            MenuController.intro2Menu.show();
         }
         else
         {
            Main.Root.addChild(this.m_loadingMask);
            ResourceManager.queueResources(["ssf2intro_v9"]);
            ResourceManager.load({"oncomplete":this.intro2Loaded});
         }
      }
      
      private function intro2Loaded(e:Event = null) : void
      {
         SoundQueue.instance.stopMusic();
         removeSelf();
         Main.Root.removeChild(this.m_loadingMask);
         if(!MenuController.intro2Menu)
         {
            MenuController.intro2Menu = new Intro2Menu();
         }
         MenuController.intro2Menu.show();
      }
      
      private function play_intro3(e:MouseEvent) : void
      {
         removeSelf();
         SoundQueue.instance.playSoundEffect("menu_selectstage");
         SoundQueue.instance.stopMusic();
         MenuController.intro3Menu.setVault(true);
         MenuController.intro3Menu.show();
      }
      
      private function intro_MOUSE_OVER(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_hover");
         m_subMenu.desc_txt.text = "Watch the SSF2 v0.8 Intro.";
      }
      
      private function intro2_MOUSE_OVER(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_hover");
         m_subMenu.desc_txt.text = "Watch the SSF2 v0.9 Intro.";
      }
      
      private function intro3_MOUSE_OVER(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_hover");
         m_subMenu.desc_txt.text = "Watch the SSF2 Beta Intro.";
      }
      
      private function intro_MOUSE_OUT(e:MouseEvent) : void
      {
         if(m_subMenu.desc_txt != null)
         {
            m_subMenu.desc_txt.text = "";
         }
      }
      
      private function replay_CLICK(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_select");
         this.rpOpen();
      }
      
      private function replay_MOUSE_OVER(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_hover");
         m_subMenu.desc_txt.text = "Re-watch all the action!";
      }
      
      private function replay_MOUSE_OUT(e:MouseEvent) : void
      {
         if(m_subMenu.desc_txt != null)
         {
            m_subMenu.desc_txt.text = "";
         }
      }
      
      private function back_CLICK_vault(e:MouseEvent) : void
      {
         removeSelf();
         SoundQueue.instance.playSoundEffect("menu_back");
         MenuController.mainMenu.show();
      }
      
      private function back_ROLL_OVER_vault(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_hover");
      }
      
      private function home_CLICK(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_back");
         SoundQueue.instance.stopMusic();
         MenuController.removeAllMenus();
         MenuController.titleMenu.show();
      }
      
      private function rpEnsureUI() : void
      {
         if(this.rp_ui != null)
         {
            return;
         }
         this.rp_entries = [];
         this.rp_cache = {};
         this.rp_icons = {};
         this.rp_rows = [];
         this.rpBuildUI();
         this.rp_ui.visible = false;
         this.rp_node = new MenuMapperNode(this.rp_ui);
         this.rp_node.updateNodes(null,null,null,null,null,null,this.rpPress,this.rpBack,this.rpUp,this.rpDown,this.rpLeft,this.rpRight);
         this.rp_mapper = new MenuMapper(this.rp_node);
         this.rp_mapper.init();
      }
      
      private function rpOpen() : void
      {
         var i:int = 0;
         var c:DisplayObject = null;
         if(this.rp_active)
         {
            return;
         }
         this.rpEnsureUI();
         this.rp_hidden = [];
         while(i < m_subMenu.numChildren)
         {
            c = m_subMenu.getChildAt(i);
            if(c != this.rp_ui && c.visible)
            {
               this.rp_hidden.push(c);
               c.visible = false;
            }
            i++;
         }
         this.rp_ui.visible = true;
         this.rp_active = true;
         this.rp_vaultMapper = m_menuMapper;
         m_menuMapper = this.rp_mapper;
         m_menuMapper.init();
         this.rpScan();
      }
      
      private function rpClose() : void
      {
         var i:int = 0;
         if(!this.rp_active)
         {
            return;
         }
         while(this.rp_hidden != null && i < this.rp_hidden.length)
         {
            this.rp_hidden[i].visible = true;
            i++;
         }
         this.rp_hidden = [];
         this.rp_ui.visible = false;
         this.rp_active = false;
         m_menuMapper = this.rp_vaultMapper;
         setMenuMappingFocus();
      }
      
      private function rpBack(e:* = null) : void
      {
         SoundQueue.instance.playSoundEffect("menu_back");
         this.rpClose();
      }
      
      private function rpBackClick(e:MouseEvent) : void
      {
         this.rpBack(null);
      }
      
      private function rpBuildUI() : void
      {
         var W:Number = Main.Width;
         var H:Number = Main.Height;
         var s:Shape = new Shape();
         var g:* = null;
         var i:int = 0;
         var mt:Matrix = new Matrix();
         var spr:Sprite = null;
         var bgS:Shape = null;
         var gg:* = null;
         var seed:Number = 0;
         var sx:Number = 0;
         var sy:Number = 0;
         this.rp_ui = new MovieClip();
         this.rp_ui.x = -W / 2;
         this.rp_ui.y = -H / 2;
         m_subMenu.addChild(this.rp_ui);
         g = s.graphics;
         g.beginFill(RP_C_DK);
         g.drawRect(0,0,W,22);
         g.endFill();
         g.beginFill(RP_C_LN);
         g.drawRect(0,22,W,2);
         g.endFill();
         g.beginFill(RP_C_DK);
         g.drawRect(0,H - 44,W,44);
         g.endFill();
         g.beginFill(RP_C_LN);
         g.drawRect(0,H - 44,W,2);
         g.endFill();
         g.beginFill(0);
         rpPoly(g,[[58,H - 42],[W - 58,H - 42],[W - 46,H],[46,H]]);
         g.endFill();
         g.beginFill(0);
         rpPoly(g,[[26,18],[W - 26,18],[W - 44,48],[26,48]]);
         g.endFill();
         mt.createGradientBox(172,25,Math.PI / 2,0,21);
         g.beginGradientFill("linear",[12449208,9426829,6272094],[1,1,1],[0,120,255],mt);
         rpPoly(g,[[100,21],[262,21],[254,46],[92,46]]);
         g.endFill();
         g.beginFill(RP_C_TAB);
         g.drawRoundRect(270,24,20,20,5,5);
         g.endFill();
         g.beginFill(RP_C_TXT);
         rpPoly(g,[[277,29],[285,34],[277,39]]);
         g.endFill();
         g.lineStyle(2,14674142);
         g.moveTo(55,40);
         g.lineTo(55,37);
         g.curveTo(55,33,51,33);
         g.lineTo(42,33);
         g.moveTo(46,29);
         g.lineTo(41,33);
         g.lineTo(46,37);
         g.lineStyle();
         g.beginFill(1778204);
         g.drawRoundRect(22,RP_LIST_Y + 2,14,176,4,4);
         g.endFill();
         bgS = new Shape();
         gg = bgS.graphics;
         mt.createGradientBox(W * 1.45,H * 1.7,0,W / 2 - W * 0.725,H * 0.9 - H * 0.85);
         gg.beginGradientFill("radial",[9083546,2898490,922648],[1,1,1],[0,90,180],mt);
         gg.drawRect(0,0,W,H);
         gg.endFill();
         seed = 12345;
         i = 0;
         while(i < 90)
         {
            seed = seed * 16807 % 2147483647;
            sx = seed % 1000 / 1000 * W;
            seed = seed * 16807 % 2147483647;
            sy = seed % 1000 / 1000 * H;
            seed = seed * 16807 % 2147483647;
            gg.beginFill(16777215,0.2 + seed % 10 / 16);
            gg.drawCircle(sx,sy,0.5 + seed % 3 * 0.35);
            gg.endFill();
            i++;
         }
         this.rp_ui.addChild(bgS);
         mt = new Matrix();
         this.rp_ui.addChild(s);
         rpText(this.rp_ui,"BACK",58,28,8,14674142);
         rpText(this.rp_ui,"REPLAYS",100,24,13,RP_C_TXT,154,"center");
         this.rp_backBtn = new Sprite();
         this.rp_backBtn.graphics.beginFill(0,0);
         this.rp_backBtn.graphics.drawRect(30,22,64,26);
         this.rp_backBtn.graphics.endFill();
         this.rp_backBtn.buttonMode = true;
         this.rp_backBtn.addEventListener(MouseEvent.CLICK,this.rpBackClick);
         this.rp_backBtn.addEventListener(MouseEvent.ROLL_OVER,this.rpHover);
         this.rp_ui.addChild(this.rp_backBtn);
         this.rp_thumb = new Shape();
         this.rp_ui.addChild(this.rp_thumb);
         i = 0;
         while(i < RP_ROWS)
         {
            this.rp_rows.push(this.rpMakeRow(i));
            i++;
         }
         this.rp_page = rpText(this.rp_ui,"",W - 150,H - 30,9,13300422,92,"right");
         this.rp_path = rpText(this.rp_ui,"",72,H - 33,7,12380341,300);
         var fb:Sprite = new Sprite();
         fb.graphics.beginFill(RP_C_TAB);
         rpPoly(fb.graphics,[[6,0],[96,0],[90,20],[0,20]]);
         fb.graphics.endFill();
         fb.x = 378;
         fb.y = H - 34;
         rpText(fb,"ABRIR CARPETA",0,4,8,RP_C_TXT,96,"center");
         fb.buttonMode = true;
         fb.addEventListener(MouseEvent.CLICK,this.rpOpenFolder);
         fb.addEventListener(MouseEvent.ROLL_OVER,this.rpHover);
         this.rp_ui.addChild(fb);
         spr = new Sprite();
         mt = new Matrix();
         mt.createGradientBox(366,196,0,0,0);
         spr.graphics.beginGradientFill("linear",[2830893,790285,0],[0,0.92,1],[0,90,255],mt);
         spr.graphics.drawRect(0,0,366,196);
         spr.graphics.endFill();
         spr.x = 262;
         spr.y = 54;
         this.rp_ui.addChild(spr);
         this.rp_detail = new Sprite();
         this.rp_detail.x = 262;
         this.rp_detail.y = 54;
         this.rp_ui.addChild(this.rp_detail);
         this.rp_empty = rpText(this.rp_ui,"No hay replays todavia.\nGuarda uno al terminar una partida.",262,130,9,12175802,366,"center");
         this.rp_empty.multiline = true;
         this.rp_empty.height = 40;
         this.rp_empty.visible = false;
         this.rp_info = new Sprite();
         this.rp_info.x = 14;
         this.rp_info.y = 258;
         this.rp_ui.addChild(this.rp_info);
         this.rp_ui.addEventListener(MouseEvent.MOUSE_WHEEL,this.rpWheel);
      }
      
      private function rpMakeRow(i:int) : Object
      {
         var mc:Sprite = new Sprite();
         var bg:Shape = new Shape();
         var nm:TextField = null;
         var sb:TextField = null;
         var minis:Sprite = new Sprite();
         var warn:TextField = null;
         mc.x = RP_LIST_X;
         mc.y = RP_LIST_Y + i * RP_ROW_H;
         mc.buttonMode = true;
         mc.addChild(bg);
         nm = rpText(mc,"",10,3,8,15003620,192);
         sb = rpText(mc,"",10,18,7,9676181,112);
         minis.x = 128;
         minis.y = 15;
         mc.addChild(minis);
         warn = rpText(mc,"",110,18,7,15038829,92,"right");
         mc.addEventListener(MouseEvent.CLICK,this.rpRowClick);
         mc.addEventListener(MouseEvent.ROLL_OVER,this.rpHover);
         rp_ui.addChild(mc);
         return {
            "mc":mc,
            "bg":bg,
            "nm":nm,
            "sb":sb,
            "minis":minis,
            "warn":warn,
            "idx":-1
         };
      }
      
      private function rpHover(e:MouseEvent) : void
      {
         SoundQueue.instance.playSoundEffect("menu_hover");
      }
      
      private function rpPress(e:* = null) : void
      {
         this.rpWatch();
      }
      
      private function rpUp(e:* = null) : void
      {
         this.rpSelect(this.rp_sel - 1);
      }
      
      private function rpDown(e:* = null) : void
      {
         this.rpSelect(this.rp_sel + 1);
      }
      
      private function rpLeft(e:* = null) : void
      {
         this.rpSelect(this.rp_sel - RP_ROWS);
      }
      
      private function rpRight(e:* = null) : void
      {
         this.rpSelect(this.rp_sel + RP_ROWS);
      }
      
      private function rpOpenFolder(e:MouseEvent) : void
      {
         var dir:* = replaysFolder();
         try
         {
            dir.openWithDefaultApplication();
         }
         catch(err:Error)
         {
            MultiplayerManager.makeNotifier();
            MultiplayerManager.notify("No se pudo abrir la carpeta: " + String(dir.nativePath));
         }
      }
      
      private function rpWheel(e:MouseEvent) : void
      {
         this.rpSelect(this.rp_sel + (e.delta > 0 ? -1 : 1));
      }
      
      private function rpRowClick(e:MouseEvent) : void
      {
         var i:int = 0;
         while(i < this.rp_rows.length)
         {
            if(this.rp_rows[i].mc == e.currentTarget && int(this.rp_rows[i].idx) >= 0)
            {
               SoundQueue.instance.playSoundEffect("menu_hover");
               this.rpSelect(int(this.rp_rows[i].idx));
               return;
            }
            i++;
         }
      }
      
      private function rpSelect(n:int) : void
      {
         var old:int = this.rp_sel;
         if(this.rp_entries.length == 0)
         {
            return;
         }
         this.rp_sel = Math.max(0,Math.min(this.rp_entries.length - 1,n));
         if(this.rp_sel < this.rp_top)
         {
            this.rp_top = this.rp_sel;
         }
         if(this.rp_sel >= this.rp_top + RP_ROWS)
         {
            this.rp_top = this.rp_sel - RP_ROWS + 1;
         }
         if(old != this.rp_sel)
         {
            SoundQueue.instance.playSoundEffect("menu_hover");
         }
         this.rpRefreshAll();
      }
      
      private function rpScan() : void
      {
         var dir:* = replaysFolder();
         var list:Array = null;
         var i:int = 0;
         var f:* = null;
         var keepPath:String = null;
         var found:int = -1;
         rpFit(this.rp_path,"Carpeta: " + String(dir.nativePath),300);
         if(this.rp_sel >= 0 && this.rp_sel < this.rp_entries.length)
         {
            keepPath = String(this.rp_entries[this.rp_sel].path);
         }
         this.rp_entries = [];
         try
         {
            list = dir.getDirectoryListing();
         }
         catch(err:Error)
         {
            list = [];
         }
         list.sort(function(a:*, b:*):int
         {
            var ta:Number = 0;
            var tb:Number = 0;
            try
            {
               ta = Number(a.modificationDate.time);
               tb = Number(b.modificationDate.time);
            }
            catch(e:Error)
            {
            }
            return ta < tb ? 1 : (ta > tb ? -1 : 0);
         });
         while(i < list.length)
         {
            f = list[i];
            if(!f.isDirectory && String(f.extension).toLowerCase() == "ssfrec")
            {
               this.rp_entries.push({
                  "file":f,
                  "path":String(f.nativePath),
                  "label":String(f.name).replace(/\.ssfrec$/i,""),
                  "meta":this.rp_cache[String(f.nativePath)],
                  "state":(this.rp_cache[String(f.nativePath)] != null ? 1 : 0)
               });
               if(String(f.nativePath) == keepPath)
               {
                  found = this.rp_entries.length - 1;
               }
            }
            i++;
         }
         this.rp_sel = found >= 0 ? found : 0;
         this.rp_top = Math.max(0,Math.min(this.rp_sel,this.rp_entries.length - RP_ROWS));
         this.rpRefreshAll();
      }
      
      private function rpParse(entry:Object) : void
      {
         var rd:ReplayData = rpLoad(entry.file);
         var meta:Object = null;
         var pl:Array = [];
         var i:int = 0;
         var p:* = null;
         if(rd == null)
         {
            entry.state = 2;
            return;
         }
         while(i < rd.PlayerData.length)
         {
            p = rd.PlayerData[i];
            if(p != null && p.exist !== false && p.character != null && p.character != "")
            {
               pl.push({
                  "idx":i,
                  "ch":String(p.character),
                  "nick":(p.name != null ? String(p.name) : ""),
                  "human":p.human !== false,
                  "level":p.level
               });
            }
            i++;
         }
         meta = {
            "mode":rd.GameMode,
            "frames":rd.FrameCount,
            "date":rd.Timestamp,
            "version":rd.VersionNumber,
            "ok":rpCompat(rd),
            "playable":Boolean(ModeFeatures.hasFeature(ModeFeatures.ALLOW_REPLAY_RECORD,rd.GameMode)) && rd.GameMode !== Mode.CLASSIC,
            "settings":rd.MatchSettings,
            "players":pl,
            "winners":rd.Winners,
            "title":rd.Name
         };
         entry.meta = meta;
         entry.state = 1;
         this.rp_cache[entry.path] = meta;
      }
      
      private function rpTick(e:Event) : void
      {
         var i:int = 0;
         var vis:Boolean = false;
         if(!this.rp_active)
         {
            return;
         }
         while(i < this.rp_entries.length)
         {
            if(int(this.rp_entries[i].state) == 0)
            {
               this.rpParse(this.rp_entries[i]);
               vis = i >= this.rp_top && i < this.rp_top + RP_ROWS || i == this.rp_sel;
               if(vis)
               {
                  this.rpRefreshAll();
               }
               return;
            }
            i++;
         }
      }
      
      private function rpTile(ch:String, size:int, col:int) : Sprite
      {
         var t:Sprite = new Sprite();
         var bd:BitmapData = null;
         var bm:Bitmap = null;
         var key:String = ch + "_" + size;
         var ini:TextField = null;
         if(this.rp_icons[key] === undefined)
         {
            try
            {
               this.rp_icons[key] = MultiplayerManager.replayIcon(ch,size * 2,size * 2);
            }
            catch(err:Error)
            {
               this.rp_icons[key] = null;
            }
         }
         bd = this.rp_icons[key];
         if(bd != null)
         {
            bm = new Bitmap(bd,"auto",true);
            bm.width = size;
            bm.height = size;
            t.addChild(bm);
         }
         else
         {
            t.graphics.beginFill(col);
            t.graphics.drawRect(0,0,size,size);
            t.graphics.endFill();
            ini = rpText(t,ch.substr(0,2).toUpperCase(),0,size / 2 - 7,int(Math.max(7,size / 3)),16777215,size,"center");
         }
         t.graphics.lineStyle(1,16777215,0.8);
         t.graphics.drawRect(0,0,size,size);
         return t;
      }
      
      private function rpRefreshAll() : void
      {
         this.rpRefreshRows();
         this.rpRefreshDetail();
      }
      
      private function rpRefreshRows() : void
      {
         var i:int = 0;
         var r:Object = null;
         var idx:int = 0;
         var en:Object = null;
         var meta:Object = null;
         var sel:Boolean = false;
         var g:* = null;
         var mt:Matrix = null;
         var k:int = 0;
         var pl:Array = null;
         var extra:TextField = null;
         while(i < RP_ROWS)
         {
            r = this.rp_rows[i];
            idx = this.rp_top + i;
            r.idx = idx < this.rp_entries.length ? idx : -1;
            r.mc.visible = int(r.idx) >= 0;
            while(r.minis.numChildren > 0)
            {
               r.minis.removeChildAt(0);
            }
            if(int(r.idx) >= 0)
            {
               en = this.rp_entries[idx];
               meta = en.meta;
               sel = idx == this.rp_sel;
               g = r.bg.graphics;
               g.clear();
               mt = new Matrix();
               mt.createGradientBox(206,32,0,0,0);
               g.beginGradientFill("linear",sel ? [797199,0,0] : [0,0,0],[1,1,0],[0,150,255],mt);
               g.drawRect(0,0,206,32);
               g.endFill();
               if(sel)
               {
                  g.beginFill(RP_C_BR);
                  g.drawRect(0,0,3,32);
                  g.endFill();
                  g.beginFill(RP_C_LT,0.8);
                  g.drawRect(3,0,150,1);
                  g.endFill();
               }
               r.mc.x = RP_LIST_X + (sel ? 6 : 0);
               r.mc.alpha = meta != null && !meta.ok || int(en.state) == 2 ? 0.55 : 1;
               rpFit(r.nm,en.label,190);
               r.nm.textColor = sel ? 16777215 : 13622479;
               r.warn.text = "";
               if(int(en.state) == 2)
               {
                  r.sb.text = "No se pudo leer";
                  r.warn.text = "ILEGIBLE";
               }
               else if(meta == null)
               {
                  r.sb.text = "Leyendo...";
               }
               else
               {
                  r.sb.text = rpDate(meta.date).substr(5) + "  -  " + rpMode(int(meta.mode));
                  if(!meta.ok)
                  {
                     r.warn.text = "OTRA VERSION";
                  }
                  else
                  {
                     pl = meta.players;
                     k = 0;
                     while(k < pl.length && k < 3)
                     {
                        this.rpAddMini(r.minis,pl[k],k);
                        k++;
                     }
                     if(pl.length > 3)
                     {
                        extra = rpText(r.minis,"+" + (pl.length - 3),3 * 18,1,8,16777215);
                     }
                  }
               }
            }
            i++;
         }
         this.rpScroll();
         this.rp_page.text = this.rp_entries.length > 0 ? this.rp_sel + 1 + " / " + this.rp_entries.length : "";
         this.rp_empty.visible = this.rp_entries.length == 0;
      }
      
      private function rpAddMini(parent:Sprite, p:Object, k:int) : void
      {
         var t:Sprite = this.rpTile(String(p.ch),16,int(RP_PCOL[int(p.idx) % RP_PCOL.length]));
         t.x = k * 18;
         parent.addChild(t);
      }
      
      private function rpScroll() : void
      {
         var n:int = int(this.rp_entries.length);
         var trackH:Number = 172;
         var th:Number = 0;
         var g:* = this.rp_thumb.graphics;
         g.clear();
         if(n <= 0)
         {
            return;
         }
         th = Math.max(26,trackH * Math.min(1,RP_ROWS / n));
         g.beginFill(13300422);
         g.drawRoundRect(23,RP_LIST_Y + 4 + (trackH - th) * (n > 1 ? this.rp_sel / (n - 1) : 0),12,th,4,4);
         g.endFill();
      }
      
      private function rpStageName(id:String) : String
      {
         var info:* = null;
         try
         {
            info = ResourceManager.getResourceByID("mappings").getProp("metadata").stage[id];
            if(info != null && info.name != null)
            {
               return String(info.name);
            }
         }
         catch(err:Error)
         {
         }
         return id == null ? "" : id;
      }
      
      private function rpStagePreview(id:String, w:Number, h:Number) : DisplayObject
      {
         var pv:MovieClip = null;
         var ic:MovieClip = null;
         var bmp:Bitmap = null;
         var holder:Sprite = new Sprite();
         var b:Rectangle = null;
         var sc:Number = 0;
         var used:MovieClip = null;
         var prev:MovieClip = null;
         var inner:MovieClip = null;
         var bd:BitmapData = null;
         var bm:Bitmap = null;
         var tmpBmp:Bitmap = null;
         var fin:BitmapData = null;
         var fw:int = 0;
         var fh:int = 0;
         var ss:Number = 0;
         this.rp_pvErr = "";
         try
         {
            if(FMCManager.getStage(id) != null)
            {
               bmp = FMCManager.getStageBitmapHD(id);
               if(bmp != null)
               {
                  fw = int(w * 3);
                  fh = int(h * 3);
                  ss = Math.max(fw / bmp.bitmapData.width,fh / bmp.bitmapData.height);
                  fin = new BitmapData(fw,fh,true,0);
                  fin.draw(bmp.bitmapData,new Matrix(ss,0,0,ss,(fw - bmp.bitmapData.width * ss) / 2,(fh - bmp.bitmapData.height * ss) / 2),null,null,null,true);
                  bmp.bitmapData.dispose();
                  bm = new Bitmap(fin,"auto",true);
                  bm.scaleX = 1 / 3;
                  bm.scaleY = 1 / 3;
                  holder.addChild(bm);
                  return holder;
               }
            }
            prev = MovieClip(MenuController.stageSelectMenu.SubMenu.stage_sample.previewer);
            inner = MovieClip(prev.getChildByName("mc"));
            if(FMCManager.getStage(id) != null)
            {
               Utils.tryToGotoAndStop(inner,"external");
               bmp = FMCManager.getStageBitmap(id);
               if(bmp != null && inner.mc != null)
               {
                  tmpBmp = new Bitmap(bmp.bitmapData);
                  tmpBmp.x = -tmpBmp.width / 2;
                  tmpBmp.y = -tmpBmp.height / 2;
                  inner.mc.addChild(tmpBmp);
               }
            }
            else
            {
               Utils.tryToGotoAndStop(inner,id);
            }
            b = prev.getBounds(prev);
            if(b.width >= 2 && b.height >= 2)
            {
               bd = new BitmapData(int(b.width * 2),int(b.height * 2),true,0);
               bd.draw(prev,new Matrix(2,0,0,2,-b.x * 2,-b.y * 2),null,null,null,true);
               fw = int(w * 3);
               fh = int(h * 3);
               ss = Math.max(fw / bd.width,fh / bd.height);
               fin = new BitmapData(fw,fh,true,0);
               fin.draw(bd,new Matrix(ss,0,0,ss,(fw - bd.width * ss) / 2,(fh - bd.height * ss) / 2),null,null,null,false);
               bd.dispose();
               bm = new Bitmap(fin,"auto",true);
               bm.scaleX = 1 / 3;
               bm.scaleY = 1 / 3;
               holder.addChild(bm);
            }
            if(tmpBmp != null && tmpBmp.parent != null)
            {
               tmpBmp.parent.removeChild(tmpBmp);
            }
            if(bm != null)
            {
               return holder;
            }
            this.rp_pvErr = "A vacio";
         }
         catch(errA:Error)
         {
            this.rp_pvErr = "A " + String(errA.message).substr(0,26);
         }
         try
         {
            pv = ResourceManager.getLibraryMC("stagePreviewerFMC");
            if(pv == null)
            {
               this.rp_pvErr += " PV sin clip";
            }
            else
            {
               if(FMCManager.getStage(id) != null)
               {
                  Utils.tryToGotoAndStop(pv,"external");
                  bmp = FMCManager.getStageBitmap(id);
                  if(bmp != null && pv.mc != null)
                  {
                     bmp.x -= bmp.width / 2;
                     bmp.y -= bmp.height / 2;
                     pv.mc.addChild(bmp);
                  }
               }
               else
               {
                  Utils.tryToGotoAndStop(pv,id);
               }
               holder.addChild(pv);
               b = holder.getBounds(holder);
               if(b.width < 2 || b.height < 2)
               {
                  this.rp_pvErr += " PV vacio (" + pv.currentLabel + ")";
                  holder.removeChild(pv);
               }
               else
               {
                  used = pv;
               }
            }
         }
         catch(err:Error)
         {
            this.rp_pvErr += " PV error: " + String(err.message).substr(0,40);
            used = null;
         }
         if(used == null)
         {
            try
            {
               ic = ResourceManager.getLibraryMC(id + "_stage_select");
               if(ic != null)
               {
                  holder.addChild(ic);
                  b = holder.getBounds(holder);
                  if(b.width >= 2 && b.height >= 2)
                  {
                     used = ic;
                     this.rp_pvErr += " > icono";
                  }
               }
            }
            catch(err2:Error)
            {
            }
         }
         if(used == null)
         {
            return null;
         }
         sc = Math.max(w / b.width,h / b.height);
         used.scaleX = sc;
         used.scaleY = sc;
         used.x = (w - b.width * sc) / 2 - b.x * sc;
         used.y = (h - b.height * sc) / 2 - b.y * sc;
         return holder;
      }
      
      private function rpRefreshDetail() : void
      {
         var en:Object = this.rp_entries.length > 0 ? this.rp_entries[this.rp_sel] : null;
         var meta:Object = en != null ? en.meta : null;
         var d:Sprite = this.rp_detail;
         var inf:Sprite = this.rp_info;
         var ban:Sprite = null;
         var bm2:Bitmap = null;
         var pv:DisplayObject = null;
         var stId:String = null;
         var pl:Array = null;
         var n:int = 0;
         var cols:int = 4;
         var cw:int = 86;
         var tsz:int = 24;
         var mg:Number = 0;
         var k:int = 0;
         var card:Sprite = null;
         var p:Object = null;
         var win:Boolean = false;
         var nick:String = null;
         var tx:Number = 0;
         var tagY:Number = 0;
         var rules:String = null;
         var st:Object = null;
         var tags:Array = null;
         var wn:Array = null;
         var plate:Sprite = null;
         var mt:Matrix = null;
         var lab:Sprite = null;
         var names:Array = null;
         var vals:Array = null;
         var i:int = 0;
         var sn:TextField = null;
         var tile:Sprite = null;
         var cn:TextField = null;
         var tg:Sprite = null;
         var tt:TextField = null;
         var lb:Sprite = null;
         var gm:Matrix = null;
         var vt:TextField = null;
         var gc:* = null;
         while(d.numChildren > 0)
         {
            d.removeChildAt(0);
         }
         while(inf.numChildren > 0)
         {
            inf.removeChildAt(0);
         }
         this.rp_info.graphics.clear();
         if(en == null)
         {
            return;
         }
         inf.graphics.beginFill(0);
         inf.graphics.lineStyle(1.5,16777215);
         inf.graphics.drawRoundRect(0,0,612,54,3,3);
         inf.graphics.endFill();
         if(meta == null)
         {
            rpText(d,int(en.state) == 2 ? "No se pudo leer este archivo." : "Leyendo replay...",0,90,10,12175802,366,"center");
            rpText(inf,en.label,104,6,9,16777215,320);
            return;
         }
         st = meta.settings;
         stId = st != null && st.stage != null ? String(st.stage) : "";
         ban = new Sprite();
         mt = new Matrix();
         mt.createGradientBox(366,70,Math.PI / 2,0,0);
         ban.graphics.beginGradientFill("linear",[1850914,3042106],[0.55,0.3],[0,255],mt);
         ban.graphics.drawRect(0,0,366,70);
         ban.graphics.endFill();
         pv = this.rpStagePreview(stId,366,70);
         if(pv != null)
         {
            ban.addChild(pv);
         }
         gc = new Sprite();
         mt = new Matrix();
         mt.createGradientBox(366,40,Math.PI / 2,0,30);
         gc.graphics.beginGradientFill("linear",[0,0],[0,0.8],[0,255],mt);
         gc.graphics.drawRect(0,30,366,40);
         gc.graphics.endFill();
         ban.addChild(gc);
         d.addChild(ban);
         bm2 = new Bitmap(rpFadeMask(366,70));
         bm2.cacheAsBitmap = true;
         ban.cacheAsBitmap = true;
         d.addChild(bm2);
         ban.mask = bm2;
         lab = new Sprite();
         lab.graphics.beginFill(RP_C_TAB);
         rpPoly(lab.graphics,[[0,0],[62,0],[58,12],[0,12]]);
         lab.graphics.endFill();
         lab.x = 8;
         lab.y = 6;
         d.addChild(lab);
         rpText(lab,"ESCENARIO",6,-1,7,RP_C_TXT);
         nick = this.rpStageName(stId).toUpperCase();
         sn = rpText(d,nick,10,34,20,16777215);
         if(sn.textWidth > 340)
         {
            sn.scaleX = 340 / sn.textWidth;
         }
         sn.filters = [new DropShadowFilter(2,45,0,1,0,0,1,1)];
         if(RP_DEBUG && this.rp_pvErr != "")
         {
            rpText(d,this.rp_pvErr,120,8,7,16765136,240,"right");
         }
         pl = meta.players;
         n = Math.min(pl.length,8);
         wn = meta.winners != null ? meta.winners : [];
         k = 0;
         while(k < n)
         {
            p = pl[k];
            win = wn.indexOf(int(p.idx)) >= 0;
            card = new Sprite();
            card.x = 8 + k % cols * 89;
            card.y = 76 + int(k / cols) * 38;
            card.graphics.beginFill(592906);
            card.graphics.drawRect(0,0,cw,34);
            card.graphics.endFill();
            card.graphics.beginFill(win ? RP_C_BR : int(RP_PCOL[int(p.idx) % RP_PCOL.length]));
            card.graphics.drawRect(0,0,cw,win ? 2.5 : 1.5);
            card.graphics.endFill();
            tile = this.rpTile(String(p.ch),tsz,int(RP_PCOL[int(p.idx) % RP_PCOL.length]));
            tile.x = 6;
            tile.y = (34 - tsz) / 2 + 1;
            card.addChild(tile);
            nick = !!p.human ? (String(p.nick) != "" ? String(p.nick) : "P" + (int(p.idx) + 1)) : "CPU Lv." + p.level;
            rpFit(rpText(card,"",tsz + 10,4,8,16777215,50),nick,50);
            cn = rpText(card,"",tsz + 10,15,6,10466208,50);
            rpFit(cn,MultiplayerManager.replayCharName(String(p.ch)),50);
            if(win)
            {
               rpText(card,"GANADOR",tsz + 10,24,5,RP_C_BR,50);
            }
            d.addChild(card);
            k++;
         }
         tagY = 76 + (int((n - 1) / cols) + 1) * 38 + 2;
         rules = "Libre";
         if(st != null)
         {
            if(st.usingLives)
            {
               rules = "Stock " + st.lives;
            }
            else if(st.usingTime)
            {
               rules = "Tiempo " + st.time + " min";
            }
         }
         tags = [this.rpStageName(stId),rules,rpLen(int(meta.frames)),rpMode(int(meta.mode))];
         tx = 8;
         i = 0;
         while(i < tags.length)
         {
            tg = new Sprite();
            tt = rpText(tg,String(tags[i]),11,1,7,15332329);
            tg.graphics.beginFill(0);
            tg.graphics.lineStyle(1,6257250);
            rpPoly(tg.graphics,[[4,0],[tt.textWidth + 24,0],[tt.textWidth + 20,14],[0,14]]);
            tg.graphics.endFill();
            tg.x = tx;
            tg.y = tagY;
            d.addChild(tg);
            tg.addChild(tt);
            tx += tt.textWidth + 30;
            i++;
         }
         names = ["NOMBRE:","FECHA:","DURACION:"];
         vals = [en.label,rpDate(meta.date),rpLen(int(meta.frames)) + "  -  " + pl.length + " jugadores"];
         i = 0;
         while(i < 3)
         {
            lb = new Sprite();
            gm = new Matrix();
            gm.createGradientBox(92,13.5,0,0,0);
            lb.graphics.beginGradientFill("linear",[RP_C_TABD,RP_C_TAB,RP_C_LT],[1,1,1],[0,110,255],gm);
            rpPoly(lb.graphics,[[0,0],[92,0],[87,13.5],[0,13.5]]);
            lb.graphics.endFill();
            lb.x = -1.5;
            lb.y = 5 + i * 15;
            rpText(lb,String(names[i]),0,0,7,RP_C_TXT,82,"right");
            inf.addChild(lb);
            vt = rpText(inf,"",100,5 + i * 15,8,16777215,270);
            rpFit(vt,String(vals[i]),268);
            i++;
         }
         plate = new Sprite();
         mt = new Matrix();
         mt.createGradientBox(232,46,0,0,0);
         plate.graphics.beginGradientFill("linear",meta.ok && meta.playable ? [9342606,13224393,15724527] : [4868682,6710886,8421504],[1,1,1],[0,150,255],mt);
         rpPoly(plate.graphics,[[18,0],[232,0],[232,46],[0,46]]);
         plate.graphics.endFill();
         plate.graphics.beginFill(1381659);
         plate.graphics.drawCircle(68,23,11);
         plate.graphics.endFill();
         plate.graphics.beginFill(RP_C_BR);
         rpPoly(plate.graphics,[[64,17],[73,23],[64,29]]);
         plate.graphics.endFill();
         plate.x = 612 - 232 + 1;
         plate.y = 3;
         rpText(plate,meta.ok && meta.playable ? "VER REPLAY" : (!!meta.ok ? "NO SE PUEDE VER" : "OTRA VERSION"),88,14,13,1381659,140);
         plate.buttonMode = true;
         plate.addEventListener(MouseEvent.CLICK,this.rpPlateClick);
         plate.addEventListener(MouseEvent.ROLL_OVER,this.rpHover);
         inf.addChild(plate);
      }
      
      private function rpPlateClick(e:MouseEvent) : void
      {
         this.rpWatch();
      }
      
      private function rpWatch() : void
      {
         var en:Object = this.rp_entries.length > 0 ? this.rp_entries[this.rp_sel] : null;
         var rd:ReplayData = null;
         if(en == null)
         {
            return;
         }
         MultiplayerManager.makeNotifier();
         if(en.meta == null || int(en.state) != 1)
         {
            MultiplayerManager.notify("Replay file could not be loaded.");
            return;
         }
         if(!en.meta.ok)
         {
            MultiplayerManager.notify("Error, incompatible version number. Received version\t" + en.meta.version + " (Expecting " + Version.getVersion() + ")");
            return;
         }
         if(!en.meta.playable)
         {
            MultiplayerManager.notify("Replay file was not playable.");
            return;
         }
         rd = rpLoad(en.file);
         if(rd == null)
         {
            MultiplayerManager.notify("Replay file could not be loaded.");
            return;
         }
         SoundQueue.instance.playSoundEffect("menu_select");
         startReplay(rd);
      }
   }
}

