package com.mcleodgaming.ssf2.items
{
   import com.mcleodgaming.ssf2.engine.*;
   import com.mcleodgaming.ssf2.util.*;
   
   public class ItemsListData
   {
      public static var OBJECTS:Object;
      
      public static var DATA:Array = null;
      
      public function ItemsListData()
      {
         super();
      }
      
      public static function init() : void
      {
         var i:int = 0;
         DATA = ResourceManager.getItemStats();
         OBJECTS = {};
         while(i < DATA.length)
         {
            OBJECTS[DATA[i].statsName] = DATA[i];
            i++;
         }
      }
      
      public static function getItemByID(id:String) : Object
      {
         return !!OBJECTS[id] ? OBJECTS[id] : null;
      }
      
      public static function getItemStatsList(includeHidden:Boolean = true, includeDisabled:Boolean = true) : Array
      {
         var i:int = 0;
         var list:Array = [];
         var statsCopy:Array = ResourceManager.getItemStats();
         while(i < statsCopy.length)
         {
            if((includeDisabled || SaveData.ItemDataObj[statsCopy[i].statsName] === undefined) && (includeHidden || SaveData.Unlocks[statsCopy[i].statsName] !== false))
            {
               list.push(statsCopy[i]);
            }
            i++;
         }
         return list;
      }
      
      public static function getRandomItemStats(includeHidden:Boolean = true, includeDisabled:Boolean = true) : Object
      {
         var list:Array = ItemsListData.getItemStatsList(includeHidden,includeDisabled);
         return list.length === 0 ? null : list[Utils.randomInteger(0,list.length)];
      }
   }
}

