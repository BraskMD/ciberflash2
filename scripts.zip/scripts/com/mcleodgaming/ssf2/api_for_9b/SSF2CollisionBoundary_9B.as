package com.mcleodgaming.ssf2.api_for_9b
{
   import flash.display.MovieClip;
   import flash.geom.Rectangle;
   
   public class SSF2CollisionBoundary_9B extends SSF2BaseAPIObject_9B
   {
      public function SSF2CollisionBoundary_9B(_arg_1:*)
      {
         super(_arg_1);
      }
      
      override public function getType() : String
      {
         return "SSF2CollisionBoundary";
      }
      
      public function getOwnStats() : Object
      {
         return {};
      }
      
      public function getMC() : MovieClip
      {
         return _api.getMC();
      }
      
      public function destroy() : void
      {
         _api.destroy();
      }
      
      public function getX() : Number
      {
         return _api.getX();
      }
      
      public function setX(_arg_1:Number) : void
      {
         _api.setX(_arg_1);
      }
      
      public function getY() : Number
      {
         return _api.getY();
      }
      
      public function setY(_arg_1:Number) : void
      {
         _api.setY(_arg_1);
      }
      
      public function hitTestPoint(_arg_1:Number, _arg_2:Number, _arg_3:Boolean = true) : Boolean
      {
         return _api.hitTestPoint(_arg_1,_arg_2,_arg_3);
      }
      
      public function hitTestRect(_arg_1:Rectangle, _arg_2:Boolean = true) : Boolean
      {
         return _api.hitTestRect(_arg_1,_arg_2);
      }
   }
}

