package com.mcleodgaming.ssf2.api_for_9b
{
   public class SSF2CustomMatch_9B extends SSF2BaseAPIObject_9B
   {
      public var matchData:Object;
      
      public function SSF2CustomMatch_9B(_arg_1:*)
      {
         super(_arg_1);
         this.matchData = {};
      }
      
      override public function getType() : String
      {
         return "SSF2CustomMatch";
      }
      
      public function getGameSettings() : Object
      {
         return _api.getGameSettings();
      }
      
      public function matchSetup(_arg_1:Object) : Object
      {
         return _arg_1;
      }
   }
}

