package com.mcleodgaming.ssf2.api_for_9b
{
   public class SSF2Beacon_9B extends SSF2GameObject_9B
   {
      public function SSF2Beacon_9B(_arg_1:*)
      {
         super(_arg_1);
      }
      
      override public function getType() : String
      {
         return "SSF2Beacon";
      }
   }
}

