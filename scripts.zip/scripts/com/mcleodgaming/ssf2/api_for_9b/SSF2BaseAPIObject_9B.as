package com.mcleodgaming.ssf2.api_for_9b
{
   public dynamic class SSF2BaseAPIObject_9B
   {
      public var $ext:Object;
      
      protected var _api:*;
      
      public function SSF2BaseAPIObject_9B(_arg_1:*)
      {
         var api:* = _arg_1;
         super();
         this._api = api;
         this.$ext = {"getAPI":function():*
         {
            return _api;
         }};
      }
      
      public function getType() : String
      {
         return "SSF2BaseAPIObject";
      }
      
      public function get metadata() : Object
      {
         return this.isDisposed() ? null : this._api.metadata;
      }
      
      public function initialize() : void
      {
      }
      
      public function update() : void
      {
      }
      
      public function isDisposed() : Boolean
      {
         return !!this._api ? false : true;
      }
      
      public function dispose() : void
      {
      }
      
      public function __dispose() : void
      {
         this._api = null;
         this.$ext = null;
      }
      
      public function isEqual(_arg_1:*) : Boolean
      {
         return !!_arg_1 ? _arg_1 && this._api === _arg_1.$ext.getAPI() : false;
      }
   }
}

