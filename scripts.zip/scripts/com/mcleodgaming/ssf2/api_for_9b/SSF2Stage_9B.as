package com.mcleodgaming.ssf2.api_for_9b
{
   import flash.display.DisplayObject;
   import flash.display.MovieClip;
   import flash.geom.Point;
   
   public class SSF2Stage_9B extends SSF2BaseAPIObject_9B
   {
      public function SSF2Stage_9B(_arg_1:*)
      {
         super(_arg_1);
      }
      
      override public function getType() : String
      {
         return "SSF2Stage";
      }
      
      public function getForeground() : MovieClip
      {
         return _api.getForeground();
      }
      
      public function getMidground() : MovieClip
      {
         return _api.getMidground();
      }
      
      public function getBackground() : MovieClip
      {
         return _api.getBackground();
      }
      
      public function getCameraBackgrounds() : Array
      {
         return _api.getCameraBackgrounds();
      }
      
      public function getWeatherMC() : MovieClip
      {
         return _api.getWeatherMC();
      }
      
      public function getWeatherMaskMC() : MovieClip
      {
         return _api.getWeatherMaskMC();
      }
      
      public function getShadowMC() : MovieClip
      {
         return _api.getShadowMC();
      }
      
      public function getShadowMaskMC() : MovieClip
      {
         return _api.getShadowMaskMC();
      }
      
      public function getHUDBackgroundMC() : MovieClip
      {
         return _api.getHUDBackgroundMC();
      }
      
      public function getHUDForegroundMC() : MovieClip
      {
         return _api.getHUDForegroundMC();
      }
      
      public function enableCeilingDeath(_arg_1:Boolean = true) : void
      {
         _api.enableCeilingDeath(_arg_1);
      }
      
      public function enableFallDeath(_arg_1:Boolean = true) : void
      {
         _api.enableFallDeath(_arg_1);
      }
      
      public function isCeilingDeathEnabled() : Boolean
      {
         return _api.isCeilingDeathEnabled();
      }
      
      public function isFallDeathEnabled() : Boolean
      {
         return _api.isFallDeathEnabled();
      }
      
      public function createTimer(_arg_1:int, _arg_2:int, _arg_3:Function, _arg_4:Object = null) : void
      {
         _api.createTimer(_arg_1,_arg_2,_arg_3,_arg_4);
      }
      
      public function destroyTimer(_arg_1:Function) : void
      {
         _api.destroyTimer(_arg_1);
      }
      
      public function toLocalPoint(_arg_1:DisplayObject) : Point
      {
         return _api.toLocalPoint(_arg_1);
      }
      
      public function getStartingPositionMCs() : Array
      {
         return _api.getStartingPositionMCs();
      }
      
      public function getSpawnPositionMCs() : Array
      {
         return _api.getSpawnPositionMCs();
      }
      
      public function getLightSourceMC() : MovieClip
      {
         return _api.getLightSourceMC();
      }
      
      public function getLedges() : Array
      {
         return _api.getLedges();
      }
      
      public function getCameraBounds() : MovieClip
      {
         return _api.getCameraBounds();
      }
      
      public function getDeathBounds() : MovieClip
      {
         return _api.getDeathBounds();
      }
      
      public function getSmashBallBounds() : MovieClip
      {
         return _api.getSmashBallBounds();
      }
      
      public function getItemSpawnBoundsList() : Array
      {
         return _api.getItemSpawnBoundsList();
      }
      
      override public function initialize() : void
      {
         var _local_2:Array = null;
         var _local_4:Array = null;
         var _local_5:Array = null;
         var _local_6:Array = null;
         var _local_1:Array = [this.getBackground(),this.getForeground()];
         var _local_3:Array = this.getCameraBackgrounds() != null ? [this.getCameraBackgrounds()[0].mc] : null;
         SSF2StageQuality_9B.init(_local_1,_local_2,_local_3,_local_4,_local_5,_local_6);
         trace("lets go");
      }
   }
}

