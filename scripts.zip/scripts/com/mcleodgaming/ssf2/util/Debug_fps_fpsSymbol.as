package com.mcleodgaming.ssf2.util
{
   import flash.display.DisplayObject;
   import mx.core.SpriteAsset;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol10")]
   public class Debug_fps_fpsSymbol extends SpriteAsset
   {
      public var bar:DisplayObject;
      
      public var fps:DisplayObject;
      
      public var lowestValue:DisplayObject;
      
      public function Debug_fps_fpsSymbol()
      {
         super();
      }
   }
}

