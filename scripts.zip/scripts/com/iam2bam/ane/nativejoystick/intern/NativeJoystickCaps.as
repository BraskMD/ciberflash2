package com.iam2bam.ane.nativejoystick.intern
{
   import com.iam2bam.ane.nativejoystick.*;
   
   public class NativeJoystickCaps
   {
      public var oemName:String;
      
      public var hasAxis:Vector.<Boolean>;
      
      public var axesRange:Vector.<uint>;
      
      public var hasPOV4Dir:Boolean;
      
      public var hasPOV4Cont:Boolean;
      
      public var numAxes:uint;
      
      public var numButtons:uint;
      
      public var miscProductName:String;
      
      public var miscProductID:uint;
      
      public var miscManufacturerID:uint;
      
      public var miscOSDriver:String;
      
      public var miscOSRegKey:String;
      
      public function NativeJoystickCaps()
      {
         var _local_1:int = 0;
         super();
         this.hasAxis = new Vector.<Boolean>(8,true);
         this.axesRange = new Vector.<uint>(8,true);
         _local_1 = 0;
         while(_local_1 < 8)
         {
            this.axesRange[_local_1] = 1;
            this.hasAxis[_local_1] = false;
            _local_1++;
         }
      }
      
      public function get hasX() : Boolean
      {
         return this.hasAxis[0];
      }
      
      public function get hasY() : Boolean
      {
         return this.hasAxis[1];
      }
      
      public function get hasZ() : Boolean
      {
         return this.hasAxis[2];
      }
      
      public function get hasR() : Boolean
      {
         return this.hasAxis[3];
      }
      
      public function get hasU() : Boolean
      {
         return this.hasAxis[4];
      }
      
      public function get hasV() : Boolean
      {
         return this.hasAxis[5];
      }
      
      public function get hasPOV() : Boolean
      {
         return this.hasPOV4Dir || this.hasPOV4Cont;
      }
      
      private function varToString(_arg_1:String) : String
      {
         return "\t" + _arg_1 + "=" + this[_arg_1] + "/" + this[_arg_1].length + "\n";
      }
      
      public function toString() : String
      {
         var _local_2:int = 0;
         var _local_1:String = "";
         _local_2 = 0;
         while(_local_2 < 8)
         {
            if(this.hasAxis[_local_2])
            {
               _local_1 += "\t\tAxis #" + _local_2 + " " + NativeJoystick.AXIS_NAMES[_local_2] + " (0.." + this.axesRange[_local_2] + ")\n";
            }
            _local_2++;
         }
         return "[RadNativeJoystickCaps(\n" + this.varToString("oemName") + this.varToString("hasPOV4Dir") + this.varToString("hasPOV4Cont") + this.varToString("numButtons") + this.varToString("numAxes") + _local_1 + this.varToString("miscProductName") + this.varToString("miscProductID") + this.varToString("miscManufacturerID") + this.varToString("miscOSDriver") + this.varToString("miscOSRegKey") + "]";
      }
   }
}

