package com.iam2bam.ane.nativejoystick.intern
{
   public class NativeJoystickState
   {
      public var plugged:Boolean;
      
      public var axesRaw:Vector.<uint>;
      
      public var axes:Vector.<Number>;
      
      public var buttons:uint;
      
      public var povAngle:Number;
      
      public var povPressed:Number;
      
      public function NativeJoystickState()
      {
         super();
         var _local_1:uint = 8;
         this.axesRaw = new Vector.<uint>(_local_1,true);
         this.axes = new Vector.<Number>(_local_1,true);
         this.reset(null,false);
      }
      
      public function reset(_arg_1:NativeJoystickCaps, _arg_2:Boolean) : void
      {
         var _local_4:int = 0;
         var _local_3:uint = 8;
         _local_4 = 0;
         while(_local_4 < _local_3)
         {
            this.axesRaw[_local_4] = _arg_1 == null ? 0 : uint(_arg_1.axesRange[_local_4] / 2);
            this.axes[_local_4] = 0;
            _local_4++;
         }
         this.povAngle = 0;
         this.buttons = 0;
         this.plugged = _arg_2;
      }
   }
}

