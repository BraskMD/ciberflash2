package com.worlize.websocket
{
   public class WebSocketError extends Error
   {
      public function WebSocketError(_arg_1:* = "", _arg_2:* = 0)
      {
         super(_arg_1,_arg_2);
      }
   }
}

