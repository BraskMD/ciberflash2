package com.hurlant.crypto.cert
{
   public class X509CertificateCollection
   {
      private var _map:Object;
      
      public function X509CertificateCollection()
      {
         super();
         this._map = {};
      }
      
      public function addPEMCertificate(name:String, subject:String, pem:String) : void
      {
         this._map[subject] = new X509Certificate(pem);
      }
      
      public function addCertificate(cert:X509Certificate) : void
      {
         var subject:String = cert.getSubjectPrincipal();
         this._map[subject] = cert;
      }
      
      public function getCertificate(subject:String) : X509Certificate
      {
         return this._map[subject];
      }
   }
}

