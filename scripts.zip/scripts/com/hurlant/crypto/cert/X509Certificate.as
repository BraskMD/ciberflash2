package com.hurlant.crypto.cert
{
   import com.hurlant.crypto.hash.*;
   import com.hurlant.crypto.rsa.*;
   import com.hurlant.util.*;
   import com.hurlant.util.der.*;
   import flash.utils.*;
   
   public class X509Certificate
   {
      private var _loaded:Boolean;
      
      private var _param:*;
      
      private var _obj:Object;
      
      public function X509Certificate(p:*)
      {
         super();
         this._loaded = false;
         this._param = p;
      }
      
      private function load() : void
      {
         var b:ByteArray = null;
         if(this._loaded)
         {
            return;
         }
         var p:* = this._param;
         if(p is String)
         {
            b = PEM.readCertIntoArray(p as String);
         }
         else if(p is ByteArray)
         {
            b = p;
         }
         if(b != null)
         {
            this._obj = DER.parse(b,Type.TLS_CERT);
            this._loaded = true;
            return;
         }
         throw new Error("Invalid x509 Certificate parameter: " + p);
      }
      
      public function isSigned(store:X509CertificateCollection, CAs:X509CertificateCollection, time:Date = null) : Boolean
      {
         this.load();
         if(time == null)
         {
            time = new Date();
         }
         var notBefore:Date = this.getNotBefore();
         var notAfter:Date = this.getNotAfter();
         if(time.getTime() < notBefore.getTime())
         {
            return false;
         }
         if(time.getTime() > notAfter.getTime())
         {
            return false;
         }
         var subject:String = this.getIssuerPrincipal();
         var parent:X509Certificate = CAs.getCertificate(subject);
         var parentIsAuthoritative:Boolean = false;
         if(parent == null)
         {
            parent = store.getCertificate(subject);
            if(parent == null)
            {
               return false;
            }
         }
         else
         {
            parentIsAuthoritative = true;
         }
         if(parent == this)
         {
            return false;
         }
         if(!(parentIsAuthoritative && parent.isSelfSigned(time)) && !parent.isSigned(store,CAs,time))
         {
            return false;
         }
         var key:RSAKey = parent.getPublicKey();
         return this.verifyCertificate(key);
      }
      
      public function isSelfSigned(time:Date) : Boolean
      {
         this.load();
         var key:RSAKey = this.getPublicKey();
         return this.verifyCertificate(key);
      }
      
      private function verifyCertificate(key:RSAKey) : Boolean
      {
         var hash:IHash = null;
         var oid:String = null;
         var algo:String = this.getAlgorithmIdentifier();
         switch(algo)
         {
            case OID.SHA1_WITH_RSA_ENCRYPTION:
               hash = new SHA1();
               oid = OID.SHA1_ALGORITHM;
               break;
            case OID.MD2_WITH_RSA_ENCRYPTION:
               hash = new MD2();
               oid = OID.MD2_ALGORITHM;
               break;
            case OID.MD5_WITH_RSA_ENCRYPTION:
               hash = new MD5();
               oid = OID.MD5_ALGORITHM;
               break;
            default:
               return false;
         }
         var data:ByteArray = this._obj.signedCertificate_bin;
         var buf:ByteArray = new ByteArray();
         key.verify(this._obj.encrypted,buf,this._obj.encrypted.length);
         buf.position = 0;
         data = hash.hash(data);
         var obj:Object = DER.parse(buf,Type.RSA_SIGNATURE);
         if(obj.algorithm.algorithmId.toString() != oid)
         {
            return false;
         }
         if(!ArrayUtil.equals(obj.hash,data))
         {
            return false;
         }
         return true;
      }
      
      private function signCertificate(key:RSAKey, algo:String) : ByteArray
      {
         var hash:IHash = null;
         var oid:String = null;
         switch(algo)
         {
            case OID.SHA1_WITH_RSA_ENCRYPTION:
               hash = new SHA1();
               oid = OID.SHA1_ALGORITHM;
               break;
            case OID.MD2_WITH_RSA_ENCRYPTION:
               hash = new MD2();
               oid = OID.MD2_ALGORITHM;
               break;
            case OID.MD5_WITH_RSA_ENCRYPTION:
               hash = new MD5();
               oid = OID.MD5_ALGORITHM;
               break;
            default:
               return null;
         }
         var data:ByteArray = this._obj.signedCertificate_bin;
         data = hash.hash(data);
         var seq1:Sequence = new Sequence();
         seq1[0] = new Sequence();
         seq1[0][0] = new ObjectIdentifier(0,0,oid);
         seq1[0][1] = null;
         seq1[1] = new ByteString();
         seq1[1].writeBytes(data);
         data = seq1.toDER();
         var buf:ByteArray = new ByteArray();
         key.sign(data,buf,data.length);
         return buf;
      }
      
      public function getPublicKey() : RSAKey
      {
         this.load();
         var pk:ByteArray = this._obj.signedCertificate.subjectPublicKeyInfo.subjectPublicKey as ByteArray;
         pk.position = 0;
         var rsaKey:Object = DER.parse(pk,[{"name":"N"},{"name":"E"}]);
         return new RSAKey(rsaKey.N,rsaKey.E.valueOf());
      }
      
      public function getSubjectPrincipal() : String
      {
         this.load();
         return Base64.encodeByteArray(this._obj.signedCertificate.subject_bin);
      }
      
      public function getIssuerPrincipal() : String
      {
         this.load();
         return Base64.encodeByteArray(this._obj.signedCertificate.issuer_bin);
      }
      
      public function getAlgorithmIdentifier() : String
      {
         return this._obj.algorithmIdentifier.algorithmId.toString();
      }
      
      public function getNotBefore() : Date
      {
         return this._obj.signedCertificate.validity.notBefore.date;
      }
      
      public function getNotAfter() : Date
      {
         return this._obj.signedCertificate.validity.notAfter.date;
      }
      
      public function getCommonName() : String
      {
         var subject:Sequence = this._obj.signedCertificate.subject;
         return (subject.findAttributeValue(OID.COMMON_NAME) as PrintableString).getString();
      }
   }
}

