package com.hurlant.crypto.prng
{
   import com.hurlant.crypto.hash.*;
   import com.hurlant.util.*;
   import flash.utils.*;
   
   public class TLSPRF
   {
      private var seed:ByteArray;
      
      private var s1:ByteArray;
      
      private var s2:ByteArray;
      
      private var a1:ByteArray;
      
      private var a2:ByteArray;
      
      private var p1:ByteArray;
      
      private var p2:ByteArray;
      
      private var d1:ByteArray;
      
      private var d2:ByteArray;
      
      private var hmac_md5:HMAC;
      
      private var hmac_sha1:HMAC;
      
      public function TLSPRF(secret:ByteArray, label:String, seed:ByteArray)
      {
         super();
         var l:int = Math.ceil(secret.length / 2);
         var s1:ByteArray = new ByteArray();
         var s2:ByteArray = new ByteArray();
         s1.writeBytes(secret,0,l);
         s2.writeBytes(secret,secret.length - l,l);
         var s:ByteArray = new ByteArray();
         s.writeUTFBytes(label);
         s.writeBytes(seed);
         this.seed = s;
         this.s1 = s1;
         this.s2 = s2;
         this.hmac_md5 = new HMAC(new MD5());
         this.hmac_sha1 = new HMAC(new SHA1());
         this.a1 = this.hmac_md5.compute(s1,this.seed);
         this.a2 = this.hmac_sha1.compute(s2,this.seed);
         this.p1 = new ByteArray();
         this.p2 = new ByteArray();
         this.d1 = new ByteArray();
         this.d2 = new ByteArray();
         this.d1.position = MD5.HASH_SIZE;
         this.d1.writeBytes(this.seed);
         this.d2.position = SHA1.HASH_SIZE;
         this.d2.writeBytes(this.seed);
      }
      
      public function nextBytes(buffer:IDataOutput, length:int) : void
      {
         while(length--)
         {
            buffer.writeByte(this.nextByte());
         }
      }
      
      public function nextByte() : int
      {
         if(this.p1.bytesAvailable == 0)
         {
            this.more_md5();
         }
         if(this.p2.bytesAvailable == 0)
         {
            this.more_sha1();
         }
         return this.p1.readUnsignedByte() ^ this.p2.readUnsignedByte();
      }
      
      public function dispose() : void
      {
         this.seed = this.dba(this.seed);
         this.s1 = this.dba(this.s1);
         this.s2 = this.dba(this.s2);
         this.a1 = this.dba(this.a1);
         this.a2 = this.dba(this.a2);
         this.p1 = this.dba(this.p1);
         this.p2 = this.dba(this.p2);
         this.d1 = this.dba(this.d1);
         this.d2 = this.dba(this.d2);
         this.hmac_md5.dispose();
         this.hmac_md5 = null;
         this.hmac_sha1.dispose();
         this.hmac_sha1 = null;
         Memory.gc();
      }
      
      public function toString() : String
      {
         return "tls-prf";
      }
      
      private function dba(ba:ByteArray) : ByteArray
      {
         for(var i:uint = 0; i < ba.length; i++)
         {
            ba[i] = 0;
         }
         ba.length = 0;
         return null;
      }
      
      private function more_md5() : void
      {
         this.d1.position = 0;
         this.d1.writeBytes(this.a1);
         var p:int = int(this.p1.position);
         var more:ByteArray = this.hmac_md5.compute(this.s1,this.d1);
         this.a1 = this.hmac_md5.compute(this.s1,this.a1);
         this.p1.writeBytes(more);
         this.p1.position = p;
      }
      
      private function more_sha1() : void
      {
         this.d2.position = 0;
         this.d2.writeBytes(this.a2);
         var p:int = int(this.p2.position);
         var more:ByteArray = this.hmac_sha1.compute(this.s2,this.d2);
         this.a2 = this.hmac_sha1.compute(this.s2,this.a2);
         this.p2.writeBytes(more);
         this.p2.position = p;
      }
   }
}

