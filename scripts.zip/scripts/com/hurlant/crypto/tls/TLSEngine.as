package com.hurlant.crypto.tls
{
   import com.hurlant.crypto.cert.*;
   import com.hurlant.crypto.prng.*;
   import com.hurlant.util.*;
   import flash.events.*;
   import flash.utils.*;
   
   public class TLSEngine extends EventDispatcher
   {
      public static const SERVER:uint = 0;
      
      public static const CLIENT:uint = 1;
      
      private static const PROTOCOL_HANDSHAKE:uint = 22;
      
      private static const PROTOCOL_ALERT:uint = 21;
      
      private static const PROTOCOL_CHANGE_CIPHER_SPEC:uint = 20;
      
      private static const PROTOCOL_APPLICATION_DATA:uint = 23;
      
      private static const STATE_NEW:uint = 0;
      
      private static const STATE_NEGOTIATING:uint = 1;
      
      private static const STATE_READY:uint = 2;
      
      private static const STATE_CLOSED:uint = 3;
      
      private static const HANDSHAKE_HELLO_REQUEST:uint = 0;
      
      private static const HANDSHAKE_CLIENT_HELLO:uint = 1;
      
      private static const HANDSHAKE_SERVER_HELLO:uint = 2;
      
      private static const HANDSHAKE_CERTIFICATE:uint = 11;
      
      private static const HANDSHAKE_SERVER_KEY_EXCHANGE:uint = 12;
      
      private static const HANDSHAKE_CERTIFICATE_REQUEST:uint = 13;
      
      private static const HANDSHAKE_HELLO_DONE:uint = 14;
      
      private static const HANDSHAKE_CERTIFICATE_VERIFY:uint = 15;
      
      private static const HANDSHAKE_CLIENT_KEY_EXCHANGE:uint = 16;
      
      private static const HANDSHAKE_FINISHED:uint = 20;
      
      public var protocol_version:uint;
      
      private var _entity:uint;
      
      private var _config:TLSConfig;
      
      private var _state:uint;
      
      private var _securityParameters:ISecurityParameters;
      
      private var _currentReadState:IConnectionState;
      
      private var _currentWriteState:IConnectionState;
      
      private var _pendingReadState:IConnectionState;
      
      private var _pendingWriteState:IConnectionState;
      
      private var _handshakePayloads:ByteArray;
      
      private var _handshakeRecords:ByteArray;
      
      private var _iStream:IDataInput;
      
      private var _oStream:IDataOutput;
      
      private var _store:X509CertificateCollection;
      
      private var _otherCertificate:X509Certificate;
      
      private var _otherIdentity:String;
      
      private var _myCertficate:X509Certificate;
      
      private var _myIdentity:String;
      
      private var _packetQueue:Array = [];
      
      private var protocolHandlers:Object = {
         23:this.parseApplicationData,
         22:this.parseHandshake,
         21:this.parseAlert,
         20:this.parseChangeCipherSpec
      };
      
      private var handshakeHandlersServer:Object = {
         0:this.notifyStateError,
         1:this.parseHandshakeClientHello,
         2:this.notifyStateError,
         11:this.loadCertificates,
         12:this.notifyStateError,
         13:this.notifyStateError,
         14:this.notifyStateError,
         15:this.notifyStateError,
         16:this.parseHandshakeClientKeyExchange,
         20:this.verifyHandshake
      };
      
      private var handshakeHandlersClient:Object = {
         0:this.parseHandshakeHello,
         1:this.notifyStateError,
         2:this.parseHandshakeServerHello,
         11:this.loadCertificates,
         12:this.parseServerKeyExchange,
         13:this.setStateRespondWithCertificate,
         14:this.sendClientAck,
         15:this.notifyStateError,
         16:this.notifyStateError,
         20:this.verifyHandshake
      };
      
      private var _entityHandshakeHandlers:Object;
      
      private var _handshakeCanContinue:Boolean = true;
      
      private var _handshakeQueue:Array = [];
      
      private var sendClientCert:Boolean = false;
      
      private var _writeScheduler:uint;
      
      public function TLSEngine(config:TLSConfig, iStream:IDataInput, oStream:IDataOutput, otherIdentity:String = null)
      {
         super();
         this._entity = config.entity;
         this._config = config;
         this._iStream = iStream;
         this._oStream = oStream;
         this._otherIdentity = otherIdentity;
         this._state = STATE_NEW;
         this._entityHandshakeHandlers = this._entity == CLIENT ? this.handshakeHandlersClient : this.handshakeHandlersServer;
         if(this._config.version == SSLSecurityParameters.PROTOCOL_VERSION)
         {
            this._securityParameters = new SSLSecurityParameters(this._entity);
         }
         else
         {
            this._securityParameters = new TLSSecurityParameters(this._entity,this._config.certificate,this._config.privateKey);
         }
         this.protocol_version = this._config.version;
         var states:Object = this._securityParameters.getConnectionStates();
         this._currentReadState = states.read;
         this._currentWriteState = states.write;
         this._handshakePayloads = new ByteArray();
         this._store = new X509CertificateCollection();
      }
      
      public function get peerCertificate() : X509Certificate
      {
         return this._otherCertificate;
      }
      
      public function start() : void
      {
         if(this._entity == CLIENT)
         {
            try
            {
               this.startHandshake();
            }
            catch(e:TLSError)
            {
               handleTLSError(e);
            }
         }
      }
      
      public function dataAvailable(e:* = null) : void
      {
         if(this._state == STATE_CLOSED)
         {
            return;
         }
         try
         {
            this.parseRecord(this._iStream);
         }
         catch(e:TLSError)
         {
            handleTLSError(e);
         }
      }
      
      public function close(e:TLSError = null) : void
      {
         if(this._state == STATE_CLOSED)
         {
            return;
         }
         var rec:ByteArray = new ByteArray();
         if(e == null && this._state != STATE_READY)
         {
            rec[0] = 1;
            rec[1] = TLSError.user_canceled;
            this.sendRecord(PROTOCOL_ALERT,rec);
         }
         rec[0] = 2;
         if(e == null)
         {
            rec[1] = TLSError.close_notify;
         }
         else
         {
            rec[1] = e.errorID;
            trace("TLSEngine shutdown triggered by " + e);
         }
         this.sendRecord(PROTOCOL_ALERT,rec);
         this._state = STATE_CLOSED;
         dispatchEvent(new Event(Event.CLOSE));
      }
      
      private function parseRecord(stream:IDataInput) : void
      {
         var p:ByteArray = null;
         var type:uint = 0;
         var ver:uint = 0;
         var length:uint = 0;
         var actualLength:uint = 0;
         var packet:Object = null;
         while(this._state != STATE_CLOSED && stream.bytesAvailable > 4)
         {
            if(this._packetQueue.length > 0)
            {
               packet = this._packetQueue.shift();
               p = packet.data;
               if(stream.bytesAvailable + p.length >= packet.length)
               {
                  stream.readBytes(p,p.length,packet.length - p.length);
                  this.parseOneRecord(packet.type,packet.length,p);
               }
               else
               {
                  stream.readBytes(p,p.length,stream.bytesAvailable);
                  this._packetQueue.push(packet);
               }
            }
            else
            {
               type = uint(stream.readByte());
               ver = uint(stream.readShort());
               length = uint(stream.readShort());
               if(length > 16384 + 2048)
               {
                  throw new TLSError("Excessive TLS Record length: " + length,TLSError.record_overflow);
               }
               if(ver != this._securityParameters.version)
               {
                  throw new TLSError("Unsupported TLS version: " + ver.toString(16),TLSError.protocol_version);
               }
               p = new ByteArray();
               actualLength = Math.min(stream.bytesAvailable,length);
               stream.readBytes(p,0,actualLength);
               if(actualLength == length)
               {
                  this.parseOneRecord(type,length,p);
               }
               else
               {
                  this._packetQueue.push({
                     "type":type,
                     "length":length,
                     "data":p
                  });
               }
            }
         }
      }
      
      private function parseOneRecord(type:uint, length:uint, p:ByteArray) : void
      {
         p = this._currentReadState.decrypt(type,length,p);
         if(p.length > 16384)
         {
            throw new TLSError("Excessive Decrypted TLS Record length: " + p.length,TLSError.record_overflow);
         }
         if(this.protocolHandlers.hasOwnProperty(type))
         {
            while(p != null)
            {
               p = this.protocolHandlers[type](p);
            }
            return;
         }
         throw new TLSError("Unsupported TLS Record Content Type: " + type.toString(16),TLSError.unexpected_message);
      }
      
      private function startHandshake() : void
      {
         this._state = STATE_NEGOTIATING;
         this.sendClientHello();
      }
      
      private function parseHandshake(p:ByteArray) : ByteArray
      {
         var n:ByteArray = null;
         if(p.length < 4)
         {
            trace("Handshake packet is way too short. bailing.");
            return null;
         }
         p.position = 0;
         var rec:ByteArray = p;
         var type:uint = rec.readUnsignedByte();
         var tmp:uint = rec.readUnsignedByte();
         var length:uint = uint(tmp << 16 | rec.readUnsignedShort());
         if(length + 4 > p.length)
         {
            trace("Handshake packet is incomplete. bailing.");
            return null;
         }
         if(type != HANDSHAKE_FINISHED)
         {
            this._handshakePayloads.writeBytes(p,0,length + 4);
         }
         if(this._entityHandshakeHandlers.hasOwnProperty(type))
         {
            if(this._entityHandshakeHandlers[type] is Function)
            {
               this._entityHandshakeHandlers[type](rec);
            }
            if(length + 4 < p.length)
            {
               n = new ByteArray();
               n.writeBytes(p,length + 4,p.length - (length + 4));
               return n;
            }
            return null;
         }
         throw new TLSError("Unimplemented or unknown handshake type!",TLSError.internal_error);
      }
      
      private function notifyStateError(rec:ByteArray) : void
      {
         throw new TLSError("Invalid handshake state for a TLS Entity type of " + this._entity,TLSError.internal_error);
      }
      
      private function parseClientKeyExchange(rec:ByteArray) : void
      {
         throw new TLSError("ClientKeyExchange is currently unimplemented!",TLSError.internal_error);
      }
      
      private function parseServerKeyExchange(rec:ByteArray) : void
      {
         throw new TLSError("ServerKeyExchange is currently unimplemented!",TLSError.internal_error);
      }
      
      private function verifyHandshake(rec:ByteArray) : void
      {
         var verifyData:ByteArray = new ByteArray();
         if(this._securityParameters.version == SSLSecurityParameters.PROTOCOL_VERSION)
         {
            rec.readBytes(verifyData,0,36);
         }
         else
         {
            rec.readBytes(verifyData,0,12);
         }
         var data:ByteArray = this._securityParameters.computeVerifyData(1 - this._entity,this._handshakePayloads);
         if(ArrayUtil.equals(verifyData,data))
         {
            this._state = STATE_READY;
            dispatchEvent(new TLSEvent(TLSEvent.READY));
            return;
         }
         throw new TLSError("Invalid Finished mac.",TLSError.bad_record_mac);
      }
      
      private function parseHandshakeHello(rec:ByteArray) : void
      {
         if(this._state != STATE_READY)
         {
            trace("Received an HELLO_REQUEST before being in state READY. ignoring.");
            return;
         }
         this._handshakePayloads = new ByteArray();
         this.startHandshake();
      }
      
      private function parseHandshakeClientKeyExchange(rec:ByteArray) : void
      {
         var len:uint = 0;
         var cipher:ByteArray = null;
         var preMasterSecret:ByteArray = null;
         var o:Object = null;
         if(this._securityParameters.useRSA)
         {
            len = uint(rec.readShort());
            cipher = new ByteArray();
            rec.readBytes(cipher,0,len);
            preMasterSecret = new ByteArray();
            this._config.privateKey.decrypt(cipher,preMasterSecret,len);
            this._securityParameters.setPreMasterSecret(preMasterSecret);
            o = this._securityParameters.getConnectionStates();
            this._pendingReadState = o.read;
            this._pendingWriteState = o.write;
            return;
         }
         throw new TLSError("parseHandshakeClientKeyExchange not implemented for DH modes.",TLSError.internal_error);
      }
      
      private function parseHandshakeServerHello(rec:IDataInput) : void
      {
         var ver:uint = uint(rec.readShort());
         if(ver != this._securityParameters.version)
         {
            throw new TLSError("Unsupported TLS version: " + ver.toString(16),TLSError.protocol_version);
         }
         var random:ByteArray = new ByteArray();
         rec.readBytes(random,0,32);
         var session_length:uint = uint(rec.readByte());
         var session:ByteArray = new ByteArray();
         if(session_length > 0)
         {
            rec.readBytes(session,0,session_length);
         }
         this._securityParameters.setCipher(rec.readShort());
         this._securityParameters.setCompression(rec.readByte());
         this._securityParameters.setServerRandom(random);
      }
      
      private function parseHandshakeClientHello(rec:IDataInput) : void
      {
         var ret:Object = null;
         var ext_total_length:uint = 0;
         var ext_type:uint = 0;
         var ext_length:uint = 0;
         var ext_data:ByteArray = null;
         var ver:uint = uint(rec.readShort());
         if(ver != this._securityParameters.version)
         {
            throw new TLSError("Unsupported TLS version: " + ver.toString(16),TLSError.protocol_version);
         }
         var random:ByteArray = new ByteArray();
         rec.readBytes(random,0,32);
         var session_length:uint = uint(rec.readByte());
         var session:ByteArray = new ByteArray();
         if(session_length > 0)
         {
            rec.readBytes(session,0,session_length);
         }
         var suites:Array = [];
         var suites_length:uint = uint(rec.readShort());
         for(var i:uint = 0; i < suites_length / 2; i++)
         {
            suites.push(rec.readShort());
         }
         var compressions:Array = [];
         var comp_length:uint = uint(rec.readByte());
         for(i = 0; i < comp_length; i++)
         {
            compressions.push(rec.readByte());
         }
         ret = {
            "random":random,
            "session":session,
            "suites":suites,
            "compressions":compressions
         };
         var sofar:uint = uint(2 + 32 + 1 + session_length + 2 + suites_length + 1 + comp_length);
         var extensions:Array = [];
         if(sofar < length)
         {
            ext_total_length = uint(rec.readShort());
            while(ext_total_length > 0)
            {
               ext_type = uint(rec.readShort());
               ext_length = uint(rec.readShort());
               ext_data = new ByteArray();
               rec.readBytes(ext_data,0,ext_length);
               ext_total_length -= 4 + ext_length;
               extensions.push({
                  "type":ext_type,
                  "length":ext_length,
                  "data":ext_data
               });
            }
         }
         ret.ext = extensions;
         this.sendServerHello(ret);
         this.sendCertificate();
         this.sendServerHelloDone();
      }
      
      private function sendClientHello() : void
      {
         var rec:ByteArray = new ByteArray();
         rec.writeShort(this._securityParameters.version);
         var prng:Random = new Random();
         var clientRandom:ByteArray = new ByteArray();
         prng.nextBytes(clientRandom,32);
         this._securityParameters.setClientRandom(clientRandom);
         rec.writeBytes(clientRandom,0,32);
         rec.writeByte(32);
         prng.nextBytes(rec,32);
         var cs:Array = this._config.cipherSuites;
         rec.writeShort(2 * cs.length);
         for(var i:int = 0; i < cs.length; i++)
         {
            rec.writeShort(cs[i]);
         }
         cs = this._config.compressions;
         rec.writeByte(cs.length);
         for(i = 0; i < cs.length; i++)
         {
            rec.writeByte(cs[i]);
         }
         rec.position = 0;
         this.sendHandshake(HANDSHAKE_CLIENT_HELLO,rec.length,rec);
      }
      
      private function findMatch(a1:Array, a2:Array) : int
      {
         var e:uint = 0;
         for(var i:int = 0; i < a1.length; i++)
         {
            e = uint(a1[i]);
            if(a2.indexOf(e) > -1)
            {
               return e;
            }
         }
         return -1;
      }
      
      private function sendServerHello(v:Object) : void
      {
         var cipher:int = int(this.findMatch(this._config.cipherSuites,v.suites));
         if(cipher == -1)
         {
            throw new TLSError("No compatible cipher found.",TLSError.handshake_failure);
         }
         this._securityParameters.setCipher(cipher);
         var comp:int = int(this.findMatch(this._config.compressions,v.compressions));
         if(comp == 1)
         {
            throw new TLSError("No compatible compression method found.",TLSError.handshake_failure);
         }
         this._securityParameters.setCompression(comp);
         this._securityParameters.setClientRandom(v.random);
         var rec:ByteArray = new ByteArray();
         rec.writeShort(this._securityParameters.version);
         var prng:Random = new Random();
         var serverRandom:ByteArray = new ByteArray();
         prng.nextBytes(serverRandom,32);
         this._securityParameters.setServerRandom(serverRandom);
         rec.writeBytes(serverRandom,0,32);
         rec.writeByte(32);
         prng.nextBytes(rec,32);
         rec.writeShort(v.suites[0]);
         rec.writeByte(v.compressions[0]);
         rec.position = 0;
         this.sendHandshake(HANDSHAKE_SERVER_HELLO,rec.length,rec);
      }
      
      private function setStateRespondWithCertificate(r:ByteArray = null) : void
      {
         this.sendClientCert = true;
      }
      
      private function sendCertificate(r:ByteArray = null) : void
      {
         var len:uint = 0;
         var len2:uint = 0;
         var cert:ByteArray = this._config.certificate;
         var rec:ByteArray = new ByteArray();
         if(cert != null)
         {
            len = cert.length;
            len2 = uint(cert.length + 3);
            rec.writeByte(len2 >> 16);
            rec.writeShort(len2 & 0xFFFF);
            rec.writeByte(len >> 16);
            rec.writeShort(len & 0xFFFF);
            rec.writeBytes(cert);
         }
         else
         {
            rec.writeShort(0);
            rec.writeByte(0);
         }
         rec.position = 0;
         this.sendHandshake(HANDSHAKE_CERTIFICATE,rec.length,rec);
      }
      
      private function sendCertificateVerify() : void
      {
         var rec:ByteArray = new ByteArray();
         var data:ByteArray = this._securityParameters.computeCertificateVerify(this._entity,this._handshakePayloads);
         data.position = 0;
         this.sendHandshake(HANDSHAKE_CERTIFICATE_VERIFY,data.length,data);
      }
      
      private function sendServerHelloDone() : void
      {
         var rec:ByteArray = new ByteArray();
         this.sendHandshake(HANDSHAKE_HELLO_DONE,rec.length,rec);
      }
      
      private function sendClientKeyExchange() : void
      {
         var p:ByteArray = null;
         var prng:Random = null;
         var preMasterSecret:ByteArray = null;
         var enc_key:ByteArray = null;
         var rec:ByteArray = null;
         var o:Object = null;
         if(this._securityParameters.useRSA)
         {
            p = new ByteArray();
            p.writeShort(this._securityParameters.version);
            prng = new Random();
            prng.nextBytes(p,46);
            p.position = 0;
            preMasterSecret = new ByteArray();
            preMasterSecret.writeBytes(p,0,p.length);
            preMasterSecret.position = 0;
            this._securityParameters.setPreMasterSecret(preMasterSecret);
            enc_key = new ByteArray();
            this._otherCertificate.getPublicKey().encrypt(preMasterSecret,enc_key,preMasterSecret.length);
            enc_key.position = 0;
            rec = new ByteArray();
            if(this._securityParameters.version > 768)
            {
               rec.writeShort(enc_key.length);
            }
            rec.writeBytes(enc_key,0,enc_key.length);
            rec.position = 0;
            this.sendHandshake(HANDSHAKE_CLIENT_KEY_EXCHANGE,rec.length,rec);
            o = this._securityParameters.getConnectionStates();
            this._pendingReadState = o.read;
            this._pendingWriteState = o.write;
            return;
         }
         throw new TLSError("Non-RSA Client Key Exchange not implemented.",TLSError.internal_error);
      }
      
      private function sendFinished() : void
      {
         var data:ByteArray = this._securityParameters.computeVerifyData(this._entity,this._handshakePayloads);
         data.position = 0;
         this.sendHandshake(HANDSHAKE_FINISHED,data.length,data);
      }
      
      private function sendHandshake(type:uint, len:uint, payload:IDataInput) : void
      {
         var rec:ByteArray = new ByteArray();
         rec.writeByte(type);
         rec.writeByte(0);
         rec.writeShort(len);
         payload.readBytes(rec,rec.position,len);
         this._handshakePayloads.writeBytes(rec,0,rec.length);
         this.sendRecord(PROTOCOL_HANDSHAKE,rec);
      }
      
      private function sendChangeCipherSpec() : void
      {
         var rec:ByteArray = new ByteArray();
         rec[0] = 1;
         this.sendRecord(PROTOCOL_CHANGE_CIPHER_SPEC,rec);
         this._currentWriteState = this._pendingWriteState;
         this._pendingWriteState = null;
      }
      
      public function sendApplicationData(data:ByteArray, offset:uint = 0, length:uint = 0) : void
      {
         var rec:ByteArray = new ByteArray();
         var len:uint = length;
         if(len == 0)
         {
            len = data.length;
         }
         while(len > 16384)
         {
            rec.position = 0;
            rec.writeBytes(data,offset,16384);
            rec.position = 0;
            this.sendRecord(PROTOCOL_APPLICATION_DATA,rec);
            offset += 16384;
            len -= 16384;
         }
         rec.position = 0;
         rec.writeBytes(data,offset,len);
         rec.position = 0;
         this.sendRecord(PROTOCOL_APPLICATION_DATA,rec);
      }
      
      private function sendRecord(type:uint, payload:ByteArray) : void
      {
         payload = this._currentWriteState.encrypt(type,payload);
         this._oStream.writeByte(type);
         this._oStream.writeShort(this._securityParameters.version);
         this._oStream.writeShort(payload.length);
         this._oStream.writeBytes(payload,0,payload.length);
         this.scheduleWrite();
      }
      
      private function scheduleWrite() : void
      {
         if(this._writeScheduler != 0)
         {
            return;
         }
         this._writeScheduler = setTimeout(this.commitWrite,0);
      }
      
      private function commitWrite() : void
      {
         clearTimeout(this._writeScheduler);
         this._writeScheduler = 0;
         if(this._state != STATE_CLOSED)
         {
            dispatchEvent(new ProgressEvent(ProgressEvent.SOCKET_DATA));
         }
      }
      
      private function sendClientAck(rec:ByteArray) : void
      {
         if(this._handshakeCanContinue)
         {
            if(this.sendClientCert)
            {
               this.sendCertificate();
            }
            this.sendClientKeyExchange();
            if(this._config.certificate != null)
            {
               this.sendCertificateVerify();
            }
            this.sendChangeCipherSpec();
            this.sendFinished();
         }
      }
      
      private function loadCertificates(rec:ByteArray) : void
      {
         var certTrusted:Boolean = false;
         var cert_len:uint = 0;
         var cert:ByteArray = null;
         var x509:X509Certificate = null;
         var commonName:String = null;
         var commonNameRegex:RegExp = null;
         var tmp:uint = uint(rec.readByte());
         var certs_len:uint = uint(tmp << 16 | rec.readShort());
         var certs:Array = [];
         while(certs_len > 0)
         {
            tmp = uint(rec.readByte());
            cert_len = uint(tmp << 16 | rec.readShort());
            cert = new ByteArray();
            rec.readBytes(cert,0,cert_len);
            certs.push(cert);
            certs_len -= 3 + cert_len;
         }
         var firstCert:X509Certificate = null;
         for(var i:int = 0; i < certs.length; i++)
         {
            x509 = new X509Certificate(certs[i]);
            this._store.addCertificate(x509);
            if(firstCert == null)
            {
               firstCert = x509;
            }
         }
         if(this._config.trustAllCertificates)
         {
            certTrusted = true;
         }
         else if(this._config.trustSelfSignedCertificates)
         {
            certTrusted = firstCert.isSelfSigned(new Date());
         }
         else
         {
            certTrusted = firstCert.isSigned(this._store,this._config.CAStore);
         }
         if(certTrusted)
         {
            if(this._otherIdentity == null || Boolean(this._config.ignoreCommonNameMismatch))
            {
               this._otherCertificate = firstCert;
            }
            else
            {
               commonName = firstCert.getCommonName();
               commonNameRegex = new RegExp(commonName.replace(/[\^\\\-$.[\]|()?+{}]/g,"\\$&").replace(/\*/g,"[^.]+"),"gi");
               if(commonNameRegex.exec(this._otherIdentity))
               {
                  this._otherCertificate = firstCert;
               }
               else
               {
                  if(!this._config.promptUserForAcceptCert)
                  {
                     throw new TLSError("Invalid common name: " + firstCert.getCommonName() + ", expected " + this._otherIdentity,TLSError.bad_certificate);
                  }
                  this._handshakeCanContinue = false;
                  dispatchEvent(new TLSEvent(TLSEvent.PROMPT_ACCEPT_CERT));
               }
            }
         }
         else
         {
            if(!this._config.promptUserForAcceptCert)
            {
               throw new TLSError("Cannot verify certificate",TLSError.bad_certificate);
            }
            this._handshakeCanContinue = false;
            dispatchEvent(new TLSEvent(TLSEvent.PROMPT_ACCEPT_CERT));
         }
      }
      
      public function acceptPeerCertificate() : void
      {
         this._handshakeCanContinue = true;
         this.sendClientAck(null);
      }
      
      public function rejectPeerCertificate() : void
      {
         throw new TLSError("Peer certificate not accepted!",TLSError.bad_certificate);
      }
      
      private function parseAlert(p:ByteArray) : void
      {
         trace("GOT ALERT! type=" + p[1]);
         this.close();
      }
      
      private function parseChangeCipherSpec(p:ByteArray) : void
      {
         p.readUnsignedByte();
         if(this._pendingReadState == null)
         {
            throw new TLSError("Not ready to Change Cipher Spec, damnit.",TLSError.unexpected_message);
         }
         this._currentReadState = this._pendingReadState;
         this._pendingReadState = null;
      }
      
      private function parseApplicationData(p:ByteArray) : void
      {
         if(this._state != STATE_READY)
         {
            throw new TLSError("Too soon for data!",TLSError.unexpected_message);
         }
         dispatchEvent(new TLSEvent(TLSEvent.DATA,p));
      }
      
      private function handleTLSError(e:TLSError) : void
      {
         this.close(e);
      }
   }
}

