package com.hurlant.crypto.tls
{
   import com.hurlant.crypto.cert.X509Certificate;
   import flash.events.*;
   import flash.net.*;
   import flash.utils.*;
   
   public class TLSSocket extends Socket implements IDataInput, IDataOutput
   {
      public static const ACCEPT_PEER_CERT_PROMPT:String = "acceptPeerCertificatePrompt";
      
      private var _endian:String;
      
      private var _objectEncoding:uint;
      
      private var _iStream:ByteArray;
      
      private var _oStream:ByteArray;
      
      private var _iStream_cursor:uint;
      
      private var _socket:Socket;
      
      private var _config:TLSConfig;
      
      private var _engine:TLSEngine;
      
      private var _ready:Boolean;
      
      private var _writeScheduler:uint;
      
      public function TLSSocket(host:String = null, port:int = 0, config:TLSConfig = null)
      {
         super();
         this._config = config;
         if(host != null && port != 0)
         {
            this.connect(host,port);
         }
      }
      
      override public function get bytesAvailable() : uint
      {
         return this._iStream.bytesAvailable;
      }
      
      override public function get connected() : Boolean
      {
         return Boolean(this._socket) && Boolean(this._socket.connected);
      }
      
      override public function get endian() : String
      {
         return this._endian;
      }
      
      override public function set endian(value:String) : void
      {
         this._endian = value;
         this._iStream.endian = value;
         this._oStream.endian = value;
      }
      
      override public function get objectEncoding() : uint
      {
         return this._objectEncoding;
      }
      
      override public function set objectEncoding(value:uint) : void
      {
         this._objectEncoding = value;
         this._iStream.objectEncoding = value;
         this._oStream.objectEncoding = value;
      }
      
      private function onTLSData(event:TLSEvent) : void
      {
         if(this._iStream.position == this._iStream.length)
         {
            this._iStream.position = 0;
            this._iStream.length = 0;
            this._iStream_cursor = 0;
         }
         var cursor:uint = uint(this._iStream.position);
         this._iStream.position = this._iStream_cursor;
         this._iStream.writeBytes(event.data);
         this._iStream_cursor = this._iStream.position;
         this._iStream.position = cursor;
         dispatchEvent(new ProgressEvent(ProgressEvent.SOCKET_DATA,false,false,event.data.length));
      }
      
      private function onTLSReady(event:TLSEvent) : void
      {
         this._ready = true;
         this.scheduleWrite();
      }
      
      private function onTLSClose(event:Event) : void
      {
         dispatchEvent(event);
         this.close();
      }
      
      private function scheduleWrite() : void
      {
         if(this._writeScheduler != 0)
         {
            return;
         }
         this._writeScheduler = setTimeout(this.commitWrite,0);
      }
      
      private function commitWrite() : void
      {
         clearTimeout(this._writeScheduler);
         this._writeScheduler = 0;
         if(this._ready)
         {
            this._engine.sendApplicationData(this._oStream);
            this._oStream.length = 0;
         }
      }
      
      override public function close() : void
      {
         this._ready = false;
         this._engine.close();
         if(this._socket.connected)
         {
            this._socket.flush();
            this._socket.close();
         }
      }
      
      public function setTLSConfig(config:TLSConfig) : void
      {
         this._config = config;
      }
      
      override public function connect(host:String, port:int) : void
      {
         this.init(new Socket(),this._config,host);
         this._socket.connect(host,port);
         this._engine.start();
      }
      
      public function releaseSocket() : void
      {
         this._socket.removeEventListener(Event.CONNECT,dispatchEvent);
         this._socket.removeEventListener(IOErrorEvent.IO_ERROR,dispatchEvent);
         this._socket.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,dispatchEvent);
         this._socket.removeEventListener(Event.CLOSE,dispatchEvent);
         this._socket.removeEventListener(ProgressEvent.SOCKET_DATA,this._engine.dataAvailable);
         this._socket = null;
      }
      
      public function reinitialize(host:String, config:TLSConfig) : void
      {
         var ba:ByteArray = new ByteArray();
         if(this._socket.bytesAvailable > 0)
         {
            this._socket.readBytes(ba,0,this._socket.bytesAvailable);
         }
         this._iStream = new ByteArray();
         this._oStream = new ByteArray();
         this._iStream_cursor = 0;
         this.objectEncoding = ObjectEncoding.DEFAULT;
         this.endian = Endian.BIG_ENDIAN;
         if(config == null)
         {
            config = new TLSConfig(TLSEngine.CLIENT);
         }
         this._engine = new TLSEngine(config,this._socket,this._socket,host);
         this._engine.addEventListener(TLSEvent.DATA,this.onTLSData);
         this._engine.addEventListener(TLSEvent.READY,this.onTLSReady);
         this._engine.addEventListener(Event.CLOSE,this.onTLSClose);
         this._engine.addEventListener(ProgressEvent.SOCKET_DATA,function(e:*):void
         {
            _socket.flush();
         });
         this._socket.addEventListener(ProgressEvent.SOCKET_DATA,this._engine.dataAvailable);
         this._engine.addEventListener(TLSEvent.PROMPT_ACCEPT_CERT,this.onAcceptCert);
         this._ready = false;
         this._engine.start();
      }
      
      public function startTLS(socket:Socket, host:String, config:TLSConfig = null) : void
      {
         if(!socket.connected)
         {
            throw new Error("Cannot STARTTLS on a socket that isn\'t connected.");
         }
         this.init(socket,config,host);
         this._engine.start();
      }
      
      private function init(socket:Socket, config:TLSConfig, host:String) : void
      {
         this._iStream = new ByteArray();
         this._oStream = new ByteArray();
         this._iStream_cursor = 0;
         this.objectEncoding = ObjectEncoding.DEFAULT;
         this.endian = Endian.BIG_ENDIAN;
         this._socket = socket;
         this._socket.addEventListener(Event.CONNECT,dispatchEvent);
         this._socket.addEventListener(IOErrorEvent.IO_ERROR,dispatchEvent);
         this._socket.addEventListener(SecurityErrorEvent.SECURITY_ERROR,dispatchEvent);
         this._socket.addEventListener(Event.CLOSE,dispatchEvent);
         if(config == null)
         {
            config = new TLSConfig(TLSEngine.CLIENT);
         }
         this._engine = new TLSEngine(config,this._socket,this._socket,host);
         this._engine.addEventListener(TLSEvent.DATA,this.onTLSData);
         this._engine.addEventListener(TLSEvent.PROMPT_ACCEPT_CERT,this.onAcceptCert);
         this._engine.addEventListener(TLSEvent.READY,this.onTLSReady);
         this._engine.addEventListener(Event.CLOSE,this.onTLSClose);
         this._engine.addEventListener(ProgressEvent.SOCKET_DATA,function(e:*):void
         {
            if(connected)
            {
               _socket.flush();
            }
         });
         this._socket.addEventListener(ProgressEvent.SOCKET_DATA,this._engine.dataAvailable);
         this._ready = false;
      }
      
      override public function flush() : void
      {
         this.commitWrite();
         this._socket.flush();
      }
      
      override public function readBoolean() : Boolean
      {
         return this._iStream.readBoolean();
      }
      
      override public function readByte() : int
      {
         return this._iStream.readByte();
      }
      
      override public function readBytes(bytes:ByteArray, offset:uint = 0, length:uint = 0) : void
      {
         this._iStream.readBytes(bytes,offset,length);
      }
      
      override public function readDouble() : Number
      {
         return this._iStream.readDouble();
      }
      
      override public function readFloat() : Number
      {
         return this._iStream.readFloat();
      }
      
      override public function readInt() : int
      {
         return this._iStream.readInt();
      }
      
      override public function readMultiByte(length:uint, charSet:String) : String
      {
         return this._iStream.readMultiByte(length,charSet);
      }
      
      override public function readObject() : *
      {
         return this._iStream.readObject();
      }
      
      override public function readShort() : int
      {
         return this._iStream.readShort();
      }
      
      override public function readUnsignedByte() : uint
      {
         return this._iStream.readUnsignedByte();
      }
      
      override public function readUnsignedInt() : uint
      {
         return this._iStream.readUnsignedInt();
      }
      
      override public function readUnsignedShort() : uint
      {
         return this._iStream.readUnsignedShort();
      }
      
      override public function readUTF() : String
      {
         return this._iStream.readUTF();
      }
      
      override public function readUTFBytes(length:uint) : String
      {
         return this._iStream.readUTFBytes(length);
      }
      
      override public function writeBoolean(value:Boolean) : void
      {
         this._oStream.writeBoolean(value);
         this.scheduleWrite();
      }
      
      override public function writeByte(value:int) : void
      {
         this._oStream.writeByte(value);
         this.scheduleWrite();
      }
      
      override public function writeBytes(bytes:ByteArray, offset:uint = 0, length:uint = 0) : void
      {
         this._oStream.writeBytes(bytes,offset,length);
         this.scheduleWrite();
      }
      
      override public function writeDouble(value:Number) : void
      {
         this._oStream.writeDouble(value);
         this.scheduleWrite();
      }
      
      override public function writeFloat(value:Number) : void
      {
         this._oStream.writeFloat(value);
         this.scheduleWrite();
      }
      
      override public function writeInt(value:int) : void
      {
         this._oStream.writeInt(value);
         this.scheduleWrite();
      }
      
      override public function writeMultiByte(value:String, charSet:String) : void
      {
         this._oStream.writeMultiByte(value,charSet);
         this.scheduleWrite();
      }
      
      override public function writeObject(object:*) : void
      {
         this._oStream.writeObject(object);
         this.scheduleWrite();
      }
      
      override public function writeShort(value:int) : void
      {
         this._oStream.writeShort(value);
         this.scheduleWrite();
      }
      
      override public function writeUnsignedInt(value:uint) : void
      {
         this._oStream.writeUnsignedInt(value);
         this.scheduleWrite();
      }
      
      override public function writeUTF(value:String) : void
      {
         this._oStream.writeUTF(value);
         this.scheduleWrite();
      }
      
      override public function writeUTFBytes(value:String) : void
      {
         this._oStream.writeUTFBytes(value);
         this.scheduleWrite();
      }
      
      public function getPeerCertificate() : X509Certificate
      {
         return this._engine.peerCertificate;
      }
      
      public function onAcceptCert(event:TLSEvent) : void
      {
         dispatchEvent(new TLSSocketEvent(this._engine.peerCertificate));
      }
      
      public function acceptPeerCertificate(event:Event) : void
      {
         this._engine.acceptPeerCertificate();
      }
      
      public function rejectPeerCertificate(event:Event) : void
      {
         this._engine.rejectPeerCertificate();
      }
   }
}

