package com.hurlant.crypto.tls
{
   import com.hurlant.crypto.hash.*;
   import com.hurlant.crypto.prng.*;
   import com.hurlant.crypto.rsa.RSAKey;
   import com.hurlant.util.*;
   import flash.utils.*;
   
   public class TLSSecurityParameters implements ISecurityParameters
   {
      public static var USER_CERTIFICATE:String;
      
      public static const COMPRESSION_NULL:uint = 0;
      
      public static var IGNORE_CN_MISMATCH:Boolean = true;
      
      public static var ENABLE_USER_CLIENT_CERTIFICATE:Boolean = false;
      
      public static const PROTOCOL_VERSION:uint = 769;
      
      private var cert:ByteArray;
      
      private var key:RSAKey;
      
      private var entity:uint;
      
      private var bulkCipher:uint;
      
      private var cipherType:uint;
      
      private var keySize:uint;
      
      private var keyMaterialLength:uint;
      
      private var IVSize:uint;
      
      private var macAlgorithm:uint;
      
      private var hashSize:uint;
      
      private var compression:uint;
      
      private var masterSecret:ByteArray;
      
      private var clientRandom:ByteArray;
      
      private var serverRandom:ByteArray;
      
      private var ignoreCNMismatch:Boolean = true;
      
      private var trustAllCerts:Boolean = false;
      
      private var trustSelfSigned:Boolean = false;
      
      private var tlsDebug:Boolean = false;
      
      public var keyExchange:uint;
      
      public function TLSSecurityParameters(entity:uint, localCert:ByteArray = null, localKey:RSAKey = null)
      {
         super();
         this.entity = entity;
         this.reset();
         this.key = localKey;
         this.cert = localCert;
      }
      
      public function get version() : uint
      {
         return PROTOCOL_VERSION;
      }
      
      public function reset() : void
      {
         this.bulkCipher = BulkCiphers.NULL;
         this.cipherType = BulkCiphers.BLOCK_CIPHER;
         this.macAlgorithm = MACs.NULL;
         this.compression = COMPRESSION_NULL;
         this.masterSecret = null;
      }
      
      public function getBulkCipher() : uint
      {
         return this.bulkCipher;
      }
      
      public function getCipherType() : uint
      {
         return this.cipherType;
      }
      
      public function getMacAlgorithm() : uint
      {
         return this.macAlgorithm;
      }
      
      public function setCipher(cipher:uint) : void
      {
         this.bulkCipher = CipherSuites.getBulkCipher(cipher);
         this.cipherType = BulkCiphers.getType(this.bulkCipher);
         this.keySize = BulkCiphers.getExpandedKeyBytes(this.bulkCipher);
         this.keyMaterialLength = BulkCiphers.getKeyBytes(this.bulkCipher);
         this.IVSize = BulkCiphers.getIVSize(this.bulkCipher);
         this.keyExchange = CipherSuites.getKeyExchange(cipher);
         this.macAlgorithm = CipherSuites.getMac(cipher);
         this.hashSize = MACs.getHashSize(this.macAlgorithm);
      }
      
      public function setCompression(algo:uint) : void
      {
         this.compression = algo;
      }
      
      public function setPreMasterSecret(secret:ByteArray) : void
      {
         var seed:ByteArray = new ByteArray();
         seed.writeBytes(this.clientRandom,0,this.clientRandom.length);
         seed.writeBytes(this.serverRandom,0,this.serverRandom.length);
         var prf:TLSPRF = new TLSPRF(secret,"master secret",seed);
         this.masterSecret = new ByteArray();
         prf.nextBytes(this.masterSecret,48);
         if(this.tlsDebug)
         {
            trace("Master Secret: " + Hex.fromArray(this.masterSecret,true));
         }
      }
      
      public function setClientRandom(secret:ByteArray) : void
      {
         this.clientRandom = secret;
      }
      
      public function setServerRandom(secret:ByteArray) : void
      {
         this.serverRandom = secret;
      }
      
      public function get useRSA() : Boolean
      {
         return KeyExchanges.useRSA(this.keyExchange);
      }
      
      public function computeVerifyData(side:uint, handshakeMessages:ByteArray) : ByteArray
      {
         var seed:ByteArray = new ByteArray();
         var md5:MD5 = new MD5();
         if(this.tlsDebug)
         {
            trace("Handshake value: " + Hex.fromArray(handshakeMessages,true));
         }
         seed.writeBytes(md5.hash(handshakeMessages),0,md5.getHashSize());
         var sha:SHA1 = new SHA1();
         seed.writeBytes(sha.hash(handshakeMessages),0,sha.getHashSize());
         if(this.tlsDebug)
         {
            trace("Seed in: " + Hex.fromArray(seed,true));
         }
         var prf:TLSPRF = new TLSPRF(this.masterSecret,side == TLSEngine.CLIENT ? "client finished" : "server finished",seed);
         var out:ByteArray = new ByteArray();
         prf.nextBytes(out,12);
         if(this.tlsDebug)
         {
            trace("Finished out: " + Hex.fromArray(out,true));
         }
         out.position = 0;
         return out;
      }
      
      public function computeCertificateVerify(side:uint, handshakeMessages:ByteArray) : ByteArray
      {
         var seed:ByteArray = new ByteArray();
         var md5:MD5 = new MD5();
         seed.writeBytes(md5.hash(handshakeMessages),0,md5.getHashSize());
         var sha:SHA1 = new SHA1();
         seed.writeBytes(sha.hash(handshakeMessages),0,sha.getHashSize());
         seed.position = 0;
         var out:ByteArray = new ByteArray();
         this.key.sign(seed,out,seed.bytesAvailable);
         out.position = 0;
         return out;
      }
      
      public function getConnectionStates() : Object
      {
         var seed:ByteArray = null;
         var prf:TLSPRF = null;
         var client_write_MAC:ByteArray = null;
         var server_write_MAC:ByteArray = null;
         var client_write_key:ByteArray = null;
         var server_write_key:ByteArray = null;
         var client_write_IV:ByteArray = null;
         var server_write_IV:ByteArray = null;
         var client_write:TLSConnectionState = null;
         var server_write:TLSConnectionState = null;
         if(this.masterSecret != null)
         {
            seed = new ByteArray();
            seed.writeBytes(this.serverRandom,0,this.serverRandom.length);
            seed.writeBytes(this.clientRandom,0,this.clientRandom.length);
            prf = new TLSPRF(this.masterSecret,"key expansion",seed);
            client_write_MAC = new ByteArray();
            prf.nextBytes(client_write_MAC,this.hashSize);
            server_write_MAC = new ByteArray();
            prf.nextBytes(server_write_MAC,this.hashSize);
            client_write_key = new ByteArray();
            prf.nextBytes(client_write_key,this.keyMaterialLength);
            server_write_key = new ByteArray();
            prf.nextBytes(server_write_key,this.keyMaterialLength);
            client_write_IV = new ByteArray();
            prf.nextBytes(client_write_IV,this.IVSize);
            server_write_IV = new ByteArray();
            prf.nextBytes(server_write_IV,this.IVSize);
            client_write = new TLSConnectionState(this.bulkCipher,this.cipherType,this.macAlgorithm,client_write_MAC,client_write_key,client_write_IV);
            server_write = new TLSConnectionState(this.bulkCipher,this.cipherType,this.macAlgorithm,server_write_MAC,server_write_key,server_write_IV);
            if(this.entity == TLSEngine.CLIENT)
            {
               return {
                  "read":server_write,
                  "write":client_write
               };
            }
            return {
               "read":client_write,
               "write":server_write
            };
         }
         return {
            "read":new TLSConnectionState(),
            "write":new TLSConnectionState()
         };
      }
   }
}

