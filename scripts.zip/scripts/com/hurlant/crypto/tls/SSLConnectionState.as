package com.hurlant.crypto.tls
{
   import com.hurlant.crypto.hash.MAC;
   import com.hurlant.crypto.symmetric.*;
   import com.hurlant.util.*;
   import flash.utils.*;
   
   public class SSLConnectionState implements IConnectionState
   {
      private var bulkCipher:uint;
      
      private var cipherType:uint;
      
      private var CIPHER_key:ByteArray;
      
      private var CIPHER_IV:ByteArray;
      
      private var cipher:ICipher;
      
      private var ivmode:IVMode;
      
      private var macAlgorithm:uint;
      
      private var MAC_write_secret:ByteArray;
      
      private var mac:MAC;
      
      private var seq_lo:uint = 0;
      
      private var seq_hi:uint = 0;
      
      public function SSLConnectionState(bulkCipher:uint = 0, cipherType:uint = 0, macAlgorithm:uint = 0, mac_enc:ByteArray = null, key:ByteArray = null, IV:ByteArray = null)
      {
         super();
         this.bulkCipher = bulkCipher;
         this.cipherType = cipherType;
         this.macAlgorithm = macAlgorithm;
         this.MAC_write_secret = mac_enc;
         this.mac = MACs.getMAC(macAlgorithm);
         this.CIPHER_key = key;
         this.CIPHER_IV = IV;
         this.cipher = BulkCiphers.getCipher(bulkCipher,key,768);
         if(this.cipher is IVMode)
         {
            this.ivmode = this.cipher as IVMode;
            this.ivmode.IV = IV;
         }
      }
      
      public function decrypt(type:uint, length:uint, p:ByteArray) : ByteArray
      {
         var nextIV:ByteArray = null;
         var data:ByteArray = null;
         var len:uint = 0;
         var mac_enc:ByteArray = null;
         var mac_received:ByteArray = null;
         if(this.cipherType == BulkCiphers.STREAM_CIPHER)
         {
            if(this.bulkCipher != BulkCiphers.NULL)
            {
               this.cipher.decrypt(p);
            }
         }
         else
         {
            p.position = 0;
            if(this.bulkCipher != BulkCiphers.NULL)
            {
               nextIV = new ByteArray();
               nextIV.writeBytes(p,p.length - this.CIPHER_IV.length,this.CIPHER_IV.length);
               p.position = 0;
               this.cipher.decrypt(p);
               this.CIPHER_IV = nextIV;
               this.ivmode.IV = nextIV;
            }
         }
         if(this.macAlgorithm != MACs.NULL)
         {
            data = new ByteArray();
            len = p.length - this.mac.getHashSize();
            data.writeUnsignedInt(this.seq_hi);
            data.writeUnsignedInt(this.seq_lo);
            data.writeByte(type);
            data.writeShort(len);
            if(len != 0)
            {
               data.writeBytes(p,0,len);
            }
            mac_enc = this.mac.compute(this.MAC_write_secret,data);
            mac_received = new ByteArray();
            mac_received.writeBytes(p,len,this.mac.getHashSize());
            if(!ArrayUtil.equals(mac_enc,mac_received))
            {
               throw new TLSError("Bad Mac Data",TLSError.bad_record_mac);
            }
            p.length = len;
            p.position = 0;
         }
         ++this.seq_lo;
         if(this.seq_lo == 0)
         {
            ++this.seq_hi;
         }
         return p;
      }
      
      public function encrypt(type:uint, p:ByteArray) : ByteArray
      {
         var data:ByteArray = null;
         var nextIV:ByteArray = null;
         var mac_enc:ByteArray = null;
         if(this.macAlgorithm != MACs.NULL)
         {
            data = new ByteArray();
            data.writeUnsignedInt(this.seq_hi);
            data.writeUnsignedInt(this.seq_lo);
            data.writeByte(type);
            data.writeShort(p.length);
            if(p.length != 0)
            {
               data.writeBytes(p);
            }
            mac_enc = this.mac.compute(this.MAC_write_secret,data);
            p.position = p.length;
            p.writeBytes(mac_enc);
         }
         p.position = 0;
         if(this.cipherType == BulkCiphers.STREAM_CIPHER)
         {
            if(this.bulkCipher != BulkCiphers.NULL)
            {
               this.cipher.encrypt(p);
            }
         }
         else
         {
            this.cipher.encrypt(p);
            nextIV = new ByteArray();
            nextIV.writeBytes(p,p.length - this.CIPHER_IV.length,this.CIPHER_IV.length);
            this.CIPHER_IV = nextIV;
            this.ivmode.IV = nextIV;
         }
         ++this.seq_lo;
         if(this.seq_lo == 0)
         {
            ++this.seq_hi;
         }
         return p;
      }
   }
}

