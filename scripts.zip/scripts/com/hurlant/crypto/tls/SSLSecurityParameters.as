package com.hurlant.crypto.tls
{
   import com.hurlant.crypto.hash.*;
   import com.hurlant.util.*;
   import flash.utils.*;
   
   public class SSLSecurityParameters implements ISecurityParameters
   {
      public static const COMPRESSION_NULL:uint = 0;
      
      public static const PROTOCOL_VERSION:uint = 768;
      
      private var entity:uint;
      
      private var bulkCipher:uint;
      
      private var cipherType:uint;
      
      private var keySize:uint;
      
      private var keyMaterialLength:uint;
      
      private var keyBlock:ByteArray;
      
      private var IVSize:uint;
      
      private var MAC_length:uint;
      
      private var macAlgorithm:uint;
      
      private var hashSize:uint;
      
      private var compression:uint;
      
      private var masterSecret:ByteArray;
      
      private var clientRandom:ByteArray;
      
      private var serverRandom:ByteArray;
      
      private var pad_1:ByteArray;
      
      private var pad_2:ByteArray;
      
      private var ignoreCNMismatch:Boolean = true;
      
      private var trustAllCerts:Boolean = false;
      
      private var trustSelfSigned:Boolean = false;
      
      public var keyExchange:uint;
      
      public function SSLSecurityParameters(entity:uint, localCert:ByteArray = null, localKey:ByteArray = null)
      {
         super();
         this.entity = entity;
         this.reset();
      }
      
      public function get version() : uint
      {
         return PROTOCOL_VERSION;
      }
      
      public function reset() : void
      {
         this.bulkCipher = BulkCiphers.NULL;
         this.cipherType = BulkCiphers.BLOCK_CIPHER;
         this.macAlgorithm = MACs.NULL;
         this.compression = COMPRESSION_NULL;
         this.masterSecret = null;
      }
      
      public function getBulkCipher() : uint
      {
         return this.bulkCipher;
      }
      
      public function getCipherType() : uint
      {
         return this.cipherType;
      }
      
      public function getMacAlgorithm() : uint
      {
         return this.macAlgorithm;
      }
      
      public function setCipher(cipher:uint) : void
      {
         this.bulkCipher = CipherSuites.getBulkCipher(cipher);
         this.cipherType = BulkCiphers.getType(this.bulkCipher);
         this.keySize = BulkCiphers.getExpandedKeyBytes(this.bulkCipher);
         this.keyMaterialLength = BulkCiphers.getKeyBytes(this.bulkCipher);
         this.IVSize = BulkCiphers.getIVSize(this.bulkCipher);
         this.keyExchange = CipherSuites.getKeyExchange(cipher);
         this.macAlgorithm = CipherSuites.getMac(cipher);
         this.hashSize = MACs.getHashSize(this.macAlgorithm);
         this.pad_1 = new ByteArray();
         this.pad_2 = new ByteArray();
         for(var x:int = 0; x < 48; x++)
         {
            this.pad_1.writeByte(54);
            this.pad_2.writeByte(92);
         }
      }
      
      public function setCompression(algo:uint) : void
      {
         this.compression = algo;
      }
      
      public function setPreMasterSecret(secret:ByteArray) : void
      {
         var shaHash:ByteArray = null;
         var mdHash:ByteArray = null;
         var i:int = 0;
         var j:int = 0;
         var tempHashA:ByteArray = new ByteArray();
         var tempHashB:ByteArray = new ByteArray();
         var sha:SHA1 = new SHA1();
         var md:MD5 = new MD5();
         var k:ByteArray = new ByteArray();
         k.writeBytes(secret);
         k.writeBytes(this.clientRandom);
         k.writeBytes(this.serverRandom);
         this.masterSecret = new ByteArray();
         var pad_char:uint = 65;
         for(i = 0; i < 3; i++)
         {
            tempHashA.position = 0;
            for(j = 0; j < i + 1; j++)
            {
               tempHashA.writeByte(pad_char);
            }
            pad_char++;
            tempHashA.writeBytes(k);
            shaHash = sha.hash(tempHashA);
            tempHashB.position = 0;
            tempHashB.writeBytes(secret);
            tempHashB.writeBytes(shaHash);
            mdHash = md.hash(tempHashB);
            this.masterSecret.writeBytes(mdHash);
         }
         k.position = 0;
         k.writeBytes(this.masterSecret);
         k.writeBytes(this.serverRandom);
         k.writeBytes(this.clientRandom);
         this.keyBlock = new ByteArray();
         tempHashA = new ByteArray();
         tempHashB = new ByteArray();
         pad_char = 65;
         for(i = 0; i < 16; i++)
         {
            tempHashA.position = 0;
            for(j = 0; j < i + 1; j++)
            {
               tempHashA.writeByte(pad_char);
            }
            pad_char++;
            tempHashA.writeBytes(k);
            shaHash = sha.hash(tempHashA);
            tempHashB.position = 0;
            tempHashB.writeBytes(this.masterSecret);
            tempHashB.writeBytes(shaHash,0);
            mdHash = md.hash(tempHashB);
            this.keyBlock.writeBytes(mdHash);
         }
      }
      
      public function setClientRandom(secret:ByteArray) : void
      {
         this.clientRandom = secret;
      }
      
      public function setServerRandom(secret:ByteArray) : void
      {
         this.serverRandom = secret;
      }
      
      public function get useRSA() : Boolean
      {
         return KeyExchanges.useRSA(this.keyExchange);
      }
      
      public function computeVerifyData(side:uint, handshakeMessages:ByteArray) : ByteArray
      {
         var innerKey:ByteArray = null;
         var hashSha:ByteArray = null;
         var hashMD:ByteArray = null;
         var sha:SHA1 = new SHA1();
         var md:MD5 = new MD5();
         var k:ByteArray = new ByteArray();
         var j:ByteArray = new ByteArray();
         var outerKey:ByteArray = new ByteArray();
         var sideBytes:ByteArray = new ByteArray();
         if(side == TLSEngine.CLIENT)
         {
            sideBytes.writeUnsignedInt(1129074260);
         }
         else
         {
            sideBytes.writeUnsignedInt(1397904978);
         }
         this.masterSecret.position = 0;
         k.writeBytes(handshakeMessages);
         k.writeBytes(sideBytes);
         k.writeBytes(this.masterSecret);
         k.writeBytes(this.pad_1,0,40);
         innerKey = sha.hash(k);
         j.writeBytes(this.masterSecret);
         j.writeBytes(this.pad_2,0,40);
         j.writeBytes(innerKey);
         hashSha = sha.hash(j);
         k = new ByteArray();
         k.writeBytes(handshakeMessages);
         k.writeBytes(sideBytes);
         k.writeBytes(this.masterSecret);
         k.writeBytes(this.pad_1);
         innerKey = md.hash(k);
         j = new ByteArray();
         j.writeBytes(this.masterSecret);
         j.writeBytes(this.pad_2);
         j.writeBytes(innerKey);
         hashMD = md.hash(j);
         outerKey.writeBytes(hashMD,0,hashMD.length);
         outerKey.writeBytes(hashSha,0,hashSha.length);
         var out:String = Hex.fromArray(outerKey);
         outerKey.position = 0;
         return outerKey;
      }
      
      public function computeCertificateVerify(side:uint, handshakeMessages:ByteArray) : ByteArray
      {
         return null;
      }
      
      public function getConnectionStates() : Object
      {
         var mac_length:int = 0;
         var key_length:int = 0;
         var iv_length:int = 0;
         var client_write_MAC:ByteArray = null;
         var server_write_MAC:ByteArray = null;
         var client_write_key:ByteArray = null;
         var server_write_key:ByteArray = null;
         var client_write_IV:ByteArray = null;
         var server_write_IV:ByteArray = null;
         var client_write:SSLConnectionState = null;
         var server_write:SSLConnectionState = null;
         if(this.masterSecret != null)
         {
            mac_length = this.hashSize as Number;
            key_length = this.keySize as Number;
            iv_length = this.IVSize as Number;
            client_write_MAC = new ByteArray();
            server_write_MAC = new ByteArray();
            client_write_key = new ByteArray();
            server_write_key = new ByteArray();
            client_write_IV = new ByteArray();
            server_write_IV = new ByteArray();
            this.keyBlock.position = 0;
            this.keyBlock.readBytes(client_write_MAC,0,mac_length);
            this.keyBlock.readBytes(server_write_MAC,0,mac_length);
            this.keyBlock.readBytes(client_write_key,0,key_length);
            this.keyBlock.readBytes(server_write_key,0,key_length);
            this.keyBlock.readBytes(client_write_IV,0,iv_length);
            this.keyBlock.readBytes(server_write_IV,0,iv_length);
            this.keyBlock.position = 0;
            client_write = new SSLConnectionState(this.bulkCipher,this.cipherType,this.macAlgorithm,client_write_MAC,client_write_key,client_write_IV);
            server_write = new SSLConnectionState(this.bulkCipher,this.cipherType,this.macAlgorithm,server_write_MAC,server_write_key,server_write_IV);
            if(this.entity == TLSEngine.CLIENT)
            {
               return {
                  "read":server_write,
                  "write":client_write
               };
            }
            return {
               "read":client_write,
               "write":server_write
            };
         }
         return {
            "read":new SSLConnectionState(),
            "write":new SSLConnectionState()
         };
      }
   }
}

