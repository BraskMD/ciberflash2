package com.hurlant.util
{
   import flash.net.*;
   import flash.system.*;
   
   public class Memory
   {
      public function Memory()
      {
         super();
      }
      
      public static function gc() : void
      {
         trace("enable");
         try
         {
            new LocalConnection().connect("foo");
            new LocalConnection().connect("foo");
         }
         catch(e:*)
         {
         }
      }
      
      public static function get used() : uint
      {
         return System.totalMemory;
      }
   }
}

