package
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol69")]
   public dynamic class ScrollThumb_overSkin extends MovieClip
   {
      public function ScrollThumb_overSkin()
      {
         super();
      }
   }
}

