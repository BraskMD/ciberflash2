package
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol58")]
   public dynamic class ScrollTrack_skin extends MovieClip
   {
      public function ScrollTrack_skin()
      {
         super();
      }
   }
}

