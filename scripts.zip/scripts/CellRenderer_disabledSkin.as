package
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol37")]
   public dynamic class CellRenderer_disabledSkin extends MovieClip
   {
      public function CellRenderer_disabledSkin()
      {
         super();
      }
   }
}

