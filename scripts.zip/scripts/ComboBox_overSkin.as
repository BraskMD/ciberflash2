package
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol106")]
   public dynamic class ComboBox_overSkin extends MovieClip
   {
      public function ComboBox_overSkin()
      {
         super();
      }
   }
}

