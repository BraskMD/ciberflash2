package
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol35")]
   public dynamic class CellRenderer_upSkin extends MovieClip
   {
      public function CellRenderer_upSkin()
      {
         super();
      }
   }
}

