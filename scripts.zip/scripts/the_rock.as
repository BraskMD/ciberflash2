package
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol526")]
   public dynamic class the_rock extends MovieClip
   {
      public function the_rock()
      {
         super();
         addFrameScript(30,this.frame31);
      }
      
      internal function frame31() : *
      {
         stop();
         parent.removeChild(this);
      }
   }
}

