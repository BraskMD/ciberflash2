package
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol81")]
   public dynamic class ScrollBar_thumbIcon extends MovieClip
   {
      public function ScrollBar_thumbIcon()
      {
         super();
      }
   }
}

