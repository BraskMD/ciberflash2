package
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol15")]
   public dynamic class HeaderRenderer_upSkin extends MovieClip
   {
      public function HeaderRenderer_upSkin()
      {
         super();
      }
   }
}

