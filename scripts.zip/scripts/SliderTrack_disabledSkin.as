package
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol99")]
   public dynamic class SliderTrack_disabledSkin extends MovieClip
   {
      public function SliderTrack_disabledSkin()
      {
         super();
      }
   }
}

