package
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol23")]
   public dynamic class HeaderRenderer_selectedDisabledSkin extends MovieClip
   {
      public function HeaderRenderer_selectedDisabledSkin()
      {
         super();
      }
   }
}

