package
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol97")]
   public dynamic class SliderTick_skin extends MovieClip
   {
      public function SliderTick_skin()
      {
         super();
      }
   }
}

