package
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol26")]
   public dynamic class HeaderRenderer_selectedOverSkin extends MovieClip
   {
      public function HeaderRenderer_selectedOverSkin()
      {
         super();
      }
   }
}

